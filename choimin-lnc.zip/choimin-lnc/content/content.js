// 콘텐츠 스크립트 - 페이지에서 실행

let currentRotation = 0;
let replacedImages = new Map();
let observerActive = false;

// 초기화
window.addEventListener('load', init);
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', init);
} else {
  init();
}

function init() {
  loadSettings();
  attachKeyListener();
  setupTitleObserver();
}

// 설정 로드 및 적용
async function loadSettings() {
  chrome.runtime.sendMessage({ type: 'getSettings' }, (response) => {
    if (!response) return;

    const settings = response.tabSettings || {};

    if (settings.cursorImage) {
      setCursor(settings.cursorImage);
    }

    if (settings.rotation && settings.rotation !== 0) {
      applyRotation(settings.rotation);
    }

    if (settings.replaceImages && settings.replacementImage) {
      replaceImagesOnPage(settings.replacementImage);
    }

    if (settings.pageTitle) {
      setPageTitle(settings.pageTitle);
    }
  });
}

// 키보드 이벤트 수신
function attachKeyListener() {
  document.addEventListener('keydown', (e) => {
    const key = e.key.toUpperCase();
    chrome.runtime.sendMessage({
      type: 'keyPress',
      key: key
    }).catch(() => {});
  });
}

// 메시지 수신
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  switch (request.type) {
    case 'rotate':
      applyRotation(request.degree);
      break;

    case 'setCursor':
      setCursor(request.imageUrl);
      break;

    case 'replaceImages':
      replaceImagesOnPage(request.imageUrl);
      break;

    case 'restoreImages':
      restoreOriginalImages();
      break;

    case 'setPageTitle':
      setPageTitle(request.title);
      break;

    case 'resetPageTitle':
      resetPageTitle();
      break;
  }
});

// 화면 회전 적용
function applyRotation(degree) {
  currentRotation = degree;
  const html = document.documentElement;
  const transform = degree === 0 ? 'none' : `rotate(${degree}deg)`;

  html.style.transform = transform;
  html.style.transformOrigin = 'center center';
  html.style.transition = 'transform 0.5s ease';

  if (degree !== 0) {
    html.style.width = '100vw';
    html.style.height = '100vh';
    html.style.overflow = 'hidden';
  } else {
    html.style.width = 'auto';
    html.style.height = 'auto';
    html.style.overflow = 'auto';
  }
}

// 커서 이미지 설정
function setCursor(imageUrl) {
  try {
    const style = document.createElement('style');
    style.textContent = `
      * {
        cursor: url('${imageUrl}') auto !important;
      }
    `;
    document.head.appendChild(style);
  } catch (e) {
    console.error('커서 설정 오류:', e);
  }
}

// 이미지 대체
function replaceImagesOnPage(imageUrl) {
  if (observerActive) return;

  // 기존 이미지 저장 및 대체
  document.querySelectorAll('img').forEach(img => {
    if (!replacedImages.has(img)) {
      replacedImages.set(img, img.src);
      img.src = imageUrl;
      img.style.transition = 'opacity 0.3s ease';
    }
  });

  // CSS background-image 대체
  document.querySelectorAll('*').forEach(el => {
    const bg = window.getComputedStyle(el).backgroundImage;
    if (bg && bg !== 'none' && !replacedImages.has(el)) {
      replacedImages.set(el, bg);
      el.style.backgroundImage = `url('${imageUrl}')`;
    }
  });

  // MutationObserver로 동적 이미지 감지
  if (!observerActive) {
    observerActive = true;
    const observer = new MutationObserver((mutations) => {
      mutations.forEach((mutation) => {
        if (mutation.type === 'childList') {
          mutation.addedNodes.forEach((node) => {
            if (node.nodeType === 1) {
              if (node.tagName === 'IMG') {
                replacedImages.set(node, node.src);
                node.src = imageUrl;
              }
            }
          });
        }
      });
    });

    observer.observe(document.body, {
      childList: true,
      subtree: true
    });
  }
}

// 원본 이미지 복구
function restoreOriginalImages() {
  replacedImages.forEach((originalUrl, element) => {
    if (element.tagName === 'IMG') {
      element.src = originalUrl;
    } else {
      element.style.backgroundImage = originalUrl;
    }
  });

  replacedImages.clear();
  observerActive = false;
}

// 페이지 제목 변경
function setPageTitle(title) {
  if (title) {
    window.originalTitle = window.originalTitle || document.title;
    document.title = title;
  }
}

// 페이지 제목 원래대로
function resetPageTitle() {
  if (window.originalTitle) {
    document.title = window.originalTitle;
  }
}

// 제목 변경 감시
function setupTitleObserver() {
  const observer = new MutationObserver((mutations) => {
    mutations.forEach((mutation) => {
      if (mutation.type === 'characterData') {
        chrome.runtime.sendMessage({ type: 'getSettings' }, (response) => {
          if (response && response.tabSettings && response.tabSettings.pageTitle) {
            document.title = response.tabSettings.pageTitle;
          }
        });
      }
    });
  });

  const titleElement = document.querySelector('title');
  if (titleElement) {
    observer.observe(titleElement, {
      characterData: true,
      subtree: true
    });
  }
}
