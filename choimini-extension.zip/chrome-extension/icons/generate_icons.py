#!/usr/bin/env python3
"""최미나이 앱 아이콘 생성 — 파란 원 배경 + '최' 글자."""
from PIL import Image, ImageDraw, ImageFont
import os

BLUE = (59, 130, 246, 255)
BG = (10, 11, 15, 255)
WHITE = (255, 255, 255, 255)

def find_font(size):
    for p in [
        "/usr/share/fonts/truetype/nanum/NanumGothic.ttf",
        "/usr/share/fonts/opentype/noto/NotoSansCJK-Bold.ttc",
        "/usr/share/fonts/truetype/noto/NotoSansCJK-Bold.ttc",
        "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
    ]:
        if os.path.exists(p):
            try:
                return ImageFont.truetype(p, size)
            except Exception:
                pass
    return ImageFont.load_default()

def make(size, char="최"):
    img = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    pad = max(1, size // 16)
    d.ellipse([pad, pad, size - pad, size - pad], fill=BLUE)
    font = find_font(int(size * 0.5))
    try:
        bbox = d.textbbox((0, 0), char, font=font)
        w, h = bbox[2] - bbox[0], bbox[3] - bbox[1]
        d.text(((size - w) / 2 - bbox[0], (size - h) / 2 - bbox[1]), char, font=font, fill=WHITE)
    except Exception:
        d.text((size * 0.3, size * 0.25), char, font=font, fill=WHITE)
    return img

if __name__ == "__main__":
    here = os.path.dirname(os.path.abspath(__file__))
    for s in [16, 48, 128]:
        make(s).save(os.path.join(here, f"icon{s}.png"))
    print("icons written:", here)
