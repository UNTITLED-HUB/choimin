// 렌더러(신뢰 영역): webview(최미나이 사이트) + Chat/Code 모드 + 로그인 상태 + 캡차 + 작업 폴더/권한 + 활동 기록 + 승인 창 + 터미널.
// 주의: 도구 출력/파일 내용/diff 는 외부 데이터이므로 항상 textContent 로만 그린다 (innerHTML 금지).
const $ = (id) => document.getElementById(id);
let SITE_ORIGIN = "";
let webview = null, webviewReady = false;
let mode = "chat", loggedIn = false;

function toast(msg) { const t = $("toast"); t.textContent = msg; t.classList.add("show"); clearTimeout(toast._h); toast._h = setTimeout(() => t.classList.remove("show"), 2600); }

/* ---------- webview ---------- */
async function initWebview() {
  const siteUrl = await window.desktop.getSiteUrl();
  SITE_ORIGIN = new URL(siteUrl).origin;
  // Electron 은 preload 에 상대경로를 허용하지 않아(조용히 무시됨) 절대 file: URL 로 지정한다 (asar 안에서도 동작)
  webview = document.createElement("webview");
  webview.id = "choimini";
  webview.setAttribute("preload", new URL("../webview-preload.js", location.href).href);
  webview.setAttribute("webpreferences", "nodeIntegration=no");
  webview.setAttribute("partition", "persist:choimini");
  webview.setAttribute("allowpopups", "");
  $("left").appendChild(webview);
  webview.src = siteUrl;

  webview.addEventListener("ipc-message", (e) => {
    let origin = ""; try { origin = new URL(webview.getURL()).origin; } catch (_) {}
    if (origin !== SITE_ORIGIN) return; // 다른 페이지로 이동했을 때 방어
    if (e.channel === "open-auth") window.desktop.openAuth(e.args[0]);
    else if (e.channel === "auth-state") setLoggedIn(!!e.args[0]);
    else if (e.channel === "tool-call") {
      const { reqId, tool, args } = e.args[0];
      window.desktop.callTool(tool, args).then((result) => webview.send("tool-result", { reqId, result }));
    }
  });
  webview.addEventListener("dom-ready", () => { webviewReady = true; pushMode(); });
  window.desktop.onAuthCallback((url) => webview.send("auth-callback", url));
}

async function pushMode() { // 현재 모드(+ Code 면 에이전트 프롬프트)를 webview 에 알린다
  if (!webviewReady) return;
  const prompt = mode === "code" ? await window.desktop.getCodePrompt() : "";
  webview.send("mode-change", mode, prompt);
}

/* ---------- 로그인 상태 ---------- */
function setLoggedIn(v) {
  loggedIn = v;
  window.desktop.setAuth(v);
  $("authState").textContent = v ? "로그인됨" : "로그인 필요";
  $("authState").classList.toggle("ok", v);
  $("modeCode").classList.toggle("locked", !v);
  $("modeCode").title = v ? "코딩 에이전트 모드" : "로그인 후 사용할 수 있어요";
}
window.desktop.onForceChat((why) => { applyModeUI("chat", true); if (why) toast(why); });

/* ---------- 모드 전환 ---------- */
const hints = { chat: "일반 최미나이 채팅", code: "Choimini Code · 작업 폴더에서 파일 수정 / 명령 실행" };
async function applyModeUI(m, silent) {
  if (m === "code") {
    const r = await window.desktop.setMode("code");
    if (!r.ok) { if (!silent) toast(r.reason === "login" ? "로그인해야 Code 모드를 쓸 수 있어요." : "인증이 필요해요."); m = "chat"; await window.desktop.setMode("chat"); }
  } else await window.desktop.setMode("chat");
  mode = m;
  document.body.classList.toggle("code", m === "code");
  $("modeChat").classList.toggle("active", m === "chat");
  $("modeCode").classList.toggle("active", m === "code");
  $("modeHint").textContent = hints[m];
  if (m === "code") { ensureTerminal(); refreshWorkspace(); setTimeout(doResize, 60); }
  pushMode();
}
$("modeChat").addEventListener("click", () => applyModeUI("chat"));
$("modeCode").addEventListener("click", async () => {
  if (mode === "code") return;
  if (!loggedIn) return toast("로그인해야 Code 모드를 쓸 수 있어요.");
  const { unlocked } = await window.desktop.codeStatus();
  if (unlocked) return applyModeUI("code");
  openCaptcha();
});

/* ---------- 캡차 ---------- */
async function loadCaptcha() {
  $("captchaInput").value = ""; $("captchaMsg").textContent = "";
  const r = await window.desktop.captchaNew();
  if (r.locked) { $("captchaMsg").textContent = `잠시 후 다시 시도하세요 (${r.retryInSec}초)`; $("captchaImg").removeAttribute("src"); return; }
  $("captchaImg").src = r.image; $("captchaInput").focus();
}
function openCaptcha() { $("captchaModal").classList.add("show"); loadCaptcha(); }
function closeCaptcha() { $("captchaModal").classList.remove("show"); }
async function submitCaptcha() {
  const r = await window.desktop.captchaVerify($("captchaInput").value);
  if (r.ok) { closeCaptcha(); applyModeUI("code"); return; }
  if (r.locked) { $("captchaMsg").textContent = `3회 실패 — ${r.retryInSec}초 뒤 다시 시도하세요.`; $("captchaImg").removeAttribute("src"); return; }
  if (r.expired) { $("captchaMsg").textContent = "시간이 지났어요. 새 이미지를 불러올게요."; return loadCaptcha(); }
  $("captchaMsg").textContent = `틀렸어요. (남은 기회 ${r.triesLeft}번)`; $("captchaInput").value = ""; $("captchaInput").focus();
}
$("captchaOk").addEventListener("click", submitCaptcha);
$("captchaRefresh").addEventListener("click", loadCaptcha);
$("captchaCancel").addEventListener("click", closeCaptcha);
$("captchaInput").addEventListener("keydown", (e) => { if (e.key === "Enter") submitCaptcha(); });

/* ---------- 작업 폴더 / 권한 모드 ---------- */
function showWorkspace(s) {
  const b = $("wsBtn");
  if (s.workspace) { const name = s.workspace.split(/[\\/]/).filter(Boolean).pop() || s.workspace; b.textContent = "📁 " + name; b.title = s.workspace; b.classList.remove("empty"); }
  else { b.textContent = "📁 작업 폴더 선택"; b.title = "작업 폴더를 선택하세요"; b.classList.add("empty"); }
  $("permMode").value = s.permMode;
}
async function refreshWorkspace() { showWorkspace(await window.desktop.workspaceGet()); }
$("wsBtn").addEventListener("click", async () => { showWorkspace(await window.desktop.workspacePick()); pushMode(); });
$("permMode").addEventListener("change", async (e) => { showWorkspace(await window.desktop.setPermMode(e.target.value)); pushMode(); });
window.desktop.onWorkspaceChanged((s) => { showWorkspace(s); pushMode(); });
$("abortBtn").addEventListener("click", () => { window.desktop.abortAgent(); toast("다음 도구 호출부터 중단돼요."); });

/* ---------- 탭 ---------- */
function showTab(name) { for (const [t, p] of [["tabAct", "paneAct"], ["tabTerm", "paneTerm"]]) { $(t).classList.toggle("active", t === name); $(p).classList.toggle("active", p === (name === "tabAct" ? "paneAct" : "paneTerm")); } if (name === "tabTerm") setTimeout(doResize, 30); }
$("tabAct").addEventListener("click", () => showTab("tabAct")); $("tabTerm").addEventListener("click", () => showTab("tabTerm"));

/* ---------- 활동 기록 (도구 호출 내역) ---------- */
const ICON = { running: "…", ok: "✓", error: "✗", denied: "⊘" };
function renderDiff(text) {
  const pre = document.createElement("pre"); pre.className = "blk";
  for (const line of String(text).split("\n")) {
    const s = document.createElement("span"); s.textContent = line + "\n";
    s.className = line.startsWith("+ ") ? "ln-add" : line.startsWith("- ") ? "ln-del" : line === "…" ? "ln-gap" : "";
    pre.appendChild(s);
  }
  return pre;
}
function upsertActivity(a) {
  const box = $("activity");
  const emptyEl = box.querySelector(".empty"); if (emptyEl) emptyEl.remove();
  let el = box.querySelector(`[data-id="${a.id}"]`);
  if (!el) {
    el = document.createElement("div"); el.dataset.id = a.id; el.className = "act";
    el.innerHTML = '<div class="act-head"><span class="ic"></span><span class="sum"></span></div><div class="act-body"></div>';
    el.querySelector(".act-head").addEventListener("click", () => el.classList.toggle("open"));
    box.appendChild(el);
  }
  el.className = "act " + a.status + (el.classList.contains("open") ? " open" : "");
  el.querySelector(".ic").textContent = ICON[a.status] || "•";
  el.querySelector(".sum").textContent = a.summary;
  const body = el.querySelector(".act-body"); body.textContent = "";
  if (a.todo) { const ul = document.createElement("ul"); ul.className = "todo"; a.todo.forEach((t) => { const li = document.createElement("li"); li.className = t.status; li.textContent = (t.status === "completed" ? "✓ " : t.status === "in_progress" ? "▶ " : "○ ") + t.text; ul.appendChild(li); }); body.appendChild(ul); el.classList.add("open"); }
  if (a.diff) body.appendChild(renderDiff(a.diff));
  else if (a.output) { const pre = document.createElement("pre"); pre.className = "blk"; pre.textContent = a.output; body.appendChild(pre); }
  box.scrollTop = box.scrollHeight;
}
window.desktop.onActivity(upsertActivity);

/* ---------- 승인 창 ---------- */
const permQueue = []; let permCurrent = null;
function showNextPerm() {
  if (permCurrent || !permQueue.length) return;
  permCurrent = permQueue.shift();
  const r = permCurrent;
  $("permKind").textContent = r.kind === "edit" ? "파일 변경 승인" : "명령 실행 승인";
  $("permTitle").textContent = r.title;
  const body = $("permBody"); body.textContent = "";
  if (r.diff) body.appendChild(renderDiff(r.diff)); else { const pre = document.createElement("pre"); pre.className = "blk"; pre.textContent = r.detail; body.appendChild(pre); }
  $("permSession").textContent = r.kind === "edit" ? "이번 세션 파일 수정 모두 허용" : "이번 세션 이 명령 항상 허용";
  $("permModal").classList.add("show");
}
function answerPerm(choice) { if (!permCurrent) return; window.desktop.respondPermission(permCurrent.id, choice); permCurrent = null; $("permModal").classList.remove("show"); showNextPerm(); }
$("permAllow").addEventListener("click", () => answerPerm("once"));
$("permSession").addEventListener("click", () => answerPerm("session"));
$("permDeny").addEventListener("click", () => answerPerm("deny"));
window.desktop.onPermissionRequest((r) => { permQueue.push(r); showNextPerm(); });
// 메인 프로세스가 요청을 취소하면(로그아웃/모드 전환/중단) 떠 있는 승인 창과 대기열을 비운다
window.desktop.onPermissionCancel(() => { permQueue.length = 0; permCurrent = null; $("permModal").classList.remove("show"); });

/* ---------- 터미널 ---------- */
const TERM_ID = "main"; let term = null, fitAddon = null, termStarted = false;
function ensureTerminal() {
  if (termStarted) return; termStarted = true;
  term = new Terminal({ fontFamily: "Consolas, 'SFMono-Regular', Menlo, monospace", fontSize: 13, theme: { background: "#0d0f16", foreground: "#e7e9f2", cursor: "#3b82f6" }, cursorBlink: true });
  fitAddon = new FitAddon.FitAddon(); term.loadAddon(fitAddon); term.open($("terminal"));
  let line = "";
  term.onData((d) => { // 파이프 기반이라 한 줄 단위 입력
    if (d === "\r") { term.write("\r\n"); window.desktop.termInput(TERM_ID, line + "\n"); line = ""; }
    else if (d === "\u007f") { if (line.length) { line = line.slice(0, -1); term.write("\b \b"); } }
    else if (d === "\u0003") { line = ""; term.write("^C\r\n"); window.desktop.termInput(TERM_ID, "\u0003"); }
    else { line += d; term.write(d); }
  });
  window.desktop.termCreate({ id: TERM_ID }).then((ok) => term.writeln(ok ? "Choimini Code 터미널 (작업 폴더에서 시작)" : "[차단] 터미널을 시작할 수 없어요."));
  window.desktop.onTermData((m) => { if (m.id === TERM_ID) term.write(m.data.replace(/\r?\n/g, "\r\n")); });
  window.desktop.onTermExit((m) => { if (m.id === TERM_ID) term.write("\r\n[프로세스 종료됨]\r\n"); });
}
function doResize() { if (!fitAddon) return; try { fitAddon.fit(); window.desktop.termResize(TERM_ID, term.cols, term.rows); } catch (_) {} }
window.addEventListener("resize", doResize);

/* ---------- 분할선 ---------- */
let dragging = false;
$("divider").addEventListener("mousedown", () => { dragging = true; document.body.style.cursor = "col-resize"; });
window.addEventListener("mouseup", () => { if (dragging) { dragging = false; document.body.style.cursor = ""; doResize(); } });
window.addEventListener("mousemove", (e) => { if (!dragging) return; $("left").style.flexBasis = Math.min(80, Math.max(20, (e.clientX / window.innerWidth) * 100)) + "%"; });

initWebview();
