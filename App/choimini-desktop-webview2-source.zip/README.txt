﻿Choimini Desktop 1.5.0 (WebView2) - 소스

빌드 (Windows, Visual Studio 필요 없음):
  build.bat 더블클릭 → out\ChoiminiDesktop.exe 하나만 만들어집니다 (DLL·code-prompt.txt 는 EXE 안에 들어감, 그 파일 하나만 있으면 실행).

반드시 필요한 것 (자동 빌드 도구가 직접 csc 로 빌드한다면 이렇게 설정):
  - 소스 3개 모두: src\Tools.cs src\Program.cs src\DeviceUse.cs  (tests 폴더 제외)
  - /main:Choimini.Boot  (시작점)
  - /resource:lib\Microsoft.Web.WebView2.Core.dll,lib.Microsoft.Web.WebView2.Core.dll (WinForms.dll, WebView2Loader.dll 도 같은 형식, res\code-prompt.txt,res.code-prompt.txt)
  - /platform:x64  (lib\WebView2Loader.dll 이 64비트라서 anycpu/x86 은 실행 시 실패)
  - 참조: System, System.Core, System.Windows.Forms, System.Drawing, System.Web.Extensions, Accessibility,
          lib\Microsoft.Web.WebView2.Core.dll, lib\Microsoft.Web.WebView2.WinForms.dll
  - /win32manifest:res\app.manifest (고해상도 화면 선명), /win32icon:res\icon.ico
Visual Studio 를 쓰면 ChoiminiDesktop.csproj 를 열어 빌드해도 됩니다.
