// 옵션 페이지 스크립트

document.addEventListener('DOMContentLoaded', init);

async function init() {
  loadSettings();
  attachEventListeners();
}

async function loadSettings() {
  const data = await StorageManager.load();
  
  document.getElementById('extensionToggle').checked = data.enabled;
  document.getElementById('defaultTabLimit').value = 10;
}

function attachEventListeners() {
  document.getElementById('extensionToggle').addEventListener('change', toggleExtension);
  document.getElementById('exportBtn').addEventListener('click', exportSettings);
  document.getElementById('importBtn').addEventListener('click', importSettings);
  document.getElementById('resetBtn').addEventListener('click', resetAll);
}

async function toggleExtension(e) {
  await StorageManager.toggleExtension(e.target.checked);
  showSaveStatus('저장되었습니다.', 'success');
}

async function exportSettings() {
  const data = await StorageManager.load();
  const json = JSON.stringify(data, null, 2);
  const blob = new Blob([json], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = 'choimin-lnc-settings.json';
  a.click();
  showSaveStatus('설정을 내보냈습니다.', 'success');
}

function importSettings() {
  const input = document.createElement('input');
  input.type = 'file';
  input.accept = 'application/json';
  input.addEventListener('change', async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = async (event) => {
      try {
        const data = JSON.parse(event.target.result);
        await chrome.storage.local.set(data);
        showSaveStatus('설정을 가져왔습니다.', 'success');
        await loadSettings();
      } catch (error) {
        showSaveStatus('올바른 파일이 아닙니다.', 'error');
      }
    };
    reader.readAsText(file);
  });
  input.click();
}

async function resetAll() {
  if (confirm('모든 설정을 초기화하시겠습니까? 이 작업은 되돌릴 수 없습니다.')) {
    await chrome.storage.local.clear();
    await chrome.storage.local.set(StorageManager.defaultData);
    showSaveStatus('모든 설정이 초기화되었습니다.', 'success');
    await loadSettings();
  }
}

function showSaveStatus(message, type) {
  const status = document.getElementById('saveStatus');
  status.textContent = message;
  status.className = type;
  
  setTimeout(() => {
    status.className = '';
  }, 3000);
}
