// background.js 테스트 (가짜 chrome API): 패널 설정이 깨어날 때마다 다시 불리지 않는지, 새 액션들, tabId 지정
// 실행: node test/background.test.js
const fs = require("fs"), path = require("path"), vm = require("vm");
let pass = 0, failN = 0;
const check = (n, ok, x) => { ok ? pass++ : failN++; console.log((ok ? "  PASS " : "  FAIL ") + n + (ok ? "" : "  " + (x || ""))); };

function load() {
  const calls = { setOptions: [], behavior: 0, update: [], winUpdate: [], exec: [], sent: [], back: 0, reload: 0, capture: [] };
  const L = () => ({ list: [], addListener(f) { this.list.push(f); }, removeListener(f) { this.list = this.list.filter((x) => x !== f); } });
  const tabs = [
    { id: 11, windowId: 1, title: "lofi - YouTube", url: "https://www.youtube.com/watch?v=x", active: false },
    { id: 12, windowId: 1, title: "choimini", url: "https://github.com/UNTITLED-HUB/choimini", active: true },
    { id: 13, windowId: 1, title: "#general | Discord", url: "https://discord.com/channels/1/2", active: false },
    { id: 14, windowId: 1, title: "Settings", url: "chrome://settings", active: false },
  ];
  const done = (id) => setTimeout(() => ev.updated.list.slice().forEach((f) => f(id, { status: "complete" }, tabs.find((t) => t.id === id) || {})), 5);
  const ev = { installed: L(), startup: L(), msg: L(), activated: L(), updated: L(), focus: L(), clicked: L() };
  const chrome = {
    sidePanel: { setOptions: async (o) => { calls.setOptions.push(o); }, setPanelBehavior: async () => { calls.behavior++; }, open: async () => {} },
    runtime: { onInstalled: ev.installed, onStartup: ev.startup, onMessage: ev.msg, sendMessage: () => Promise.resolve(), getURL: (p) => "chrome-extension://x/" + p },
    tabs: {
      onActivated: ev.activated, onUpdated: ev.updated,
      query: async (q) => q.active ? tabs.filter((t) => t.active) : tabs.slice(),
      get: async (id) => { const t = tabs.find((x) => x.id === id); if (!t) throw new Error("no tab"); return t; },
      update: async (id, o) => { calls.update.push([id, o]); if (o.active) tabs.forEach((t) => t.active = t.id === id); return tabs.find((t) => t.id === id); },
      goBack: async (id) => { calls.back++; done(id); }, goForward: async (id) => { done(id); }, reload: async (id) => { calls.reload++; done(id); },
      captureVisibleTab: async (w, o) => { calls.capture.push(o); return "data:image/jpeg;base64,AAAA"; },
      sendMessage: async (id, m) => { calls.sent.push([id, m.action]); return { ok: true, result: { text: "page of " + id } }; },
      create: async (o) => ({ id: 99, url: o.url }),
    },
    windows: { onFocusChanged: ev.focus, update: async (id, o) => { calls.winUpdate.push([id, o]); } },
    action: { onClicked: ev.clicked },
    permissions: { contains: async () => true },
    scripting: { executeScript: async (o) => { calls.exec.push(o); return o.func ? [{ result: o.func.name === "consoleHook" ? { installed: calls.exec.filter((e) => e.func).length === 1, logs: [{ level: "error", text: "boom" }] } : null }] : [{}]; } },
  };
  vm.runInNewContext(fs.readFileSync(path.join(__dirname, "..", "background.js"), "utf8"), { chrome, console, setTimeout, clearTimeout, URL, Promise });
  const handler = ev.msg.list.find((f) => f.toString().includes("BROWSER_ACTION"));
  const act = (action, args) => new Promise((res) => handler({ type: "BROWSER_ACTION", action, args }, {}, res));
  return { calls, ev, act, tabs };
}

(async () => {
  const B = load();
  check("서비스 워커가 깨어날 때 패널 설정을 다시 하지 않음 (탭 이동 시 패널 닫힘 원인)", B.calls.setOptions.length === 0 && B.calls.behavior === 0, JSON.stringify(B.calls.setOptions));
  B.ev.installed.list.forEach((f) => f()); await new Promise((r) => setTimeout(r, 10));
  check("설치 때만 설정, path 없이 (열린 패널을 다시 로드하지 않음)", B.calls.setOptions.length === 1 && !("path" in B.calls.setOptions[0]) && B.calls.setOptions[0].enabled === true);
  B.ev.activated.list.forEach((f) => f({ tabId: 11 })); await new Promise((r) => setTimeout(r, 10));
  check("탭 전환해도 setOptions 안 부름", B.calls.setOptions.length === 1);

  let r = await B.act("list_tabs", {});
  check("list_tabs: http 탭만 + windowId/active", r.ok && r.result.length === 3 && r.result[1].active && r.result[0].windowId === 1, JSON.stringify(r));
  r = await B.act("current_tab", {});
  check("current_tab 지원 (예전엔 UNKNOWN_ACTION)", r.ok && r.result.id === 12, JSON.stringify(r));
  r = await B.act("read_text", { tabId: 11 });
  check("tabId 로 보지 않는 탭(YouTube) 읽기 + 어느 탭인지 결과에 표시", r.ok && B.calls.sent.slice(-1)[0][0] === 11 && r.result.tab.id === 11 && /YouTube/.test(r.result.tab.title), JSON.stringify(r));
  r = await B.act("read_text", {});
  check("tabId 없으면 지금 보는 탭(GitHub)", r.ok && B.calls.sent.slice(-1)[0][0] === 12);
  r = await B.act("read_text", { tabId: 14 });
  check("chrome:// 탭은 거부", !r.ok, JSON.stringify(r));
  r = await B.act("screenshot", { tabId: 11 });
  check("보이지 않는 탭 screenshot → switch_tab 안내", !r.ok && r.error === "NOT_VISIBLE" && /switch_tab/.test(r.message));
  r = await B.act("screenshot", {});
  check("screenshot 지원 + 고화질 JPEG", r.ok && /^data:image\/jpeg/.test(r.result.dataUrl) && B.calls.capture[0].quality >= 85, JSON.stringify(B.calls.capture));
  r = await B.act("switch_tab", { tabId: 13 });
  check("switch_tab → 탭 활성화 + 창 포커스", r.ok && B.calls.update.some((u) => u[0] === 13 && u[1].active) && B.calls.winUpdate.length === 1);
  r = await B.act("read_console", {});
  check("read_console: 처음엔 수집 시작 안내 (MAIN world)", r.ok && /모아요/.test(r.result.note) && B.calls.exec.slice(-1)[0].world === "MAIN", JSON.stringify(r));
  r = await B.act("read_console", {});
  check("read_console: 두 번째엔 로그 반환", r.ok && r.result.logs.length === 1 && r.result.logs[0].text === "boom");
  r = await B.act("Refresh", {});
  check("별칭(Refresh → reload) + 대소문자", r.ok && B.calls.reload === 1, JSON.stringify(r));
  r = await B.act("back", {});
  check("back", r.ok && B.calls.back === 1);
  r = await B.act("fly", {});
  check("모르는 액션 → 가능한 목록 안내", !r.ok && /switch_tab/.test(r.message));
  console.log("\n" + pass + " passed, " + failN + " failed");
  process.exit(failN ? 1 : 0);
})();
