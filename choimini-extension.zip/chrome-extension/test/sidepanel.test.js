// 확장 사이드 패널 테스트 (jsdom): 로그인 강제, 위조 메시지 무시, 정지, 페이지 제어 전달, Google 로그인(실제 탭), 사이트 버전 감지
// 실행: NODE_PATH=<jsdom 경로> node test/sidepanel.test.js
const { JSDOM } = require("jsdom"), fs = require("fs"), path = require("path");
const root = path.join(__dirname, "..");
const SITE = "https://untitled-hub.github.io/choimini/", ORIGIN = "https://untitled-hub.github.io";
let pass = 0, failN = 0;
const check = (n, ok, x) => { ok ? pass++ : failN++; console.log((ok ? "  PASS " : "  FAIL ") + n + (ok ? "" : "  " + (x || ""))); };
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

async function makePanel() {
  const t = { sent: [], toSite: [], created: [], removed: [], updated: [], removedCb: [], nextTabId: 100 };
  const html = fs.readFileSync(path.join(root, "sidepanel.html"), "utf8").replace(/<script src="[^"]+"><\/script>/g, "");
  const dom = new JSDOM(html, { url: "chrome-extension://abc/sidepanel.html", runScripts: "outside-only", pretendToBeVisual: true });
  const w = dom.window;
  w.chrome = {
    permissions: { contains: async () => true, request: async () => true, onAdded: { addListener() {} }, onRemoved: { addListener() {} } },
    runtime: { sendMessage: (m, cb) => { t.sent.push(m); cb({ ok: true, result: { title: "T" } }); } },
    tabs: {
      create: (o, cb) => { t.created.push(o.url); const tab = { id: t.nextTabId++ }; if (cb) cb(tab); },
      remove: (id) => t.removed.push(id),
      onUpdated: { addListener: (f) => t.updated.push(f) },
      onRemoved: { addListener: (f) => t.removedCb.push(f) },
    },
  };
  w.CHOIMINI_SITE_URL = SITE;
  const frame = w.document.getElementById("frame");
  w.eval(fs.readFileSync(path.join(root, "sidepanel.js"), "utf8"));            // (frame.src 를 설정하면 contentWindow 가 새로 만들어지므로)
  frame.contentWindow.postMessage = (msg) => t.toSite.push(msg);              // 실행 "후"에 사이트로 나가는 메시지를 가로채서 관찰
  await sleep(100);
  const fromSite = (data, opts = {}) => w.dispatchEvent(new w.MessageEvent("message", { data, origin: opts.origin || ORIGIN, source: opts.source === undefined ? frame.contentWindow : opts.source }));
  const req = async (id, action) => { const before = t.toSite.length; fromSite({ source: "choimini-web", type: "browser-request", id, action, args: {} }); await sleep(60); return t.toSite.slice(before).find((m) => m.type === "browser-response" && m.id === id); };
  const status = () => w.document.getElementById("status").textContent;
  const fire = (id, url) => t.updated.forEach((f) => f(id, { url }, { id, url }));
  return Object.assign(t, { w, frame, fromSite, req, status, fire });
}

(async () => {
  let P = await makePanel();
  let { toSite, sent, fromSite, req, status, w } = P;

  console.log("\n[1] Not logged in");
  check("status says login required", /로그인 필요/.test(status()), status());
  let r = await req("a1", "snapshot");
  check("page control request is REFUSED (NOT_LOGGED_IN) and never reaches the browser", r && r.ok === false && r.error === "NOT_LOGGED_IN" && sent.length === 0, JSON.stringify(r) + " sent=" + sent.length);
  check("the site is told control is disabled", toSite.some((m) => m.type === "browser-ready" && m.enabled === false));

  console.log("\n[2] Forged login reports are ignored");
  fromSite({ source: "choimini-web", type: "auth", loggedIn: true }, { origin: "https://evil.example" }); await sleep(50);
  check("'logged in' from ANOTHER origin is ignored", /로그인 필요/.test(status()));
  fromSite({ source: "choimini-web", type: "auth", loggedIn: true }, { source: null }); await sleep(50);
  check("'logged in' not coming from our iframe is ignored", /로그인 필요/.test(status()));
  r = await req("a2", "snapshot"); check("still refused after the forged attempts", r && r.error === "NOT_LOGGED_IN" && sent.length === 0);

  console.log("\n[3] Logged in");
  fromSite({ source: "choimini-web", type: "auth", loggedIn: true }); await sleep(80);
  check("status: page control is on", /켜짐/.test(status()), status());
  r = await req("b1", "snapshot");
  check("request is forwarded to the browser and the result returned", r && r.ok === true && sent.length === 1 && sent[0].type === "BROWSER_ACTION" && sent[0].action === "snapshot", JSON.stringify(r));
  check("site is told control is enabled", toSite.filter((m) => m.type === "browser-ready").pop().enabled === true);

  console.log("\n[3b] Stop button");
  w.document.getElementById("stopBtn").click(); await sleep(50);
  r = await req("b2", "snapshot"); check("paused → refused (PAUSED)", r && r.error === "PAUSED" && sent.length === 1, JSON.stringify(r));
  w.document.getElementById("stopBtn").click(); await sleep(50);
  r = await req("b3", "snapshot"); check("resumed → works again", r && r.ok === true && sent.length === 2);

  console.log("\n[4] Logout");
  fromSite({ source: "choimini-web", type: "auth", loggedIn: false }); await sleep(80);
  check("status back to login required + site told control is disabled", /로그인 필요/.test(status()) && toSite.filter((m) => m.type === "browser-ready").pop().enabled === false);
  r = await req("c1", "snapshot"); check("requests refused again after logout", r && r.error === "NOT_LOGGED_IN" && sent.length === 2);

  console.log("\n[5] Request hygiene");
  const n = toSite.length; fromSite({ source: "choimini-web", type: "browser-request", id: "x", action: "snapshot" }, { origin: "https://evil.example" }); await sleep(60);
  check("browser requests from another origin get no answer at all", toSite.length === n);

  console.log("\n[6] Google login opens in a REAL tab (Google refuses to load inside an iframe)");
  const SB = "https://cfozaatwytsitimvjkyz.supabase.co/auth/v1/authorize?provider=google&redirect_to=" + encodeURIComponent(SITE) + "&code_challenge=abc";
  fromSite({ source: "choimini-web", type: "open-auth", url: SB }); await sleep(60);
  check("a valid Supabase login URL from the site is opened in a new tab", P.created.length === 1 && P.created[0] === SB, JSON.stringify(P.created));
  const tabId = P.nextTabId - 1;
  for (const bad of ["http://cfozaatwytsitimvjkyz.supabase.co/auth/v1/authorize?x=1", "https://evil.example/auth/v1/authorize", "https://cfozaatwytsitimvjkyz.supabase.co/rest/v1/secrets", "javascript:alert(1)", "https://accounts.google.com/o/oauth2/v2/auth", "not a url", "https://evil.supabase.co.evil.example/auth/v1/authorize"]) fromSite({ source: "choimini-web", type: "open-auth", url: bad });
  await sleep(60);
  check("anything else is NOT opened (http, other hosts, javascript:, non-authorize paths, look-alike hosts)", P.created.length === 1, JSON.stringify(P.created));
  fromSite({ source: "choimini-web", type: "open-auth", url: SB }, { origin: "https://evil.example" }); await sleep(40);
  check("open-auth from another origin is ignored", P.created.length === 1);

  const cbCount = () => toSite.filter((m) => m.type === "auth-callback").length;
  P.fire(tabId, "https://accounts.google.com/signin/v2/identifier?x=1"); P.fire(tabId, "https://cfozaatwytsitimvjkyz.supabase.co/auth/v1/callback?code=INTERNAL");
  check("while the tab is still on Google/Supabase nothing is forwarded", cbCount() === 0 && P.removed.length === 0);
  P.fire(999, SITE + "?code=OTHERTAB"); check("codes from a tab we did not open are ignored", cbCount() === 0);
  P.fire(tabId, "https://evil.example/choimini/?code=EVIL"); check("a look-alike page (other origin) is ignored", cbCount() === 0);
  P.fire(tabId, SITE + "?code=GOOD123");
  const cb = toSite.filter((m) => m.type === "auth-callback");
  check("back on the site with ?code → the iframe receives choimini://auth-callback?code=…", cb.length === 1 && cb[0].url === "choimini://auth-callback?code=GOOD123", JSON.stringify(cb));
  check("the login tab is closed afterwards", P.removed.length === 1 && P.removed[0] === tabId);
  P.fire(tabId, SITE + "?code=REPLAY"); check("a second code (replay) is ignored", cbCount() === 1);

  fromSite({ source: "choimini-web", type: "open-auth", url: SB }); await sleep(40);
  const t2 = P.nextTabId - 1; P.fire(t2, SITE + "?error=access_denied&error_description=User%20cancelled");
  check("a cancelled login is reported to the site (auth-error) and the tab closes", toSite.some((m) => m.type === "auth-error" && /cancelled/i.test(m.message)) && P.removed.includes(t2));
  fromSite({ source: "choimini-web", type: "open-auth", url: SB }); await sleep(40);
  const t3 = P.nextTabId - 1; P.removedCb.forEach((f) => f(t3)); P.fire(t3, SITE + "?code=AFTERCLOSE");
  check("if you close the login tab yourself, a later code is ignored", cbCount() === 1);

  console.log("\n[7] A site that is still the OLD version (never reports its login state)");
  P = await makePanel();
  check("right after start it does not accuse the site yet", !/사이트 업데이트 필요/.test(P.status()), P.status());
  await sleep(8400);
  check("after 8s of silence the status says the site needs updating (instead of a misleading 'login required')", /사이트 업데이트 필요/.test(P.status()), P.status());
  P.fromSite({ source: "choimini-web", type: "auth", loggedIn: false }); await sleep(60);
  check("as soon as the site reports, that message goes away", !/사이트 업데이트 필요/.test(P.status()) && /로그인 필요/.test(P.status()), P.status());

  console.log(`\n${pass} passed, ${failN} failed`);
  process.exit(failN ? 1 : 0);
})();
