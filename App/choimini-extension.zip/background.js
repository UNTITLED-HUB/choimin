// Chrome in Choimini — 백그라운드 서비스 워커 (MV3)
//  1) 아이콘 클릭 → 사이드 패널
//  2) 사이드 패널이 보낸 "브라우저 제어" 요청을 활성 탭에 전달
//     - navigate / new_tab / list_tabs : 여기서 직접 처리
//     - 그 외(snapshot/click/type/...)  : agent.js를 주입하고 콘텐츠 스크립트로 전달

// 사이드 패널은 "창 전체(전역)" 패널로 고정한다. 탭별(tabId) 설정을 쓰면 다른 탭으로 갔다 올 때 패널이 닫힌다.
// ⚠ 1.3.0 까지는 서비스 워커가 깨어날 때마다(다른 탭으로 이동 → tabs.onActivated 로 깨어남) setOptions({path}) 를 다시 불렀다.
//    열려 있는 패널에 path 를 다시 설정하면 패널이 새로 로드/닫혀서 "다른 탭 갔다 오면 닫힘" 이 생겼다.
//    → 설치/브라우저 시작 때 한 번만, path 없이(경로는 manifest 의 default_path) 설정한다.
function setupPanel() {
  chrome.sidePanel.setOptions({ enabled: true }).catch((e) => console.error(e));
  chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }).catch((e) => console.error(e));
}
chrome.runtime.onInstalled.addListener(setupPanel);
chrome.runtime.onStartup.addListener(setupPanel);

// 지금 보고 있는 탭을 사이드 패널(→ 사이트)에 실시간으로 알린다. 탭을 옮겨도 패널은 그대로 유지된다.
function tabInfo(tab) { return tab ? { id: tab.id, windowId: tab.windowId, title: tab.title || "", url: tab.url || "" } : null; }
async function broadcastCurrentTab() {
  try {
    const [tab] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
    if (tab) chrome.runtime.sendMessage({ type: "CURRENT_TAB", tab: tabInfo(tab) }).catch(() => {});
  } catch (_) {}
}
chrome.tabs.onActivated.addListener(() => broadcastCurrentTab());
chrome.tabs.onUpdated.addListener((id, info, tab) => { if (tab.active && (info.status === "complete" || info.title || info.url)) broadcastCurrentTab(); });
chrome.windows.onFocusChanged.addListener(() => broadcastCurrentTab());
chrome.runtime.onMessage.addListener((m, _s, send) => { if (m && m.type === "GET_CURRENT_TAB") { chrome.tabs.query({ active: true, lastFocusedWindow: true }).then(([t]) => send({ tab: tabInfo(t) })).catch(() => send({ tab: null })); return true; } });

chrome.action.onClicked.addListener(async (tab) => {
  try { await chrome.sidePanel.open({ windowId: tab.windowId }); }
  catch (e) { chrome.tabs.create({ url: chrome.runtime.getURL("sidepanel.html") }); }
});

const AGENT_ACTIONS = new Set(["snapshot", "read_text", "click", "type", "select", "check", "submit", "scroll", "wait"]);
// 모델이 조금 다른 이름을 써도 알아듣게 (사이트도 정리해서 보내지만 예전 사이트 대비)
const ALIAS = { open: "navigate", goto: "navigate", go: "navigate", visit: "navigate", open_tab: "new_tab", tabs: "list_tabs", get_tabs: "list_tabs",
  active_tab: "current_tab", read: "read_text", get_text: "read_text", text: "read_text", dom: "snapshot", capture: "screenshot", console: "read_console",
  activate_tab: "switch_tab", focus_tab: "switch_tab", select_tab: "switch_tab", go_back: "back", go_forward: "forward", refresh: "reload" };

function isHttp(url) { try { const p = new URL(url).protocol; return p === "http:" || p === "https:"; } catch (_) { return false; } }

async function activeTab() {
  const [tab] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
  if (!tab) throw new Error("활성 탭이 없어요.");
  if (!isHttp(tab.url || "")) throw new Error("이 페이지는 제어할 수 없어요 (chrome:// 등 브라우저 내부 페이지). 일반 웹페이지를 열어주세요.");
  return tab;
}
// args.tabId 가 있으면 그 탭(보고 있지 않은 탭도 가능), 없으면 지금 보고 있는 탭
async function targetTab(args) {
  if (args && args.tabId != null && args.tabId !== "") {
    let tab; try { tab = await chrome.tabs.get(Number(args.tabId)); } catch (_) { throw new Error("tabId " + args.tabId + " 탭이 없어요. list_tabs 로 다시 확인하세요."); }
    if (!isHttp(tab.url || "")) throw new Error("이 탭은 제어할 수 없어요 (브라우저 내부 페이지).");
    return tab;
  }
  return activeTab();
}

// 페이지 콘솔 로그 수집기: 페이지 자체(MAIN world)의 console 을 감싸서 최근 300개를 보관한다
function consoleHook() {
  if (!window.__choiminiConsole) {
    const buf = window.__choiminiConsole = [];
    const fmt = (a) => { try { return typeof a === "string" ? a : a instanceof Error ? (a.stack || a.message) : JSON.stringify(a); } catch (_) { return String(a); } };
    ["log", "info", "warn", "error", "debug"].forEach((lv) => {
      const orig = console[lv];
      console[lv] = function () { try { buf.push({ level: lv, t: Date.now(), text: Array.prototype.map.call(arguments, fmt).join(" ").slice(0, 2000) }); if (buf.length > 300) buf.shift(); } catch (_) {} return orig.apply(this, arguments); };
    });
    window.addEventListener("error", (e) => { buf.push({ level: "error", t: Date.now(), text: String(e.message) + (e.filename ? " (" + e.filename + ":" + e.lineno + ")" : "") }); });
    window.addEventListener("unhandledrejection", (e) => { buf.push({ level: "error", t: Date.now(), text: "Unhandled rejection: " + String(e.reason && (e.reason.stack || e.reason.message) || e.reason) }); });
    return { installed: true, logs: [] };
  }
  return { installed: false, logs: window.__choiminiConsole.slice() };
}

function waitForComplete(tabId, timeoutMs = 15000) {
  return new Promise((resolve) => {
    const done = () => { chrome.tabs.onUpdated.removeListener(onUpd); clearTimeout(t); resolve(); };
    const onUpd = (id, info) => { if (id === tabId && info.status === "complete") done(); };
    const t = setTimeout(done, timeoutMs);
    chrome.tabs.onUpdated.addListener(onUpd);
  });
}

async function hasHostAccess() {
  return chrome.permissions.contains({ origins: ["<all_urls>"] });
}

async function handleBrowserAction(action, args) {
  args = args || {};

  if (!(await hasHostAccess())) {
    return { ok: false, error: "NO_PERMISSION", message: "사이드 패널의 '페이지 제어 허용' 버튼을 먼저 눌러주세요." };
  }

  action = ALIAS[String(action || "").toLowerCase()] || String(action || "").toLowerCase();

  if (action === "list_tabs") {
    const all = !!args.all_windows;
    const tabs = await chrome.tabs.query(all ? {} : { lastFocusedWindow: true });
    return { ok: true, result: tabs.filter((t) => isHttp(t.url || "")).map((t) => ({ id: t.id, windowId: t.windowId, title: t.title, url: t.url, active: t.active })) };
  }

  if (action === "current_tab") {
    const [tab] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
    return tab ? { ok: true, result: tabInfo(tab) } : { ok: false, error: "NO_TAB", message: "활성 탭이 없어요." };
  }

  if (action === "switch_tab") { // 다른 탭으로 화면 전환 (사용자가 보는 탭이 바뀐다)
    const tab = await targetTab(args).catch((e) => { throw e; });
    await chrome.tabs.update(tab.id, { active: true });
    try { await chrome.windows.update(tab.windowId, { focused: true }); } catch (_) {}
    return { ok: true, result: tabInfo(tab) };
  }

  if (action === "back" || action === "forward" || action === "reload") {
    const tab = await targetTab(args);
    if (action === "back") await chrome.tabs.goBack(tab.id); else if (action === "forward") await chrome.tabs.goForward(tab.id); else await chrome.tabs.reload(tab.id);
    await waitForComplete(tab.id, 10000);
    const t2 = await chrome.tabs.get(tab.id);
    return { ok: true, result: tabInfo(t2) };
  }

  if (action === "screenshot") { // 보이는 화면 캡처. 고화질 JPEG(글자 구분 가능), AI 에게도 이미지로 전달된다
    const tab = await targetTab(args);
    if (!tab.active) return { ok: false, error: "NOT_VISIBLE", message: "보이는 탭만 캡처할 수 있어요. 먼저 {\"action\":\"switch_tab\",\"tabId\":" + tab.id + "} 로 이동하세요." };
    const dataUrl = await chrome.tabs.captureVisibleTab(tab.windowId, { format: "jpeg", quality: 90 });
    return { ok: true, result: { dataUrl, tabId: tab.id, url: tab.url, title: tab.title } };
  }

  if (action === "read_console") {
    const tab = await targetTab(args);
    const [r] = await chrome.scripting.executeScript({ target: { tabId: tab.id }, world: "MAIN", func: consoleHook });
    const v = (r && r.result) || { installed: true, logs: [] };
    const logs = (v.logs || []).slice(-Math.min(Math.max(Number(args.limit) || 100, 1), 300));
    return { ok: true, result: { tabId: tab.id, url: tab.url, logs, note: v.installed ? "지금부터 콘솔 로그를 모아요. 문제를 재현(새로고침·클릭 등)한 뒤 read_console 을 다시 부르세요." : (logs.length ? "" : "아직 기록된 로그가 없어요.") } };
  }

  if (action === "navigate" || action === "new_tab") {
    if (!isHttp(args.url)) return { ok: false, error: "BAD_URL", message: "http(s) 주소만 열 수 있어요." };
    let tab;
    if (action === "new_tab") tab = await chrome.tabs.create({ url: args.url });
    else { const cur = await activeTab().catch(() => null); tab = cur ? await chrome.tabs.update(cur.id, { url: args.url }) : await chrome.tabs.create({ url: args.url }); }
    await waitForComplete(tab.id);
    return { ok: true, result: { tabId: tab.id, url: args.url } };
  }

  if (!AGENT_ACTIONS.has(action)) return { ok: false, error: "UNKNOWN_ACTION", message: "지원하지 않는 액션: " + action + " (가능: navigate new_tab list_tabs current_tab switch_tab back forward reload screenshot read_console snapshot read_text click type select check submit scroll wait)" };

  const tab = await targetTab(args);
  await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ["agent.js"] });
  const resp = await chrome.tabs.sendMessage(tab.id, { target: "choimini-agent", action, args });
  if (!resp) return { ok: false, error: "NO_RESPONSE" };
  if (!resp.ok) return { ok: false, error: "AGENT_ERROR", message: resp.error };
  // 어느 탭에서 실행했는지 함께 알려 준다(여러 탭이 열려 있을 때 헷갈리지 않게)
  const result = (resp.result && typeof resp.result === "object" && !Array.isArray(resp.result)) ? Object.assign({ tab: { id: tab.id, title: tab.title, url: tab.url } }, resp.result) : resp.result;
  return { ok: true, result };
}

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (!msg || msg.type !== "BROWSER_ACTION") return;
  handleBrowserAction(msg.action, msg.args)
    .then(sendResponse)
    .catch((e) => sendResponse({ ok: false, error: "EXCEPTION", message: String(e && e.message || e) }));
  return true;
});
