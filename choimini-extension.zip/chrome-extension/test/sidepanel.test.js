// 확장 사이드 패널 테스트 (jsdom): 로그인 강제, 위조 메시지 무시, 정지, 페이지 제어 전달
// 실행: NODE_PATH=<jsdom 경로> node test/sidepanel.test.js
const { JSDOM } = require("jsdom"), fs = require("fs"), path = require("path");
const root = path.join(__dirname, "..");
let pass = 0, failN = 0;
const check = (n, ok, x) => { ok ? pass++ : failN++; console.log((ok ? "  PASS " : "  FAIL ") + n + (ok ? "" : "  " + (x || ""))); };
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

(async () => {
  const SITE = "https://untitled-hub.github.io/choimini/", ORIGIN = "https://untitled-hub.github.io";
  const sent = [], toSite = []; let hasHostPerm = true;
  const html = fs.readFileSync(path.join(root, "sidepanel.html"), "utf8").replace(/<script src="[^"]+"><\/script>/g, "");
  const dom = new JSDOM(html, { url: "chrome-extension://abc/sidepanel.html", runScripts: "outside-only", pretendToBeVisual: true });
  const w = dom.window;
  w.chrome = {
    permissions: { contains: async () => hasHostPerm, request: async () => true, onAdded: { addListener() {} }, onRemoved: { addListener() {} } },
    runtime: { sendMessage: (m, cb) => { sent.push(m); cb({ ok: true, result: { title: "T" } }); } },
    tabs: { create() {} },
  };
  w.CHOIMINI_SITE_URL = SITE;
  const frame = w.document.getElementById("frame");
  w.eval(fs.readFileSync(path.join(root, "sidepanel.js"), "utf8"));         // (frame.src 를 설정하면 contentWindow 가 새로 만들어지므로)
  frame.contentWindow.postMessage = (msg) => toSite.push(msg);           // 실행 "후"에 사이트로 나가는 메시지를 가로채서 관찰
  await sleep(100);

  const fromSite = (data, opts = {}) => w.dispatchEvent(new w.MessageEvent("message", { data, origin: opts.origin || ORIGIN, source: opts.source === undefined ? frame.contentWindow : opts.source }));
  const req = async (id, action) => { const before = toSite.length; fromSite({ source: "choimini-web", type: "browser-request", id, action, args: {} }); await sleep(60); return toSite.slice(before).find((m) => m.type === "browser-response" && m.id === id); };
  const status = () => w.document.getElementById("status").textContent;

  console.log("\n[1] Not logged in");
  check("status says login required", /로그인 필요/.test(status()), status());
  let r = await req("a1", "snapshot");
  check("page control request is REFUSED (NOT_LOGGED_IN) and never reaches the browser", r && r.ok === false && r.error === "NOT_LOGGED_IN" && sent.length === 0, JSON.stringify(r) + " sent=" + sent.length);
  check("the site is told control is disabled", toSite.some((m) => m.type === "browser-ready" && m.enabled === false));

  console.log("\n[2] Forged login reports are ignored");
  fromSite({ source: "choimini-web", type: "auth", loggedIn: true }, { origin: "https://evil.example" }); await sleep(50);
  check("'logged in' from ANOTHER origin is ignored", /로그인 필요/.test(status()));
  fromSite({ source: "choimini-web", type: "auth", loggedIn: true }, { source: null }); await sleep(50);
  check("'logged in' not coming from our iframe is ignored", /로그인 필요/.test(status()));
  r = await req("a2", "snapshot"); check("still refused after the forged attempts", r && r.error === "NOT_LOGGED_IN" && sent.length === 0);

  console.log("\n[3] Logged in");
  fromSite({ source: "choimini-web", type: "auth", loggedIn: true }); await sleep(80);
  check("status: page control is on", /켜짐/.test(status()), status());
  r = await req("b1", "snapshot");
  check("request is forwarded to the browser and the result returned", r && r.ok === true && sent.length === 1 && sent[0].type === "BROWSER_ACTION" && sent[0].action === "snapshot", JSON.stringify(r));
  check("site is told control is enabled", toSite.filter((m) => m.type === "browser-ready").pop().enabled === true);

  console.log("\n[3b] Stop button");
  w.document.getElementById("stopBtn").click(); await sleep(50);
  r = await req("b2", "snapshot"); check("paused → refused (PAUSED)", r && r.error === "PAUSED" && sent.length === 1, JSON.stringify(r));
  w.document.getElementById("stopBtn").click(); await sleep(50);
  r = await req("b3", "snapshot"); check("resumed → works again", r && r.ok === true && sent.length === 2);

  console.log("\n[4] Logout");
  fromSite({ source: "choimini-web", type: "auth", loggedIn: false }); await sleep(80);
  check("status back to login required + site told control is disabled", /로그인 필요/.test(status()) && toSite.filter((m) => m.type === "browser-ready").pop().enabled === false);
  r = await req("c1", "snapshot"); check("requests refused again after logout", r && r.error === "NOT_LOGGED_IN" && sent.length === 2);

  console.log("\n[5] Request hygiene");
  const n = toSite.length; fromSite({ source: "choimini-web", type: "browser-request", id: "x", action: "snapshot" }, { origin: "https://evil.example" }); await sleep(60);
  check("browser requests from another origin get no answer at all", toSite.length === n);

  console.log(`\n${pass} passed, ${failN} failed`);
  process.exit(failN ? 1 : 0);
})();
