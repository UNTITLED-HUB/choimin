// Chrome in Choimini — 페이지 제어 에이전트 (콘텐츠 스크립트, 필요할 때만 주입됨)
// 지원 액션: snapshot, click, type, select, check, submit, scroll, wait, read_text
//
// 안전 규칙 (이 파일에서 강제 — 웹사이트/모델이 우회 못 함):
//  1) 비밀번호·카드번호·CVV·OTP 필드에는 절대 입력하지 않는다 (사용자가 직접 입력).
//  2) 제출(submit 버튼 클릭 / form 제출)은 args.confirmed === true 일 때만 실행한다.
//     아니면 needsConfirmation + 요약(요청 대상 도메인, 채워진 필드 라벨)만 돌려준다.
(function () {
  if (window.__choiminiAgentInstalled) return;
  window.__choiminiAgentInstalled = true;

  const refs = new Map(); // "e1" -> Element
  let refSeq = 0;

  const SENSITIVE_RE = /pass(word)?|pwd|cvv|cvc|card.?(num|no)|cc-?(num|csc|exp)|otp|one.?time|security.?code|pin\b|ssn|주민|비밀번호|카드번호/i;

  function isVisible(el) {
    const r = el.getBoundingClientRect();
    if (r.width === 0 || r.height === 0) return false;
    const st = getComputedStyle(el);
    return st.visibility !== "hidden" && st.display !== "none" && st.opacity !== "0";
  }

  const txt = (el) => String((el.innerText != null ? el.innerText : el.textContent) || "").trim();

  function labelOf(el) {
    const aria = el.getAttribute("aria-label");
    if (aria) return aria.trim();
    if (el.id) {
      const l = document.querySelector('label[for="' + CSS.escape(el.id) + '"]');
      if (l) return txt(l);
    }
    const wrap = el.closest("label");
    if (wrap) return txt(wrap);
    return (el.placeholder || el.getAttribute("title") || el.name || "").trim();
  }

  function isSensitive(el) {
    if (el.type === "password") return true;
    const ac = (el.getAttribute("autocomplete") || "");
    if (/^cc-|one-time-code|current-password|new-password/.test(ac)) return true;
    return SENSITIVE_RE.test([el.name, el.id, labelOf(el)].join(" "));
  }

  function isSubmitter(el) {
    if (el.tagName === "INPUT") return el.type === "submit" || el.type === "image";
    if (el.tagName === "BUTTON") return el.type === "submit" || (!el.getAttribute("type") && !!el.form);
    return false;
  }

  function getEl(ref) {
    const el = refs.get(ref);
    if (!el || !el.isConnected) throw new Error("Unknown or stale ref '" + ref + "'. Take a new snapshot.");
    return el;
  }

  function snapshot() {
    refs.clear(); refSeq = 0;
    const sel = 'a[href],button,input,select,textarea,[role="button"],[role="link"],[role="checkbox"],[contenteditable="true"]';
    const out = [];
    document.querySelectorAll(sel).forEach((el) => {
      if (el.type === "hidden" || !isVisible(el)) return;
      if (out.length >= 150) return;
      const ref = "e" + (++refSeq);
      refs.set(ref, el);
      const item = {
        ref, tag: el.tagName.toLowerCase(), type: el.type || el.getAttribute("role") || undefined,
        label: labelOf(el).slice(0, 80),
        text: txt(el).slice(0, 80) || undefined,
        disabled: el.disabled || undefined,
        submit: isSubmitter(el) || undefined,
        sensitive: (el.matches("input,textarea") && isSensitive(el)) || undefined,
      };
      if (el.matches("input,textarea") && !item.sensitive && el.type !== "checkbox" && el.type !== "radio") item.value = String(el.value || "").slice(0, 80);
      if (el.type === "checkbox" || el.type === "radio") item.checked = el.checked;
      if (el.tagName === "SELECT") item.options = Array.from(el.options).slice(0, 40).map((o) => ({ value: o.value, label: o.text.trim() }));
      if (el.tagName === "A") item.href = el.href;
      out.push(item);
    });
    return { url: location.href, title: document.title, elements: out };
  }

  function setNativeValue(el, value) {
    const proto = el.tagName === "TEXTAREA" ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    const setter = Object.getOwnPropertyDescriptor(proto, "value").set;
    setter.call(el, value);
    el.dispatchEvent(new Event("input", { bubbles: true }));
    el.dispatchEvent(new Event("change", { bubbles: true }));
  }

  function formSummary(form) {
    const fields = [];
    if (form) {
      form.querySelectorAll("input,select,textarea").forEach((f) => {
        if (f.type === "hidden" || f.type === "submit" || !isVisible(f)) return;
        const filled = f.type === "checkbox" || f.type === "radio" ? f.checked : !!f.value;
        fields.push({ label: labelOf(f) || f.name || f.type, filled, sensitive: isSensitive(f) || undefined });
      });
    }
    let target = location.origin;
    try { if (form && form.action) target = new URL(form.action, location.href).origin; } catch (_) {}
    return { page: location.href, sendsTo: target, sameOrigin: target === location.origin, fields: fields.slice(0, 30) };
  }

  function requireConfirm(form, args, run) {
    if (args.confirmed !== true) {
      return { needsConfirmation: true, summary: formSummary(form) };
    }
    return run();
  }

  const actions = {
    snapshot,

    read_text() { return { url: location.href, text: (document.body.innerText || "").slice(0, 8000) }; },

    click(args) {
      const el = getEl(args.ref);
      if (isSubmitter(el)) return requireConfirm(el.form, args, () => { el.click(); return { ok: true, submitted: true }; });
      el.scrollIntoView({ block: "center" });
      el.click();
      return { ok: true };
    },

    type(args) {
      const el = getEl(args.ref);
      if (isSensitive(el)) {
        return { ok: false, error: "SENSITIVE_FIELD", message: "이 필드(비밀번호/카드/인증번호 등)는 사용자가 직접 입력해야 해요." };
      }
      el.scrollIntoView({ block: "center" });
      el.focus();
      if (el.isContentEditable) { el.textContent = String(args.text ?? ""); el.dispatchEvent(new Event("input", { bubbles: true })); }
      else setNativeValue(el, String(args.text ?? ""));
      return { ok: true };
    },

    select(args) {
      const el = getEl(args.ref);
      if (el.tagName !== "SELECT") return { ok: false, error: "NOT_SELECT" };
      const want = String(args.value ?? "");
      const opt = Array.from(el.options).find((o) => o.value === want || o.text.trim() === want);
      if (!opt) return { ok: false, error: "NO_SUCH_OPTION" };
      el.value = opt.value;
      el.dispatchEvent(new Event("input", { bubbles: true }));
      el.dispatchEvent(new Event("change", { bubbles: true }));
      return { ok: true };
    },

    check(args) {
      const el = getEl(args.ref);
      const want = args.checked !== false;
      if (el.checked !== want) el.click();
      return { ok: true, checked: el.checked };
    },

    submit(args) {
      const el = getEl(args.ref);
      const form = el.tagName === "FORM" ? el : el.form || el.closest("form");
      if (!form) return { ok: false, error: "NO_FORM" };
      return requireConfirm(form, args, () => {
        if (form.requestSubmit) form.requestSubmit(); else form.submit();
        return { ok: true, submitted: true };
      });
    },

    scroll(args) {
      const dy = Number(args.dy) || Math.round(window.innerHeight * 0.8);
      window.scrollBy({ top: dy, behavior: "instant" });
      return { ok: true, scrollY: Math.round(window.scrollY) };
    },

    wait(args) {
      const ms = Math.min(Math.max(Number(args.ms) || 500, 0), 5000);
      return new Promise((r) => setTimeout(() => r({ ok: true, waitedMs: ms }), ms));
    },
  };

  chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
    if (!msg || msg.target !== "choimini-agent") return;
    Promise.resolve()
      .then(() => {
        const fn = actions[msg.action];
        if (!fn) throw new Error("Unknown action: " + msg.action);
        return fn(msg.args || {});
      })
      .then((result) => sendResponse({ ok: true, result }))
      .catch((e) => sendResponse({ ok: false, error: String(e && e.message || e) }));
    return true; // async
  });
})();
