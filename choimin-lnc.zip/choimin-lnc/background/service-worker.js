// 서비스 워커 - 백그라운드 작업 처리

// 모듈 로드
importScripts('../modules/storage.js');
importScripts('../modules/managers.js');

// 확장앱 설치 시 초기화
chrome.runtime.onInstalled.addListener(async () => {
  const data = await chrome.storage.local.get(null);
  if (!Object.keys(data).length) {
    await chrome.storage.local.set(StorageManager.defaultData);
  }
});

// 탭 업데이트 모니터링 (사이트 접속 이벤트)
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status === 'complete' && tab.url) {
    SiteEventManager.handleUrlChange(tab.url).catch(e => console.error('URL 처리 오류:', e));
  }
});

// 탭 활성화 모니터링
chrome.tabs.onActivated.addListener((activeInfo) => {
  chrome.tabs.get(activeInfo.tabId, (tab) => {
    if (tab && tab.url) {
      SiteEventManager.handleUrlChange(tab.url).catch(e => console.error('URL 처리 오류:', e));
    }
  });
});

// 메시지 수신 처리
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.type === 'getSettings') {
    chrome.storage.local.get(null, (data) => {
      sendResponse(data);
    });
    return true;
  }

  if (request.type === 'keyPress') {
    ShortcutEventManager.handleKeyPress(request.key);
  }

  if (request.type === 'logEvent') {
    StorageManager.addEventLog(request.data).catch(e => console.error('로그 저장 오류:', e));
  }
});
