Choimini Desktop (Windows)
1. 압축을 전부 풀기 2. ChoiminiDesktop.exe 실행
필요: Windows 10/11 + Microsoft Edge WebView2 Runtime
