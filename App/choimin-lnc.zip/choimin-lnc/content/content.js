// 콘텐츠 스크립트 - 페이지에서 실행

let currentRotation = 0;
let replacedImages = new Map();
let observerActive = false;
let extensionEnabled = true;

// 초기화
window.addEventListener('load', init);
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', init);
} else {
  init();
}

function init() {
  loadSettings();
  attachKeyListener();
  setupTitleObserver();
}

// 설정 로드 및 적용
async function loadSettings() {
  chrome.runtime.sendMessage({ type: 'getSettings' }, (response) => {
    if (!response) return;

    extensionEnabled = !!response.enabled;

    // 확장앱이 꺼져있으면 어떤 탭 설정도 적용하지 않는다
    if (!extensionEnabled) return;

    const settings = response.tabSettings || {};

    if (settings.cursorImage) {
      setCursor(settings.cursorImage);
    }

    if (settings.rotation && settings.rotation !== 0) {
      applyRotation(settings.rotation);
    }

    if (settings.replaceImages && settings.replacementImage) {
      replaceImagesOnPage(settings.replacementImage);
    }

    if (settings.pageTitle) {
      setPageTitle(settings.pageTitle);
    }
  });
}

// 키보드 이벤트 수신
function attachKeyListener() {
  document.addEventListener('keydown', (e) => {
    if (!extensionEnabled) return;
    const key = e.key.toUpperCase();
    chrome.runtime.sendMessage({
      type: 'keyPress',
      key: key
    }).catch(() => {});
  });
}

// 메시지 수신
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  switch (request.type) {
    case 'extensionToggled':
      extensionEnabled = !!request.enabled;
      if (extensionEnabled) {
        // 다시 켜지면 저장된 설정을 재적용
        loadSettings();
      } else {
        // 꺼지면 모든 효과를 즉시 원상복구
        revertAllEffects();
      }
      break;

    case 'rotate':
      if (extensionEnabled) applyRotation(request.degree);
      break;

    case 'setCursor':
      if (extensionEnabled) setCursor(request.imageUrl);
      break;

    case 'replaceImages':
      if (extensionEnabled) replaceImagesOnPage(request.imageUrl);
      break;

    case 'restoreImages':
      restoreOriginalImages();
      break;

    case 'setPageTitle':
      if (extensionEnabled) setPageTitle(request.title);
      break;

    case 'resetPageTitle':
      resetPageTitle();
      break;
  }
});

// 확장앱이 꺼졌을 때 모든 효과 원상복구
function revertAllEffects() {
  applyRotation(0);
  removeCursor();
  restoreOriginalImages();
  resetPageTitle();
}

// 화면 회전 적용
function applyRotation(degree) {
  currentRotation = degree;
  const html = document.documentElement;
  const transform = degree === 0 ? 'none' : `rotate(${degree}deg)`;

  html.style.transform = transform;
  html.style.transformOrigin = 'center center';
  html.style.transition = 'transform 0.5s ease';

  if (degree !== 0) {
    html.style.width = '100vw';
    html.style.height = '100vh';
    html.style.overflow = 'hidden';
  } else {
    html.style.width = 'auto';
    html.style.height = 'auto';
    html.style.overflow = 'auto';
  }
}

// 커서 이미지 설정
let cursorStyleEl = null;

function setCursor(imageUrl) {
  try {
    removeCursor();

    const style = document.createElement('style');
    style.id = 'choimin-lnc-cursor-style';
    // 주의: cursor 속성은 url()과 fallback 키워드 사이에 반드시 콤마가 필요합니다.
    // "url('...') auto" (X, 문법 오류로 무시됨) -> "url('...'), auto" (O)
    style.textContent = `
      *, *::before, *::after {
        cursor: url("${imageUrl}") 0 0, auto !important;
      }
    `;
    document.head.appendChild(style);
    cursorStyleEl = style;

    // 이미지 로드 실패 시 기본 커서로 자동 복구
    const testImg = new Image();
    testImg.onerror = () => {
      removeCursor();
    };
    testImg.src = imageUrl;
  } catch (e) {
    console.error('커서 설정 오류:', e);
    removeCursor();
  }
}

function removeCursor() {
  const existing = document.getElementById('choimin-lnc-cursor-style');
  if (existing) {
    existing.remove();
  }
  cursorStyleEl = null;
}

// 이미지 대체
function replaceImagesOnPage(imageUrl) {
  if (observerActive) return;

  // 기존 이미지 저장 및 대체
  document.querySelectorAll('img').forEach(img => {
    if (!replacedImages.has(img)) {
      replacedImages.set(img, img.src);
      img.src = imageUrl;
      img.style.transition = 'opacity 0.3s ease';
    }
  });

  // CSS background-image 대체
  document.querySelectorAll('*').forEach(el => {
    const bg = window.getComputedStyle(el).backgroundImage;
    if (bg && bg !== 'none' && !replacedImages.has(el)) {
      replacedImages.set(el, bg);
      el.style.backgroundImage = `url('${imageUrl}')`;
    }
  });

  // MutationObserver로 동적 이미지 감지
  if (!observerActive) {
    observerActive = true;
    const observer = new MutationObserver((mutations) => {
      if (!extensionEnabled) return;
      mutations.forEach((mutation) => {
        if (mutation.type === 'childList') {
          mutation.addedNodes.forEach((node) => {
            if (node.nodeType === 1) {
              if (node.tagName === 'IMG') {
                replacedImages.set(node, node.src);
                node.src = imageUrl;
              }
            }
          });
        }
      });
    });

    observer.observe(document.body, {
      childList: true,
      subtree: true
    });
  }
}

// 원본 이미지 복구
function restoreOriginalImages() {
  replacedImages.forEach((originalUrl, element) => {
    if (element.tagName === 'IMG') {
      element.src = originalUrl;
    } else {
      element.style.backgroundImage = originalUrl;
    }
  });

  replacedImages.clear();
  observerActive = false;
}

// 페이지 제목 변경
function setPageTitle(title) {
  if (title) {
    window.originalTitle = window.originalTitle || document.title;
    document.title = title;
  }
}

// 페이지 제목 원래대로
function resetPageTitle() {
  if (window.originalTitle) {
    document.title = window.originalTitle;
  }
}

// 제목 변경 감시
function setupTitleObserver() {
  const observer = new MutationObserver((mutations) => {
    if (!extensionEnabled) return;
    mutations.forEach((mutation) => {
      if (mutation.type === 'characterData') {
        chrome.runtime.sendMessage({ type: 'getSettings' }, (response) => {
          if (response && response.enabled && response.tabSettings && response.tabSettings.pageTitle) {
            document.title = response.tabSettings.pageTitle;
          }
        });
      }
    });
  });

  const titleElement = document.querySelector('title');
  if (titleElement) {
    observer.observe(titleElement, {
      characterData: true,
      subtree: true
    });
  }
}
