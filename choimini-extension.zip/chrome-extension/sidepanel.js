// 사이드 패널: 최미나이 사이트(iframe) ↔ 확장(백그라운드) 브리지
//
// 프로토콜 (postMessage, origin 엄격 검사):
//   사이트 → 확장 : { source:"choimini-web", type:"browser-request", id, action, args }
//   확장 → 사이트 : { source:"choimini-ext", type:"browser-response", id, ok, result|error|message,
//                     needsConfirmation?, summary? }
//   확장 → 사이트 : { source:"choimini-ext", type:"browser-ready", enabled }  (로드/권한 변경 시)
//
// 안전장치: ① 페이지 제어는 사용자가 버튼으로 권한을 준 뒤에만  ② "정지" 버튼으로 즉시 차단
//          ③ 양식 제출은 이 패널에서 사용자가 [제출 허용]을 눌러야만 진행(agent.js도 재검증)

const SITE = window.CHOIMINI_SITE_URL;
const SITE_ORIGIN = new URL(SITE).origin;
const frame = document.getElementById("frame");
const fallback = document.getElementById("fallback");
const statusEl = document.getElementById("status");
const permBtn = document.getElementById("permBtn");
const stopBtn = document.getElementById("stopBtn");
const confirmBox = document.getElementById("confirm");
const confirmBody = document.getElementById("confirmBody");

let loaded = false;
let paused = false;
let enabled = false;
let loggedIn = false;   // 사이트(iframe)가 알려주는 Google 로그인 상태. 로그인 안 되면 페이지 제어는 전부 거부한다.
let siteReported = false, siteStale = false;   // 사이트가 로그인 상태를 한 번이라도 보고했는지 (안 하면 사이트가 예전 버전)
const SITE_REPORT_MS = 8000;
setTimeout(() => { if (!siteReported) { siteStale = true; renderStatus(); } }, SITE_REPORT_MS);

/* ---------- 로드 / 폴백 ---------- */
function showFallback() { frame.style.display = "none"; fallback.style.display = "flex"; }
document.getElementById("openTabBtn").addEventListener("click", () => chrome.tabs.create({ url: SITE }));
frame.addEventListener("load", () => { loaded = true; notifyReady(); });
frame.src = SITE + (SITE.includes("?") ? "&" : "?") + "app=chrome"; // choimini-auth.js가 크롬 확장임을 인식
setTimeout(() => { if (!loaded) showFallback(); }, 2500);

/* ---------- 권한 / 상태 ---------- */
async function refreshPerm() {
  enabled = await chrome.permissions.contains({ origins: ["<all_urls>"] });
  permBtn.style.display = enabled ? "none" : "";
  renderStatus();
  notifyReady();
}
function renderStatus(busy) {
  statusEl.className = "st" + (busy ? " busy" : enabled && loggedIn && !paused ? " on" : "");
  statusEl.textContent = busy ? "작업 중: " + busy
    : !loggedIn && siteStale ? "사이트 업데이트 필요 (index.html)"
    : !loggedIn ? "로그인 필요"
    : !enabled ? "페이지 제어: 꺼짐"
    : paused ? "페이지 제어: 정지됨" : "페이지 제어: 켜짐";
}
permBtn.addEventListener("click", async () => {
  await chrome.permissions.request({ origins: ["<all_urls>"] }); // 사용자 클릭으로만 요청 가능
  refreshPerm();
});
stopBtn.addEventListener("click", () => {
  paused = !paused;
  stopBtn.textContent = paused ? "재개" : "정지";
  stopBtn.classList.toggle("paused", paused);
  renderStatus();
  notifyReady();
});
chrome.permissions.onAdded.addListener(refreshPerm);
chrome.permissions.onRemoved.addListener(refreshPerm);
refreshPerm();

function post(msg) {
  if (frame.contentWindow) frame.contentWindow.postMessage(Object.assign({ source: "choimini-ext" }, msg), SITE_ORIGIN);
}
function notifyReady() { post({ type: "browser-ready", enabled: enabled && loggedIn && !paused }); }

/* ---------- 요청 처리 ---------- */
function askConfirm(summary) {
  return new Promise((resolve) => {
    const fields = (summary.fields || []).map((f) =>
      "<li>" + esc(f.label) + (f.sensitive ? " 🔒(민감)" : "") + " — " + (f.filled ? "입력됨" : "비어있음") + "</li>").join("");
    confirmBody.innerHTML =
      "<div>페이지: " + esc(summary.page) + "</div>" +
      "<div>전송 대상: <b>" + esc(summary.sendsTo) + "</b>" + (summary.sameOrigin ? "" : " ⚠ 다른 사이트") + "</div>" +
      "<ul>" + fields + "</ul>";
    confirmBox.classList.add("show");
    const done = (v) => { confirmBox.classList.remove("show"); resolve(v); };
    document.getElementById("allowBtn").onclick = () => done(true);
    document.getElementById("denyBtn").onclick = () => done(false);
  });
}
function esc(s) { return String(s == null ? "" : s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c])); }

function callBackground(action, args) {
  return new Promise((resolve) => chrome.runtime.sendMessage({ type: "BROWSER_ACTION", action, args }, (r) => resolve(r || { ok: false, error: "NO_RESPONSE" })));
}

async function runRequest(msg) {
  if (!loggedIn) return { ok: false, error: "NOT_LOGGED_IN", message: "로그인해야 페이지 제어를 쓸 수 있어요." };
  if (paused) return { ok: false, error: "PAUSED", message: "사용자가 정지했어요." };
  renderStatus(msg.action);
  try {
    let res = await callBackground(msg.action, msg.args);
    // 제출류는 agent.js가 needsConfirmation을 돌려줌 → 사용자 확인 → confirmed:true로 재시도
    if (res.ok && res.result && res.result.needsConfirmation) {
      const allow = await askConfirm(res.result.summary);
      if (!allow) return { ok: false, error: "USER_DENIED", message: "사용자가 제출을 거부했어요." };
      res = await callBackground(msg.action, Object.assign({}, msg.args, { confirmed: true }));
    }
    return res;
  } finally { renderStatus(); }
}

window.addEventListener("message", async (ev) => {
  if (ev.origin !== SITE_ORIGIN || ev.source !== frame.contentWindow) return;
  const m = ev.data;
  if (m && m.source === "choimini-web" && m.type === "auth") { // 사이트가 보고하는 로그인 상태 (origin/source 는 위에서 이미 검사됨)
    siteReported = true; siteStale = false; loggedIn = !!m.loggedIn; renderStatus(); notifyReady(); return;
  }
  if (m && m.source === "choimini-web" && m.type === "open-auth") { openAuthTab(m.url); return; }
  if (!m || m.source !== "choimini-web" || m.type !== "browser-request" || typeof m.action !== "string") return;
  const res = await runRequest(m);
  post({ type: "browser-response", id: m.id, ok: !!res.ok, result: res.result, error: res.error, message: res.message });
});


/* ---------- Google 로그인 (실제 탭에서) ----------
   구글은 iframe 안에서의 로그인 화면을 막는다. 그래서 사이트(iframe)가 구글로 이동하려는 것을 가로채서(nocf.js 또는 새 auth.js)
   이 패널에 알려 주면, 여기서 "실제 탭"으로 로그인 창을 열고, 로그인 후 사이트로 돌아올 때 URL 의 code 를 iframe 에 전달한다.
   (PKCE: code 는 iframe 이 보관한 verifier 가 있어야만 세션으로 바뀌므로, 탭 URL 에 code 가 보여도 다른 곳에선 쓸 수 없다.) */
let authTabId = null;
const SITE_PATH = new URL(SITE).pathname;

function isAuthorizeUrl(u) {
  return u.protocol === "https:" && /\.supabase\.co$/.test(u.hostname) && u.pathname.indexOf("/auth/v1/authorize") === 0;
}
function openAuthTab(raw) {
  let u; try { u = new URL(String(raw)); } catch (_) { return; }
  if (!isAuthorizeUrl(u)) return;                       // 로그인 주소가 아니면 열지 않는다 (사이트가 임의 주소를 열게 하지 못함)
  chrome.tabs.create({ url: u.href, active: true }, (tab) => { authTabId = tab && tab.id != null ? tab.id : null; });
}
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (authTabId === null || tabId !== authTabId) return;
  const url = changeInfo.url || (tab && tab.url);
  if (!url) return;
  let u; try { u = new URL(url); } catch (_) { return; }
  if (u.origin !== SITE_ORIGIN || u.pathname.indexOf(SITE_PATH) !== 0) return;   // 아직 구글/Supabase 단계
  const code = u.searchParams.get("code");
  const err = u.searchParams.get("error_description") || u.searchParams.get("error");
  if (code) {
    post({ type: "auth-callback", url: "choimini://auth-callback?code=" + encodeURIComponent(code) });
    const id = authTabId; authTabId = null; chrome.tabs.remove(id);
  } else if (err) {
    post({ type: "auth-error", message: err });
    const id = authTabId; authTabId = null; chrome.tabs.remove(id);
  }
});
chrome.tabs.onRemoved.addListener((tabId) => { if (tabId === authTabId) authTabId = null; });
