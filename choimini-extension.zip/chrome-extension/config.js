// Choimini 사이트 URL — 배포된 실제 주소로 교체하세요.
// (예: GitHub Pages 주소. 브라우저 연결 시 실제 배포 URL 확인해서 채움)
window.CHOIMINI_SITE_URL = "https://untitled-hub.github.io/choimini/";
