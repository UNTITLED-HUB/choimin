// Chrome in Choimini — 페이지 제어 에이전트 (콘텐츠 스크립트, 필요할 때만 주입됨)
// 지원 액션: snapshot, click, type, select, check, submit, scroll, wait, read_text
//
// 안전 규칙 (이 파일에서 강제 — 웹사이트/모델이 우회 못 함):
//  1) 비밀번호·카드번호·CVV·OTP 필드에는 절대 입력하지 않는다 (사용자가 직접 입력).
//  2) 제출(submit 버튼 클릭 / form 제출)은 args.confirmed === true 일 때만 실행한다.
//     아니면 needsConfirmation + 요약(요청 대상 도메인, 채워진 필드 라벨)만 돌려준다.
(function () {
  if (window.__choiminiAgentInstalled) return;
  window.__choiminiAgentInstalled = true;

  const refs = new Map(); // "e1" -> Element
  let refSeq = 0;

  const SENSITIVE_RE = /pass(word)?|pwd|cvv|cvc|card.?(num|no)|cc-?(num|csc|exp)|otp|one.?time|security.?code|pin\b|ssn|주민|비밀번호|카드번호/i;

  function isVisible(el) {
    const r = el.getBoundingClientRect();
    if (r.width === 0 || r.height === 0) return false;
    const st = getComputedStyle(el);
    return st.visibility !== "hidden" && st.display !== "none" && st.opacity !== "0";
  }

  const txt = (el) => String((el.innerText != null ? el.innerText : el.textContent) || "").trim();

  function labelOf(el) {
    const aria = el.getAttribute("aria-label");
    if (aria) return aria.trim();
    if (el.id) {
      const l = document.querySelector('label[for="' + CSS.escape(el.id) + '"]');
      if (l) return txt(l);
    }
    const wrap = el.closest("label");
    if (wrap) return txt(wrap);
    return (el.placeholder || el.getAttribute("title") || el.name || "").trim();
  }

  function isSensitive(el) {
    if (el.type === "password") return true;
    const ac = (el.getAttribute("autocomplete") || "");
    if (/^cc-|one-time-code|current-password|new-password/.test(ac)) return true;
    return SENSITIVE_RE.test([el.name, el.id, labelOf(el)].join(" "));
  }

  // 실제로 양식을 제출하는 버튼만. (예전엔 <button> 의 기본 type 이 "submit" 이라 양식 밖의 평범한 버튼까지 제출 확인을 요구했다)
  function isSubmitter(el) {
    if (!el.form) return false;
    if (el.tagName === "INPUT") return el.type === "submit" || el.type === "image";
    if (el.tagName === "BUTTON") { const t = (el.getAttribute("type") || "submit").toLowerCase(); return t === "submit"; }
    return false;
  }

  function getEl(ref) {
    const el = refs.get(ref);
    if (!el || !el.isConnected) throw new Error("Unknown or stale ref '" + ref + "'. Take a new snapshot.");
    return el;
  }

  function snapshot() {
    refs.clear(); refSeq = 0;
    const sel = 'a[href],button,input,select,textarea,[role="button"],[role="link"],[role="checkbox"],[contenteditable="true"]';
    const out = [];
    document.querySelectorAll(sel).forEach((el) => {
      if (el.type === "hidden" || !isVisible(el)) return;
      if (out.length >= 150) return;
      const ref = "e" + (++refSeq);
      refs.set(ref, el);
      const item = {
        ref, tag: el.tagName.toLowerCase(), type: el.type || el.getAttribute("role") || undefined,
        label: labelOf(el).slice(0, 80),
        text: txt(el).slice(0, 80) || undefined,
        disabled: el.disabled || undefined,
        submit: isSubmitter(el) || undefined,
        sensitive: (el.matches("input,textarea") && isSensitive(el)) || undefined,
      };
      if (el.matches("input,textarea") && !item.sensitive && el.type !== "checkbox" && el.type !== "radio") item.value = String(el.value || "").slice(0, 80);
      if (el.type === "checkbox" || el.type === "radio") item.checked = el.checked;
      if (el.tagName === "SELECT") item.options = Array.from(el.options).slice(0, 40).map((o) => ({ value: o.value, label: o.text.trim() }));
      if (el.tagName === "A") item.href = el.href;
      out.push(item);
    });
    return { url: location.href, title: document.title, elements: out };
  }

  function setNativeValue(el, value) {
    const proto = el.tagName === "TEXTAREA" ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    const setter = Object.getOwnPropertyDescriptor(proto, "value").set;
    setter.call(el, value);
    el.dispatchEvent(new Event("input", { bubbles: true }));
    el.dispatchEvent(new Event("change", { bubbles: true }));
  }

  function formSummary(form) {
    const fields = [];
    if (form) {
      form.querySelectorAll("input,select,textarea").forEach((f) => {
        if (f.type === "hidden" || f.type === "submit" || !isVisible(f)) return;
        const filled = f.type === "checkbox" || f.type === "radio" ? f.checked : !!f.value;
        fields.push({ label: labelOf(f) || f.name || f.type, filled, sensitive: isSensitive(f) || undefined });
      });
    }
    let target = location.origin;
    try { if (form && form.action) target = new URL(form.action, location.href).origin; } catch (_) {}
    return { page: location.href, sendsTo: target, sameOrigin: target === location.origin, fields: fields.slice(0, 30) };
  }

  function requireConfirm(form, args, run) {
    if (args.confirmed !== true) {
      return { needsConfirmation: true, summary: formSummary(form) };
    }
    return run();
  }

  /* ---------- 화면 커서 (Claude 의 computer_use 처럼): 최미나이가 조작하는 곳으로 화살표가 움직이고 누를 때 물결 ---------- */
  let cursorHost = null, cursorEl = null, hideTimer = 0;
  function ensureCursor() {
    if (cursorHost && cursorHost.isConnected) return;
    cursorHost = document.createElement("div");
    cursorHost.setAttribute("data-choimini-cursor", "");
    cursorHost.style.cssText = "position:fixed;left:0;top:0;width:0;height:0;z-index:2147483647;pointer-events:none;";
    const root = cursorHost.attachShadow({ mode: "closed" });
    root.innerHTML = '<style>.c{position:fixed;left:0;top:0;width:22px;height:26px;transition:transform .18s ease-out,opacity .3s;pointer-events:none;filter:drop-shadow(0 1px 2px rgba(0,0,0,.45));}' +
      '.r{position:fixed;width:16px;height:16px;margin:-8px 0 0 -8px;border:3px solid #3b82f6;border-radius:50%;pointer-events:none;animation:rp .45s ease-out forwards;}' +
      '@keyframes rp{from{transform:scale(.5);opacity:1}to{transform:scale(3.2);opacity:0}}</style>' +
      '<svg class="c" viewBox="0 0 22 26"><path d="M1 1 L1 20 L6 15.5 L9.5 23.5 L13 22 L9.5 14 L16 14 Z" fill="#fff" stroke="#111827" stroke-width="1.6" stroke-linejoin="round"/></svg>';
    cursorEl = root.querySelector(".c"); cursorHost._root = root;
    (document.documentElement || document.body).appendChild(cursorHost);
  }
  function pointTo(x, y, click) {
    try {
      ensureCursor();
      cursorEl.style.opacity = "1";
      cursorEl.style.transform = "translate(" + Math.round(x) + "px," + Math.round(y) + "px)";
      if (click) { const r = document.createElement("div"); r.className = "r"; r.style.left = x + "px"; r.style.top = y + "px"; cursorHost._root.appendChild(r); setTimeout(() => r.remove(), 600); }
      clearTimeout(hideTimer); hideTimer = setTimeout(() => { if (cursorEl) cursorEl.style.opacity = "0"; }, 3000);
    } catch (_) {}
  }
  function center(el) { const r = el.getBoundingClientRect(); return { x: r.left + r.width / 2, y: r.top + r.height / 2 }; }
  function pointAt(el, click) { const c = center(el); pointTo(c.x, c.y, click); return c; }
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

  /* 스크린샷 이미지 좌표(기기 픽셀) → 화면(CSS) 좌표 */
  function fromShot(args) {
    const dpr = Number(args.dpr) || window.devicePixelRatio || 1;
    const css = args.coord === "css";
    return { x: Number(args.x) / (css ? 1 : dpr), y: Number(args.y) / (css ? 1 : dpr) };
  }
  // ref 가 있으면 그 요소, x,y 가 있으면 그 위치의 요소
  function target(args) {
    if (args.ref) return { el: getEl(args.ref), at: null };
    if (args.x == null || args.y == null) throw new Error("ref 또는 x,y 가 필요해요.");
    const p = fromShot(args);
    if (!(p.x >= 0 && p.y >= 0 && p.x <= window.innerWidth && p.y <= window.innerHeight)) throw new Error("화면 밖 좌표예요. 스크린샷 이미지 안의 좌표를 쓰세요.");
    const el = document.elementFromPoint(p.x, p.y);
    if (!el) throw new Error("그 위치에 요소가 없어요.");
    return { el, at: p };
  }
  function mouse(el, type, p, extra) {
    const o = Object.assign({ bubbles: true, cancelable: true, composed: true, clientX: p.x, clientY: p.y, view: window, button: 0 }, extra || {});
    const Ev = type.startsWith("pointer") && window.PointerEvent ? PointerEvent : MouseEvent;
    el.dispatchEvent(new Ev(type, o));
  }
  function newRef(el) { for (const [k, v] of refs) if (v === el) return k; const ref = "e" + (++refSeq); refs.set(ref, el); return ref; }
  function describe(el) {
    return { ref: newRef(el), tag: el.tagName.toLowerCase(), label: labelOf(el).slice(0, 80) || undefined, text: txt(el).slice(0, 80) || undefined };
  }
  const submitterOf = (el) => el.closest && el.closest('button,input[type="submit"],input[type="image"]');

  const actions = {
    snapshot,

    read_text() { return { url: location.href, text: (document.body.innerText || "").slice(0, 8000) }; },

    async click(args) {
      const t = target(args); let el = t.el;
      const sub = submitterOf(el);
      if (sub && isSubmitter(sub)) return requireConfirm(sub.form, args, () => { pointAt(sub, true); sub.click(); return { ok: true, submitted: true }; });
      if (!t.at) el.scrollIntoView({ block: "center" });
      const p = t.at || center(el);
      pointTo(p.x, p.y, true); await sleep(120);
      mouse(el, "pointerdown", p); mouse(el, "mousedown", p); mouse(el, "pointerup", p); mouse(el, "mouseup", p);
      el.click();
      return { ok: true, clicked: describe(el) };
    },

    async double_click(args) {
      const t = target(args); const el = t.el; if (submitterOf(el)) return { ok: false, error: "SUBMIT_BUTTON", message: "제출 버튼은 click 으로 눌러 주세요(확인 절차가 있어요)." };
      if (!t.at) el.scrollIntoView({ block: "center" });
      const p = t.at || center(el); pointTo(p.x, p.y, true); await sleep(120);
      mouse(el, "mousedown", p, { detail: 1 }); mouse(el, "mouseup", p, { detail: 1 }); mouse(el, "click", p, { detail: 1 });
      mouse(el, "mousedown", p, { detail: 2 }); mouse(el, "mouseup", p, { detail: 2 }); mouse(el, "click", p, { detail: 2 }); mouse(el, "dblclick", p, { detail: 2 });
      pointTo(p.x, p.y, true);
      return { ok: true, target: describe(el) };
    },

    async right_click(args) {
      const t = target(args); const el = t.el; const p = t.at || center(el);
      pointTo(p.x, p.y, true); await sleep(100);
      mouse(el, "mousedown", p, { button: 2 }); mouse(el, "mouseup", p, { button: 2 }); mouse(el, "contextmenu", p, { button: 2 });
      return { ok: true, target: describe(el), note: "페이지가 만든 메뉴만 열려요(브라우저 기본 메뉴는 열 수 없어요)." };
    },

    async hover(args) {
      const t = target(args); const el = t.el; if (!t.at) el.scrollIntoView({ block: "nearest" });
      const p = t.at || center(el); pointTo(p.x, p.y, false); await sleep(120);
      ["pointerover", "pointerenter", "mouseover", "mouseenter", "pointermove", "mousemove"].forEach((ty) => mouse(el, ty, p, ty.endsWith("enter") ? { bubbles: false } : null));
      await sleep(250);
      return { ok: true, target: describe(el) };
    },

    // 키 누르기: 포커스된 요소(또는 ref) 에. Enter 로 양식이 제출되면 확인 절차를 거친다
    press_key(args) {
      const raw = String(args.key || "").trim(); if (!raw) return { ok: false, error: "NO_KEY", message: "key 가 필요해요. 예: {\"action\":\"press_key\",\"key\":\"Enter\"}" };
      const parts = raw.split("+").map((x) => x.trim()).filter(Boolean);
      const mods = { ctrlKey: false, shiftKey: false, altKey: false, metaKey: false };
      parts.slice(0, -1).forEach((m) => { m = m.toLowerCase(); if (m === "ctrl" || m === "control") mods.ctrlKey = true; else if (m === "shift") mods.shiftKey = true; else if (m === "alt") mods.altKey = true; else if (m === "meta" || m === "cmd" || m === "win") mods.metaKey = true; });
      const NAMES = { enter: "Enter", return: "Enter", esc: "Escape", escape: "Escape", tab: "Tab", space: " ", backspace: "Backspace", delete: "Delete", del: "Delete", up: "ArrowUp", down: "ArrowDown", left: "ArrowLeft", right: "ArrowRight", arrowup: "ArrowUp", arrowdown: "ArrowDown", arrowleft: "ArrowLeft", arrowright: "ArrowRight", home: "Home", end: "End", pageup: "PageUp", pagedown: "PageDown" };
      let key = parts[parts.length - 1]; key = NAMES[key.toLowerCase()] || (key.length === 1 ? key : key);
      const el = args.ref ? getEl(args.ref) : (document.activeElement || document.body);
      if (args.ref) el.focus();
      if (isSensitive(el) && key.length === 1) return { ok: false, error: "SENSITIVE_FIELD", message: "이 필드는 사용자가 직접 입력해야 해요." };
      if (el.isConnected && el.getBoundingClientRect) pointAt(el, false);
      // Enter 로 양식 제출 = 제출과 같으므로 확인을 받는다
      if (key === "Enter" && !mods.ctrlKey && !mods.altKey && el.form && el.tagName === "INPUT") {
        return requireConfirm(el.form, args, () => { if (el.form.requestSubmit) el.form.requestSubmit(); else el.form.submit(); return { ok: true, submitted: true }; });
      }
      const o = Object.assign({ key, code: key.length === 1 ? "Key" + key.toUpperCase() : key, bubbles: true, cancelable: true, composed: true }, mods);
      const notCanceled = el.dispatchEvent(new KeyboardEvent("keydown", o));
      if (key.length === 1) el.dispatchEvent(new KeyboardEvent("keypress", o));
      el.dispatchEvent(new KeyboardEvent("keyup", o));
      // 기본 동작 일부를 직접 처리 (합성 키 이벤트는 브라우저 기본 동작을 하지 않음)
      if (notCanceled) {
        if (key === "Tab") {
          const f = Array.from(document.querySelectorAll('a[href],button,input,select,textarea,[tabindex]:not([tabindex="-1"]),[contenteditable="true"]')).filter((x) => !x.disabled && isVisible(x));
          const i = f.indexOf(document.activeElement); const n = f[(i + (mods.shiftKey ? -1 : 1) + f.length) % f.length]; if (n) { n.focus(); pointAt(n, false); }
        } else if (mods.ctrlKey && key.toLowerCase() === "a" && el.select) el.select();
        else if (key === "Escape" && document.activeElement && document.activeElement.blur) document.activeElement.blur();
      }
      return { ok: true, key: raw, target: el === document.body ? "body" : describe(el) };
    },

    // 글자로 요소 찾기 (전체 snapshot 보다 빠름). 찾은 요소에 ref 를 붙여 준다
    find(args) {
      const q = String(args.text || args.query || "").trim().toLowerCase(); if (!q) return { ok: false, error: "NO_TEXT", message: "text 가 필요해요." };
      const out = [];
      const sel = 'a,button,input,select,textarea,label,h1,h2,h3,h4,li,td,th,[role],[aria-label],[title],p,span,div';
      for (const el of document.querySelectorAll(sel)) {
        if (out.length >= 25) break;
        if (!isVisible(el)) continue;
        const hay = (labelOf(el) + " " + (el.children.length <= 3 ? txt(el) : "") + " " + (el.getAttribute("aria-label") || "")).toLowerCase();
        if (!hay.includes(q)) continue;
        if (out.some((o) => o._el.contains(el) && o._el !== el && o._el.children.length <= 3)) continue;
        const r = el.getBoundingClientRect(), dpr = window.devicePixelRatio || 1;
        out.push(Object.assign(describe(el), { _el: el, x: Math.round((r.left + r.width / 2) * dpr), y: Math.round((r.top + r.height / 2) * dpr), sensitive: (el.matches("input,textarea") && isSensitive(el)) || undefined }));
      }
      out.forEach((o) => delete o._el);
      return { url: location.href, count: out.length, elements: out, note: "x,y 는 스크린샷 이미지 좌표" };
    },

    // 요소(또는 페이지)의 HTML 일부 — 구조 확인용. 입력값(value)은 지운다
    get_html(args) {
      let el = args.ref ? getEl(args.ref) : (args.selector ? document.querySelector(String(args.selector)) : document.body);
      if (!el) return { ok: false, error: "NOT_FOUND", message: "그 요소가 없어요." };
      const c = el.cloneNode(true);
      c.querySelectorAll && c.querySelectorAll("input,textarea").forEach((f) => { f.removeAttribute("value"); if (f.tagName === "TEXTAREA") f.textContent = ""; });
      c.querySelectorAll && c.querySelectorAll("script,style,svg,noscript").forEach((x) => x.remove());
      const max = Math.min(Math.max(Number(args.max) || 8000, 500), 30000);
      const html = c.outerHTML || "";
      return { url: location.href, length: html.length, html: html.slice(0, max) + (html.length > max ? "…(생략)" : "") };
    },

    scroll_to(args) {
      const el = getEl(args.ref); el.scrollIntoView({ block: "center", behavior: "instant" }); pointAt(el, false);
      return { ok: true, scrollY: Math.round(window.scrollY) };
    },

    type(args) {
      const el = getEl(args.ref);
      if (isSensitive(el)) {
        return { ok: false, error: "SENSITIVE_FIELD", message: "이 필드(비밀번호/카드/인증번호 등)는 사용자가 직접 입력해야 해요." };
      }
      el.scrollIntoView({ block: "center" });
      pointAt(el, true);
      el.focus();
      if (el.isContentEditable) { el.textContent = String(args.text ?? ""); el.dispatchEvent(new Event("input", { bubbles: true })); }
      else setNativeValue(el, String(args.text ?? ""));
      return { ok: true };
    },

    select(args) {
      const el = getEl(args.ref);
      if (el.tagName !== "SELECT") return { ok: false, error: "NOT_SELECT" };
      const want = String(args.value ?? "");
      const opt = Array.from(el.options).find((o) => o.value === want || o.text.trim() === want);
      if (!opt) return { ok: false, error: "NO_SUCH_OPTION" };
      el.value = opt.value;
      el.dispatchEvent(new Event("input", { bubbles: true }));
      el.dispatchEvent(new Event("change", { bubbles: true }));
      return { ok: true };
    },

    check(args) {
      const el = getEl(args.ref);
      const want = args.checked !== false;
      if (el.checked !== want) el.click();
      return { ok: true, checked: el.checked };
    },

    submit(args) {
      const el = getEl(args.ref);
      const form = el.tagName === "FORM" ? el : el.form || el.closest("form");
      if (!form) return { ok: false, error: "NO_FORM" };
      return requireConfirm(form, args, () => {
        if (form.requestSubmit) form.requestSubmit(); else form.submit();
        return { ok: true, submitted: true };
      });
    },

    scroll(args) {
      const dy = Number(args.dy) || Math.round(window.innerHeight * 0.8);
      window.scrollBy({ top: dy, behavior: "instant" });
      return { ok: true, scrollY: Math.round(window.scrollY) };
    },

    wait(args) {
      const ms = Math.min(Math.max(Number(args.ms) || 500, 0), 5000);
      return new Promise((r) => setTimeout(() => r({ ok: true, waitedMs: ms }), ms));
    },
  };

  chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
    if (!msg || msg.target !== "choimini-agent") return;
    Promise.resolve()
      .then(() => {
        const fn = actions[msg.action];
        if (!fn) throw new Error("Unknown action: " + msg.action);
        return fn(msg.args || {});
      })
      .then((result) => sendResponse({ ok: true, result }))
      .catch((e) => sendResponse({ ok: false, error: String(e && e.message || e) }));
    return true; // async
  });
})();
