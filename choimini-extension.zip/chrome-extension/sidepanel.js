// 사이드 패널: 최미나이 사이트(iframe) ↔ 확장(백그라운드) 브리지
//
// 프로토콜 (postMessage, origin 엄격 검사):
//   사이트 → 확장 : { source:"choimini-web", type:"browser-request", id, action, args }
//   확장 → 사이트 : { source:"choimini-ext", type:"browser-response", id, ok, result|error|message,
//                     needsConfirmation?, summary? }
//   확장 → 사이트 : { source:"choimini-ext", type:"browser-ready", enabled }  (로드/권한 변경 시)
//
// 안전장치: ① 페이지 제어는 사용자가 버튼으로 권한을 준 뒤에만  ② "정지" 버튼으로 즉시 차단
//          ③ 양식 제출은 이 패널에서 사용자가 [제출 허용]을 눌러야만 진행(agent.js도 재검증)

const SITE = window.CHOIMINI_SITE_URL;
const SITE_ORIGIN = new URL(SITE).origin;
const frame = document.getElementById("frame");
const fallback = document.getElementById("fallback");
const statusEl = document.getElementById("status");
const permBtn = document.getElementById("permBtn");
const stopBtn = document.getElementById("stopBtn");
const confirmBox = document.getElementById("confirm");
const confirmBody = document.getElementById("confirmBody");

let loaded = false;
let paused = false;
let enabled = false;
let loggedIn = false;   // 사이트(iframe)가 알려주는 Google 로그인 상태. 로그인 안 되면 페이지 제어는 전부 거부한다.

/* ---------- 로드 / 폴백 ---------- */
function showFallback() { frame.style.display = "none"; fallback.style.display = "flex"; }
document.getElementById("openTabBtn").addEventListener("click", () => chrome.tabs.create({ url: SITE }));
frame.addEventListener("load", () => { loaded = true; notifyReady(); });
frame.src = SITE + (SITE.includes("?") ? "&" : "?") + "app=chrome"; // choimini-auth.js가 크롬 확장임을 인식
setTimeout(() => { if (!loaded) showFallback(); }, 2500);

/* ---------- 권한 / 상태 ---------- */
async function refreshPerm() {
  enabled = await chrome.permissions.contains({ origins: ["<all_urls>"] });
  permBtn.style.display = enabled ? "none" : "";
  renderStatus();
  notifyReady();
}
function renderStatus(busy) {
  statusEl.className = "st" + (busy ? " busy" : enabled && loggedIn && !paused ? " on" : "");
  statusEl.textContent = busy ? "작업 중: " + busy
    : !loggedIn ? "로그인 필요"
    : !enabled ? "페이지 제어: 꺼짐"
    : paused ? "페이지 제어: 정지됨" : "페이지 제어: 켜짐";
}
permBtn.addEventListener("click", async () => {
  await chrome.permissions.request({ origins: ["<all_urls>"] }); // 사용자 클릭으로만 요청 가능
  refreshPerm();
});
stopBtn.addEventListener("click", () => {
  paused = !paused;
  stopBtn.textContent = paused ? "재개" : "정지";
  stopBtn.classList.toggle("paused", paused);
  renderStatus();
  notifyReady();
});
chrome.permissions.onAdded.addListener(refreshPerm);
chrome.permissions.onRemoved.addListener(refreshPerm);
refreshPerm();

function post(msg) {
  if (frame.contentWindow) frame.contentWindow.postMessage(Object.assign({ source: "choimini-ext" }, msg), SITE_ORIGIN);
}
function notifyReady() { post({ type: "browser-ready", enabled: enabled && loggedIn && !paused }); }

/* ---------- 요청 처리 ---------- */
function askConfirm(summary) {
  return new Promise((resolve) => {
    const fields = (summary.fields || []).map((f) =>
      "<li>" + esc(f.label) + (f.sensitive ? " 🔒(민감)" : "") + " — " + (f.filled ? "입력됨" : "비어있음") + "</li>").join("");
    confirmBody.innerHTML =
      "<div>페이지: " + esc(summary.page) + "</div>" +
      "<div>전송 대상: <b>" + esc(summary.sendsTo) + "</b>" + (summary.sameOrigin ? "" : " ⚠ 다른 사이트") + "</div>" +
      "<ul>" + fields + "</ul>";
    confirmBox.classList.add("show");
    const done = (v) => { confirmBox.classList.remove("show"); resolve(v); };
    document.getElementById("allowBtn").onclick = () => done(true);
    document.getElementById("denyBtn").onclick = () => done(false);
  });
}
function esc(s) { return String(s == null ? "" : s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c])); }

function callBackground(action, args) {
  return new Promise((resolve) => chrome.runtime.sendMessage({ type: "BROWSER_ACTION", action, args }, (r) => resolve(r || { ok: false, error: "NO_RESPONSE" })));
}

async function runRequest(msg) {
  if (!loggedIn) return { ok: false, error: "NOT_LOGGED_IN", message: "로그인해야 페이지 제어를 쓸 수 있어요." };
  if (paused) return { ok: false, error: "PAUSED", message: "사용자가 정지했어요." };
  renderStatus(msg.action);
  try {
    let res = await callBackground(msg.action, msg.args);
    // 제출류는 agent.js가 needsConfirmation을 돌려줌 → 사용자 확인 → confirmed:true로 재시도
    if (res.ok && res.result && res.result.needsConfirmation) {
      const allow = await askConfirm(res.result.summary);
      if (!allow) return { ok: false, error: "USER_DENIED", message: "사용자가 제출을 거부했어요." };
      res = await callBackground(msg.action, Object.assign({}, msg.args, { confirmed: true }));
    }
    return res;
  } finally { renderStatus(); }
}

window.addEventListener("message", async (ev) => {
  if (ev.origin !== SITE_ORIGIN || ev.source !== frame.contentWindow) return;
  const m = ev.data;
  if (m && m.source === "choimini-web" && m.type === "auth") { // 사이트가 보고하는 로그인 상태 (origin/source 는 위에서 이미 검사됨)
    loggedIn = !!m.loggedIn; renderStatus(); notifyReady(); return;
  }
  if (!m || m.source !== "choimini-web" || m.type !== "browser-request" || typeof m.action !== "string") return;
  const res = await runRequest(m);
  post({ type: "browser-response", id: m.id, ok: !!res.ok, result: res.result, error: res.error, message: res.message });
});
