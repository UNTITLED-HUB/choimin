// Choimini Desktop — Electron 메인 프로세스
// - Chat 모드: 일반 최미나이 웹 채팅
// - Code 모드(= Choimini Code): Claude Code 처럼 "작업 폴더" 안에서 파일을 읽고/검색/수정하고 명령을 실행하는 코딩 에이전트
//     · 모델은 사이트(webview)에 있고, 도구 실행은 전부 이 프로세스가 한다 (사이트는 요청만 한다)
//     · 실행 조건(모두 이 프로세스가 강제): ① Google 로그인 ② 캡차 통과 ③ Code 모드 ④ 작업 폴더 선택 ⑤ 권한 모드/사용자 승인
// - 모든 앱 공통: 로그인 필수, Cloudflare 확인 없음(앱 식별 헤더/UA/플래그), 토큰 배수 없음
const { app, BrowserWindow, ipcMain, shell, dialog, session } = require("electron");
const path = require("path");
const os = require("os");
const fs = require("fs");
const crypto = require("crypto");
const { spawn } = require("child_process");
const { SITE_URL, APP_HEADER_NAME, APP_HEADER_VALUE, UA_SUFFIX } = require("./config.js");
const Tools = require("./agent-tools.js");

// 개발/테스트 전용 오버라이드 — 패키징된 앱(app.isPackaged)에서는 무시된다
const DEV = !app.isPackaged;
const EFFECTIVE_SITE_URL = (DEV && process.env.CHOIMINI_DEV_SITE) || SITE_URL;
const SITE_ORIGIN = new URL(EFFECTIVE_SITE_URL).origin;

let mainWindow = null;
const procs = new Map(); // 통합 터미널 id -> child

/* ---------------- 설정 저장 (작업 폴더만) ---------------- */
const settingsFile = () => path.join(app.getPath("userData"), "choimini-desktop.json");
function loadSettings() { try { return JSON.parse(fs.readFileSync(settingsFile(), "utf8")); } catch (_) { return {}; } }
function saveSettings(patch) { try { fs.mkdirSync(path.dirname(settingsFile()), { recursive: true }); fs.writeFileSync(settingsFile(), JSON.stringify(Object.assign(loadSettings(), patch), null, 2)); } catch (_) {} }

/* ---------------- 프로토콜 / 단일 인스턴스 ---------------- */
if (process.defaultApp) {
  if (process.argv.length >= 2) app.setAsDefaultProtocolClient("choimini", process.execPath, [path.resolve(process.argv[1])]);
} else {
  app.setAsDefaultProtocolClient("choimini");
}
const gotLock = app.requestSingleInstanceLock();
if (!gotLock) {
  app.quit();
} else {
  app.on("second-instance", (_e, argv) => {
    const url = argv.find((a) => a.startsWith("choimini://"));
    if (url) forwardAuthCallback(url);
    if (mainWindow) { if (mainWindow.isMinimized()) mainWindow.restore(); mainWindow.focus(); }
  });
  app.on("open-url", (event, url) => { event.preventDefault(); forwardAuthCallback(url); });
  app.whenReady().then(() => { setupSession(); createWindow(); });
}

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1320, height: 840, backgroundColor: "#0a0b0f", title: "Choimini Desktop",
    webPreferences: { preload: path.join(__dirname, "preload.js"), contextIsolation: true, nodeIntegration: false, webviewTag: true },
  });
  mainWindow.loadFile(path.join(__dirname, "renderer", "index.html"));
  mainWindow.on("closed", () => { denyAllPending(); mainWindow = null; });
}
app.on("window-all-closed", () => {
  procs.forEach((p) => { try { p.kill(); } catch (_) {} });
  if (process.platform !== "darwin") app.quit();
});

const send = (ch, payload) => { if (mainWindow && !mainWindow.isDestroyed()) mainWindow.webContents.send(ch, payload); };
const fromHost = (e) => mainWindow && e.sender === mainWindow.webContents; // 호스트 UI(신뢰 영역)에서 온 요청만

/* ---------------- 앱 식별 (Cloudflare 확인 없이 접속) ----------------
   모든 앱은 사이트에 "앱 트래픽"임을 알린다: 요청 헤더 + UA 꼬리표 (+ 사이트 쪽 window.CHOIMINI_SKIP_CLOUDFLARE).
   사이트가 이 신호를 보고 Turnstile 을 건너뛴다. Cloudflare WAF 를 쓰는 경우엔 같은 헤더로 Skip 규칙을 만들면 된다. */
function setupSession() {
  const ses = session.fromPartition("persist:choimini");
  ses.setUserAgent(ses.getUserAgent() + " " + UA_SUFFIX);
  ses.webRequest.onBeforeSendHeaders({ urls: [SITE_ORIGIN + "/*"] }, (details, cb) => {
    details.requestHeaders[APP_HEADER_NAME] = APP_HEADER_VALUE;
    cb({ requestHeaders: details.requestHeaders });
  });
}

/* ---------------- OAuth 딥링크 ---------------- */
function forwardAuthCallback(url) { send("auth-callback", url); }
ipcMain.on("open-auth", (e, url) => {
  if (!fromHost(e)) return;
  try { if (new URL(url).protocol === "https:") shell.openExternal(url); } catch (_) {}
});
ipcMain.handle("get-site-url", () => EFFECTIVE_SITE_URL);

/* ---------------- 상태: 로그인 / 캡차 / 모드 ---------------- */
let authOk = false;         // 사이트가 보고한 Google 로그인 상태 (호스트 UI 가 전달)
let codeUnlocked = false;   // 캡차 통과 여부 (세션 동안 유지)
let activeMode = "chat";    // "지금 Code 모드인가"는 이 프로세스가 직접 기억한다 (웹페이지가 쓰는 변수는 위조 가능)
let permMode = "ask";       // ask | acceptEdits | plan
let workspace = (DEV && process.env.CHOIMINI_TEST_WORKSPACE) || loadSettings().workspace || null;
const codeAllowed = () => authOk && codeUnlocked && activeMode === "code";

function forceChat(reason) {
  const was = activeMode === "code";
  activeMode = "chat";
  denyAllPending();
  if (was) send("force-chat", reason || "");
}

ipcMain.handle("set-auth", (e, v) => {
  if (!fromHost(e)) return false;
  authOk = !!v;
  if (!authOk) { forceChat("로그아웃되어 Chat 모드로 돌아왔어요."); procs.forEach((p) => { try { p.kill(); } catch (_) {} }); procs.clear(); sessionAllow.edits = false; sessionAllow.commands.clear(); }
  return authOk;
});
ipcMain.handle("get-auth", () => ({ authOk }));

/* ---------------- Code 모드 CAPTCHA ----------------
   정답은 이 프로세스 메모리에만 있다. 3회 실패 시 30초 잠금, 이미지는 2분 뒤 만료. */
const CAPTCHA_CHARS = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
let captcha = null, captchaLockedUntil = 0;
const rint = (n) => crypto.randomInt(0, n);
function buildCaptchaSvg(text) {
  const W = 220, H = 80;
  let s = `<svg xmlns="http://www.w3.org/2000/svg" width="${W}" height="${H}" viewBox="0 0 ${W} ${H}"><rect width="${W}" height="${H}" fill="#151826"/>`;
  for (let i = 0; i < 7; i++) s += `<path d="M${rint(W)} ${rint(H)} Q${rint(W)} ${rint(H)} ${rint(W)} ${rint(H)}" stroke="hsl(${rint(360)},60%,55%)" stroke-width="${1 + rint(2)}" fill="none" opacity="0.7"/>`;
  for (let i = 0; i < 40; i++) s += `<circle cx="${rint(W)}" cy="${rint(H)}" r="${1 + rint(2)}" fill="hsl(${rint(360)},50%,60%)" opacity="0.6"/>`;
  const step = (W - 30) / text.length;
  for (let i = 0; i < text.length; i++) {
    const x = 20 + i * step, y = 48 + rint(16) - 8, rot = rint(50) - 25, size = 34 + rint(10);
    s += `<text x="${x}" y="${y}" font-size="${size}" font-family="Verdana,Arial,sans-serif" font-weight="700" fill="hsl(${rint(360)},70%,75%)" transform="rotate(${rot} ${x} ${y})">${text[i]}</text>`;
  }
  return s + "</svg>";
}
ipcMain.handle("captcha-new", (e) => {
  if (!fromHost(e)) return { locked: true, retryInSec: 0 };
  if (Date.now() < captchaLockedUntil) return { locked: true, retryInSec: Math.ceil((captchaLockedUntil - Date.now()) / 1000) };
  let text = ""; for (let i = 0; i < 5; i++) text += CAPTCHA_CHARS[rint(CAPTCHA_CHARS.length)];
  captcha = { text, expires: Date.now() + 120000, tries: 0 };
  return { locked: false, image: "data:image/svg+xml;base64," + Buffer.from(buildCaptchaSvg(text)).toString("base64") };
});
ipcMain.handle("captcha-verify", (e, input) => {
  if (!fromHost(e)) return { ok: false };
  if (Date.now() < captchaLockedUntil) return { ok: false, locked: true, retryInSec: Math.ceil((captchaLockedUntil - Date.now()) / 1000) };
  if (!captcha || Date.now() > captcha.expires) return { ok: false, expired: true };
  captcha.tries++;
  if (String(input || "").trim().toUpperCase() === captcha.text) { captcha = null; codeUnlocked = true; return { ok: true }; }
  if (captcha.tries >= 3) { captcha = null; captchaLockedUntil = Date.now() + 30000; return { ok: false, locked: true, retryInSec: 30 }; }
  return { ok: false, triesLeft: 3 - captcha.tries };
});
ipcMain.handle("code-status", () => ({ unlocked: codeUnlocked, authOk }));

// Code 모드로 들어가려면 로그인 + 캡차 통과가 모두 필요하다
ipcMain.handle("set-mode", (e, m) => {
  if (!fromHost(e)) return { ok: false };
  if (m === "code") {
    if (!authOk) return { ok: false, reason: "login" };
    if (!codeUnlocked) return { ok: false, reason: "captcha" };
    activeMode = "code"; return { ok: true };
  }
  activeMode = "chat"; denyAllPending(); return { ok: true };
});

/* ---------------- 작업 폴더 / 권한 모드 ---------------- */
ipcMain.handle("workspace-get", () => ({ workspace, permMode }));
ipcMain.handle("workspace-pick", async (e) => {
  if (!fromHost(e) || !codeAllowed()) return { workspace, permMode };
  const r = await dialog.showOpenDialog(mainWindow, { title: "작업 폴더 선택", properties: ["openDirectory", "createDirectory"] });
  if (!r.canceled && r.filePaths[0]) { workspace = r.filePaths[0]; saveSettings({ workspace }); sessionAllow.edits = false; sessionAllow.commands.clear(); send("workspace-changed", { workspace, permMode }); }
  return { workspace, permMode };
});
ipcMain.handle("perm-mode-set", (e, m) => {
  if (!fromHost(e) || !["ask", "acceptEdits", "plan"].includes(m)) return { permMode };
  permMode = m; send("workspace-changed", { workspace, permMode }); return { permMode };
});

/* ---------------- 권한 요청 (변경/명령 실행 전에 사용자 승인) ---------------- */
const sessionAllow = { edits: false, commands: new Set() };
const pending = new Map(); let permSeq = 0;
function denyAllPending() {
  pending.forEach((p) => p.resolve({ allow: false, reason: "cancel" })); pending.clear();
  send("permission-cancel"); // 화면에 떠 있는 승인 창도 닫게 한다 (안 그러면 낡은 창이 다음 요청을 가린다)
}

function requestPermission(req) { // req: {kind:'edit'|'command', title, detail, diff?, key?}
  if (permMode === "plan") return Promise.resolve({ allow: false, reason: "plan" });
  if (req.kind === "edit" && (permMode === "acceptEdits" || sessionAllow.edits)) return Promise.resolve({ allow: true, auto: true });
  if (req.kind === "command" && sessionAllow.commands.has(req.key)) return Promise.resolve({ allow: true, auto: true });
  return new Promise((resolve) => {
    if (!mainWindow) return resolve({ allow: false, reason: "cancel" });
    const id = ++permSeq;
    pending.set(id, { resolve, req });
    send("permission-request", Object.assign({ id }, req));
  });
}
ipcMain.on("permission-response", (e, { id, choice }) => {
  if (!fromHost(e)) return;
  const p = pending.get(id); if (!p) return;
  pending.delete(id);
  if (choice === "session") { if (p.req.kind === "edit") sessionAllow.edits = true; else sessionAllow.commands.add(p.req.key); }
  p.resolve({ allow: choice === "once" || choice === "session" });
});

/* ---------------- 에이전트 도구 실행 ---------------- */
let activitySeq = 0, agentAborted = false;
ipcMain.on("agent-abort", (e) => { if (fromHost(e)) { agentAborted = true; denyAllPending(); } });

const clip = (s, n) => (String(s).length > n ? String(s).slice(0, n) + "…" : String(s));
function runShell(cmd, cwd, timeoutMs) {
  return new Promise((resolve) => {
    const isWin = process.platform === "win32";
    const sh = isWin ? (process.env.COMSPEC || "cmd.exe") : (process.env.SHELL || "/bin/bash");
    const args = isWin ? ["/d", "/s", "/c", cmd] : ["-lc", cmd];
    send("term-data", { id: "main", data: `\r\n\x1b[36m$ ${cmd}\x1b[0m\r\n` });
    let out = "", done = false;
    const p = spawn(sh, args, { cwd, env: process.env, windowsHide: true });
    const cap = (b) => { out += b; if (out.length > 60000) out = "…(앞부분 생략)…\n" + out.slice(-30000); };
    const finish = (code, extra) => { if (done) return; done = true; clearTimeout(t); resolve({ code, out: out + (extra || "") }); };
    const t = setTimeout(() => { try { p.kill(); } catch (_) {} finish(-4, `\n[시간 초과] ${Math.round(timeoutMs / 1000)}초를 넘어 중단했어요.`); }, timeoutMs);
    p.stdout.on("data", (b) => { const s = b.toString("utf8"); cap(s); send("term-data", { id: "main", data: s }); });
    p.stderr.on("data", (b) => { const s = b.toString("utf8"); cap(s); send("term-data", { id: "main", data: s }); });
    p.on("error", (err) => finish(-1, `\n[오류] ${err.message}`));
    p.on("exit", (code) => finish(code));
  });
}

const READ_TOOLS = new Set(["read_file", "list_dir", "glob", "grep"]);
const summarize = (tool, a) => {
  a = a || {};
  switch (tool) {
    case "read_file": return "읽기 " + (a.path || "");
    case "list_dir": return "폴더 보기 " + (a.path || ".");
    case "glob": return "파일 찾기 " + (a.pattern || "");
    case "grep": return "내용 검색 " + (a.pattern || "");
    case "write_file": return "파일 쓰기 " + (a.path || "");
    case "edit_file": return "파일 수정 " + (a.path || "");
    case "run_command": return "$ " + clip(a.command || "", 120);
    case "todo_write": return "할 일 목록 갱신";
    default: return tool;
  }
};

async function handleTool(tool, a) {
  a = a && typeof a === "object" ? a : {};
  if (!authOk) return { ok: false, error: "[차단] 로그인이 필요해요. 로그인한 뒤에 사용할 수 있어요." };
  if (!codeUnlocked) return { ok: false, error: "[차단] Code 모드 캡차 인증이 필요해요." };
  if (activeMode !== "code") return { ok: false, error: "[차단] Code 모드에서만 도구를 쓸 수 있어요." };
  if (agentAborted) { agentAborted = false; return { ok: false, aborted: true, error: "[중단됨] 사용자가 작업을 중단했어요." }; }

  const id = ++activitySeq, summary = summarize(tool, a);
  const emit = (patch) => send("agent-activity", Object.assign({ id, tool, summary }, patch));
  try {
    if (tool === "todo_write") { const r = Tools.todo_write(a); emit({ status: "ok", todo: r.items }); return { ok: true, output: r.output }; }

    if (!workspace) throw new Tools.ToolError("작업 폴더가 선택되지 않았어요. 사용자에게 상단의 '작업 폴더 선택'을 눌러 달라고 안내하세요.");
    const ws = Tools.makeWorkspace(workspace);
    emit({ status: "running" });

    if (READ_TOOLS.has(tool)) {
      const r = Tools[tool](ws, a);
      emit({ status: "ok", output: clip(r.output, 400) });
      return r;
    }

    if (tool === "write_file" || tool === "edit_file") {
      const prep = tool === "write_file" ? Tools.prepare_write_file(ws, a) : Tools.prepare_edit_file(ws, a);
      const perm = await requestPermission({ kind: "edit", title: prep.title, detail: prep.rel, diff: prep.diff });
      if (!perm.allow) return deny(emit, perm, "변경");
      const r = prep.apply();
      emit({ status: "ok", diff: prep.diff, output: r.output });
      return r;
    }

    if (tool === "run_command") {
      const cmd = String(a.command || "").trim();
      if (!cmd) throw new Tools.ToolError("command 가 필요해요.");
      if (cmd.length > 8000) throw new Tools.ToolError("명령이 너무 길어요.");
      const perm = await requestPermission({ kind: "command", title: "명령 실행", detail: cmd + "\n\n(작업 폴더: " + ws.root + ")", key: cmd });
      if (!perm.allow) return deny(emit, perm, "명령 실행");
      const timeout = Math.min(Math.max(Number(a.timeout_ms) || 120000, 1000), 600000);
      const r = await runShell(cmd, ws.root, timeout);
      const output = `종료코드 ${r.code}\n${r.out}`.trimEnd();
      emit({ status: r.code === 0 ? "ok" : "error", output: clip(output, 600) });
      return { ok: true, exitCode: r.code, output: clip(output, 30000) };
    }

    throw new Tools.ToolError("알 수 없는 도구예요: " + tool);
  } catch (err) {
    const msg = err instanceof Tools.ToolError ? err.message : "예상치 못한 오류: " + err.message;
    emit({ status: "error", output: msg });
    return { ok: false, error: msg };
  }
}
function deny(emit, perm, what) {
  const msg = perm.reason === "plan"
    ? `[계획 모드] 읽기 전용이라 ${what}을(를) 하지 않았어요. 변경이 필요하면 무엇을 할지 계획만 설명하고, 사용자에게 권한 모드를 바꿔 달라고 안내하세요.`
    : `[거부] 사용자가 ${what}을(를) 허용하지 않았어요. 다른 방법을 제안하거나 이유를 물어보세요.`;
  emit({ status: "denied", output: msg });
  return { ok: false, denied: true, error: msg };
}
ipcMain.handle("agent-tool", (e, { tool, args }) => (fromHost(e) ? handleTool(String(tool), args) : { ok: false, error: "[차단]" }));

/* ---------------- 코딩 에이전트 프롬프트 (Code 모드일 때만 사이트에 전달) ---------------- */
function buildCodePrompt() {
  const base = require("./system-prompt-code.js").CHOIMINI_CODE_MODE_PROMPT_KO;
  const w = workspace ? `작업 폴더: ${workspace}` : "작업 폴더: (아직 선택되지 않음 — 사용자에게 상단의 '작업 폴더 선택'을 눌러 달라고 안내하세요)";
  const m = { ask: "묻기(파일 수정/명령 실행 때마다 사용자가 승인)", acceptEdits: "편집 자동 허용(파일 수정은 자동, 명령 실행은 승인)", plan: "계획 전용(읽기만 가능, 수정/실행 불가)" }[permMode];
  return `${base}\n\n[현재 상태]\n${w}\n권한 모드: ${m}`;
}
ipcMain.handle("get-code-prompt", (e) => (fromHost(e) && codeAllowed() ? buildCodePrompt() : ""));
// webview preload 가 "시작하자마자" 동기로 물어본다 → 새로고침/페이지 이동 직후에도 값이 맞다 (우리 창 안의 webview 요청만 응답)
ipcMain.on("guest-get-state", (e) => {
  const mine = mainWindow && e.sender.hostWebContents === mainWindow.webContents;
  e.returnValue = mine && codeAllowed() ? { mode: "code", prompt: buildCodePrompt() } : { mode: "chat", prompt: "" };
});

/* ---------------- 통합 터미널 (Code 모드에서만) ---------------- */
ipcMain.handle("term-create", (e, { id }) => {
  if (!fromHost(e) || !codeAllowed()) return false;
  if (procs.has(id)) return true;
  const isWin = process.platform === "win32";
  const sh = isWin ? (process.env.COMSPEC || "cmd.exe") : (process.env.SHELL || "/bin/bash");
  const cwd = workspace && fs.existsSync(workspace) ? workspace : os.homedir();
  const p = spawn(sh, isWin ? [] : ["-i"], { cwd, env: process.env, windowsHide: true });
  const out = (d) => send("term-data", { id, data: d.toString("utf8") });
  p.stdout.on("data", out); p.stderr.on("data", out);
  p.on("exit", () => { send("term-exit", { id }); procs.delete(id); });
  p.on("error", (err) => out(`\r\n[오류] ${err.message}\r\n`));
  procs.set(id, p);
  return true;
});
ipcMain.on("term-input", (e, { id, data }) => { if (!fromHost(e) || !codeAllowed()) return; const p = procs.get(id); if (p && p.stdin.writable) p.stdin.write(data); });
ipcMain.on("term-resize", () => {});
ipcMain.on("term-kill", (e, { id }) => { if (!fromHost(e)) return; const p = procs.get(id); if (p) { try { p.kill(); } catch (_) {} procs.delete(id); } });
