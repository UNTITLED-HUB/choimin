// 저장소 관리
class StorageManager {
  static defaultData = {
    enabled: true,
    siteEvents: [],
    shortcutEvents: [],
    tabSettings: {
      cursorImage: null,
      rotation: 0,
      replaceImages: false,
      replacementImage: null,
      applyNewTabs: false,
      pageTitle: null
    },
    eventLog: []
  };

  static async load() {
    const data = await chrome.storage.local.get(null);
    return data && Object.keys(data).length ? data : this.defaultData;
  }

  static async save(data) {
    await chrome.storage.local.set(data);
  }

  static async addSiteEvent(event) {
    const data = await this.load();
    event.id = 'site-' + Date.now() + '-' + Math.random().toString(36).substr(2, 9);
    event.enabled = true;
    data.siteEvents.push(event);
    await this.save(data);
    return event;
  }

  static async updateSiteEvent(id, event) {
    const data = await this.load();
    const index = data.siteEvents.findIndex(e => e.id === id);
    if (index !== -1) {
      data.siteEvents[index] = { ...data.siteEvents[index], ...event };
      await this.save(data);
    }
  }

  static async deleteSiteEvent(id) {
    const data = await this.load();
    data.siteEvents = data.siteEvents.filter(e => e.id !== id);
    await this.save(data);
  }

  static async addShortcutEvent(event) {
    const data = await this.load();
    event.id = 'shortcut-' + Date.now() + '-' + Math.random().toString(36).substr(2, 9);
    event.enabled = true;
    data.shortcutEvents.push(event);
    await this.save(data);
    return event;
  }

  static async updateShortcutEvent(id, event) {
    const data = await this.load();
    const index = data.shortcutEvents.findIndex(e => e.id === id);
    if (index !== -1) {
      data.shortcutEvents[index] = { ...data.shortcutEvents[index], ...event };
      await this.save(data);
    }
  }

  static async deleteShortcutEvent(id) {
    const data = await this.load();
    data.shortcutEvents = data.shortcutEvents.filter(e => e.id !== id);
    await this.save(data);
  }

  static async updateTabSettings(settings) {
    const data = await this.load();
    data.tabSettings = { ...data.tabSettings, ...settings };
    await this.save(data);
  }

  static async toggleExtension(enabled) {
    const data = await this.load();
    data.enabled = enabled;
    await this.save(data);
  }

  static async addEventLog(log) {
    const data = await this.load();
    log.timestamp = new Date().toLocaleTimeString();
    data.eventLog.unshift(log);
    if (data.eventLog.length > 50) {
      data.eventLog.pop();
    }
    await this.save(data);
  }

  static async clearEventLog() {
    const data = await this.load();
    data.eventLog = [];
    await this.save(data);
  }
}
