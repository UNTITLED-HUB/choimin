// Choimini Desktop (WebView2 판)
// Electron 대신 Windows 에 이미 설치된 Microsoft Edge WebView2 런타임을 쓴다.
//  - 앱 자체 크기가 작고, 데이터 폴더(캐시)를 작게 제한한다 (%LOCALAPPDATA%\ChoiminiDesktop).
//  - 모든 보안 판단(로그인·캡차·Local·권한·작업 폴더)은 이 프로세스가 한다. 사이트는 요청만 한다.
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.IO;
using System.IO.Pipes;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Web.Script.Serialization;
using System.Windows.Forms;
using Microsoft.Web.WebView2.Core;
using Microsoft.Web.WebView2.WinForms;

namespace Choimini
{
    static class Cfg
    {
        public const string Version = "1.4.0";
        public const string SiteUrl = "https://untitled-hub.github.io/choimini/";
        public const string AppHeaderName = "X-Choimini-App";
        public const string AppHeaderValue = "desktop";
        public const string UaSuffix = "ChoiminiDesktop/" + Version;
        public const long CacheLimit = 32L * 1024 * 1024;
        public static readonly string DataRoot = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "ChoiminiDesktop");
        public static readonly string WebData = Path.Combine(DataRoot, "wv2");
        public static readonly string SettingsFile = Path.Combine(DataRoot, "settings.json");
        public static readonly string[] PurgeNames = { "Code Cache", "GPUCache", "DawnCache", "DawnGraphiteCache", "DawnWebGPUCache", "GrShaderCache", "GraphiteDawnCache", "ShaderCache", "blob_storage", "Crashpad", "BrowserMetrics", "component_crx_cache", "extensions_crx_cache", "OptimizationHints", "Safe Browsing", "ScriptCache" };
        public static readonly string[] LegacyNames = { "choimini-desktop", "Choimini Desktop", "Electron", "choimini" };
    }

    static class Json
    {
        static readonly JavaScriptSerializer S = new JavaScriptSerializer { MaxJsonLength = int.MaxValue, RecursionLimit = 64 };
        public static string To(object o) { return S.Serialize(o); }
        public static Dictionary<string, object> Dict(string s) { try { return S.Deserialize<Dictionary<string, object>>(s); } catch (Exception) { return null; } }
        public static string Str(Dictionary<string, object> d, string k) { object v; return d != null && d.TryGetValue(k, out v) && v != null ? Convert.ToString(v) : ""; }
    }

    static class Disk
    {
        public static long Size(string dir, int depth = 0)
        {
            long n = 0;
            try
            {
                foreach (var f in new DirectoryInfo(dir).EnumerateFileSystemInfos())
                {
                    try
                    {
                        if ((f.Attributes & FileAttributes.ReparsePoint) != 0) continue;
                        var fi = f as FileInfo;
                        if (fi != null) n += fi.Length; else if (depth < 14) n += Size(f.FullName, depth + 1);
                    }
                    catch (Exception) { }
                }
            }
            catch (Exception) { }
            return n;
        }
        public static string Fmt(long b) { if (b < 1024) return b + " B"; if (b < 1048576) return (b / 1024.0).ToString("0.#") + " KB"; if (b < 1073741824) return (b / 1048576.0).ToString("0.#") + " MB"; return (b / 1073741824.0).ToString("0.##") + " GB"; }
        // 다시 만들어지는 캐시 폴더를 지운다 (로그인·채팅·Linux Local 데이터는 건드리지 않는다)
        public static long PurgeCaches(string root, int depth = 0)
        {
            long freed = 0;
            try
            {
                foreach (var d in new DirectoryInfo(root).GetDirectories())
                {
                    if ((d.Attributes & FileAttributes.ReparsePoint) != 0) continue;
                    if (Cfg.PurgeNames.Contains(d.Name, StringComparer.OrdinalIgnoreCase))
                    {
                        long s = Size(d.FullName);
                        try { d.Delete(true); freed += s; } catch (Exception) { }
                    }
                    else if (depth < 4) freed += PurgeCaches(d.FullName, depth + 1);
                }
            }
            catch (Exception) { }
            return freed;
        }
        // 예전 Electron 판이 남긴 데이터 폴더인지 (Electron 흔적이 있는 것만)
        public static List<string> FindLegacy()
        {
            var res = new List<string>();
            var roots = new[] { Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData) };
            foreach (var r in roots.Distinct())
                foreach (var n in Cfg.LegacyNames)
                {
                    var p = Path.Combine(r, n);
                    if (!Directory.Exists(p)) continue;
                    bool electron = Directory.Exists(Path.Combine(p, "Partitions")) || Directory.Exists(Path.Combine(p, "Local Storage")) || Directory.Exists(Path.Combine(p, "Code Cache")) || File.Exists(Path.Combine(p, "choimini-desktop.json"));
                    if (electron) res.Add(p);
                }
            return res;
        }
    }

    /* ---------------- 보안문자 ---------------- */
    class Captcha
    {
        const string Chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
        static readonly RandomNumberGenerator Rng = RandomNumberGenerator.Create();
        public static int R(int n) { var b = new byte[4]; Rng.GetBytes(b); return (int)(BitConverter.ToUInt32(b, 0) % (uint)n); }
        string text; DateTime expires; int tries; DateTime lockedUntil = DateTime.MinValue;
        public bool Locked { get { return DateTime.Now < lockedUntil; } }
        public int RetrySec { get { return (int)Math.Ceiling((lockedUntil - DateTime.Now).TotalSeconds); } }
        public Bitmap New()
        {
            var sb = new StringBuilder(); for (int i = 0; i < 5; i++) sb.Append(Chars[R(Chars.Length)]);
            text = sb.ToString(); expires = DateTime.Now.AddSeconds(120); tries = 0;
            var bmp = new Bitmap(220, 80);
            using (var g = Graphics.FromImage(bmp))
            {
                g.SmoothingMode = SmoothingMode.AntiAlias; g.Clear(Color.FromArgb(21, 24, 38));
                for (int i = 0; i < 7; i++) using (var p = new Pen(Color.FromArgb(180, 80 + R(150), 80 + R(150), 80 + R(150)), 1 + R(2))) g.DrawBezier(p, R(220), R(80), R(220), R(80), R(220), R(80), R(220), R(80));
                for (int i = 0; i < 40; i++) using (var b = new SolidBrush(Color.FromArgb(150, 80 + R(150), 80 + R(150), 80 + R(150)))) { int r = 1 + R(2); g.FillEllipse(b, R(220), R(80), r * 2, r * 2); }
                float step = (220 - 30) / (float)text.Length;
                for (int i = 0; i < text.Length; i++)
                {
                    float x = 22 + i * step, y = 40 + R(12) - 6, rot = R(50) - 25;
                    using (var f = new Font("Verdana", 20 + R(6), FontStyle.Bold))
                    using (var b = new SolidBrush(Color.FromArgb(255, 150 + R(100), 150 + R(100), 150 + R(100))))
                    {
                        var st = g.Save(); g.TranslateTransform(x, y); g.RotateTransform(rot);
                        g.DrawString(text[i].ToString(), f, b, 0, -18); g.Restore(st);
                    }
                }
            }
            return bmp;
        }
        // 0 = 통과, 1 = 틀림(남은 기회 있음), 2 = 잠김, 3 = 만료
        public int Verify(string input)
        {
            if (Locked) return 2;
            if (text == null || DateTime.Now > expires) return 3;
            tries++;
            if ((input ?? "").Trim().ToUpperInvariant() == text) { text = null; return 0; }
            if (tries >= 3) { text = null; lockedUntil = DateTime.Now.AddSeconds(30); return 2; }
            return 1;
        }
    }

    class CaptchaForm : Form
    {
        readonly Captcha cap; readonly PictureBox pic = new PictureBox(); readonly TextBox box = new TextBox(); readonly Label msg = new Label();
        public CaptchaForm(Captcha c, string purpose)
        {
            cap = c; Text = "보안문자 확인"; FormBorderStyle = FormBorderStyle.FixedDialog; StartPosition = FormStartPosition.CenterParent; MaximizeBox = false; MinimizeBox = false; ClientSize = new Size(340, 250); ShowInTaskbar = false;
            var t = new Label { Left = 16, Top = 12, Width = 308, Height = 44, Text = purpose == "full" ? "⚠ 전체 승인: AI 가 컴퓨터에서 묻지 않고 작업해요.\n아래 글자를 입력해야 켤 수 있어요." : "내 컴퓨터(Local)에서 AI 가 작업하려면\n아래 글자를 입력해 주세요." };
            pic.Left = 60; pic.Top = 62; pic.Width = 220; pic.Height = 80; pic.SizeMode = PictureBoxSizeMode.StretchImage;
            box.Left = 60; box.Top = 152; box.Width = 160; box.CharacterCasing = CharacterCasing.Upper; box.MaxLength = 8; box.Font = new Font("Consolas", 12);
            var refresh = new Button { Left = 226, Top = 151, Width = 54, Height = 28, Text = "새로" };
            refresh.Click += delegate { Reload(); };
            msg.Left = 16; msg.Top = 186; msg.Width = 308; msg.Height = 20; msg.ForeColor = Color.Firebrick;
            var ok = new Button { Left = 150, Top = 212, Width = 84, Height = 28, Text = "확인" };
            var cancel = new Button { Left = 240, Top = 212, Width = 84, Height = 28, Text = "취소", DialogResult = DialogResult.Cancel };
            ok.Click += delegate
            {
                int r = cap.Verify(box.Text);
                if (r == 0) { DialogResult = DialogResult.OK; Close(); return; }
                if (r == 2) { msg.Text = "너무 많이 틀렸어요. " + cap.RetrySec + "초 뒤에 다시 시도하세요."; return; }
                if (r == 3) { Reload(); msg.Text = "시간이 지나 새 글자로 바꿨어요."; return; }
                msg.Text = "틀렸어요. 다시 입력해 주세요."; box.SelectAll();
            };
            AcceptButton = ok; CancelButton = cancel;
            Controls.AddRange(new Control[] { t, pic, box, refresh, msg, ok, cancel });
            Reload();
        }
        void Reload() { if (cap.Locked) { msg.Text = cap.RetrySec + "초 뒤에 다시 시도하세요."; return; } var old = pic.Image; pic.Image = cap.New(); if (old != null) old.Dispose(); box.Clear(); box.Focus(); }
    }

    /* ---------------- 승인 창 ---------------- */
    class PermReq { public string Kind, Title, Detail, Diff, Key, Risk, Reason; public bool Sensitive; }
    class PermissionForm : Form
    {
        public string Choice = "deny";
        public PermissionForm(PermReq r)
        {
            Text = "AI 가 허락을 요청해요"; StartPosition = FormStartPosition.CenterParent; ClientSize = new Size(640, r.Diff != null && r.Diff.Length > 0 ? 520 : 330); MinimizeBox = false; MaximizeBox = false; FormBorderStyle = FormBorderStyle.FixedDialog; ShowInTaskbar = false;
            bool danger = r.Risk == "danger";
            var head = new Label { Left = 14, Top = 10, Width = 612, Height = 24, Text = (danger ? "⚠ " : "") + r.Title, Font = new Font(SystemFonts.MessageBoxFont, FontStyle.Bold), ForeColor = danger ? Color.Firebrick : SystemColors.ControlText };
            var detail = new TextBox { Left = 14, Top = 38, Width = 612, Height = 120, Multiline = true, ReadOnly = true, ScrollBars = ScrollBars.Vertical, Font = new Font("Consolas", 9.5f), Text = (r.Detail ?? "").Replace("\n", "\r\n") };
            Controls.Add(head); Controls.Add(detail);
            int y = 166;
            if (r.Diff != null && r.Diff.Length > 0)
            {
                var diff = new TextBox { Left = 14, Top = 166, Width = 612, Height = 270, Multiline = true, ReadOnly = true, ScrollBars = ScrollBars.Both, WordWrap = false, Font = new Font("Consolas", 9), Text = r.Diff.Replace("\r\n", "\n").Replace("\n", "\r\n") };
                Controls.Add(diff); y = 446;
            }
            else detail.Height = 220;
            var by = r.Diff != null && r.Diff.Length > 0 ? 476 : 280;
            Button b1 = new Button { Left = 14, Top = by, Width = 130, Height = 32, Text = "이번만 허용" };
            Button b2 = new Button { Left = 150, Top = by, Width = 190, Height = 32, Text = r.Kind == "command" ? "이 명령은 이번 세션 허용" : (r.Kind == "read" ? "읽기는 이번 세션 허용" : "수정은 이번 세션 허용"), Enabled = !r.Sensitive };
            Button b3 = new Button { Left = 520, Top = by, Width = 106, Height = 32, Text = "거부" };
            b1.Click += delegate { Choice = "once"; Close(); };
            b2.Click += delegate { Choice = "session"; Close(); };
            b3.Click += delegate { Choice = "deny"; Close(); };
            AcceptButton = null; CancelButton = b3;
            Controls.AddRange(new Control[] { b1, b2, b3 });
            Shown += delegate { b3.Focus(); }; // 기본 포커스는 "거부" (엔터 연타로 허용되는 사고 방지)
        }
    }

    /* ---------------- 메인 창 ---------------- */
    class MainForm : Form
    {
        readonly WebView2 wv = new WebView2();
        readonly string siteUrl; readonly string siteOrigin;
        readonly Captcha captcha = new Captcha();
        readonly Dictionary<string, string> prompts = new Dictionary<string, string>();
        readonly List<PermissionForm> openPerm = new List<PermissionForm>();
        readonly Dictionary<string, Process> procs = new Dictionary<string, Process>();
        string codePromptBase = "";
        string scriptId;

        bool authOk, codeUnlocked, fullAllowed;
        string activeMode = "chat", permMode = "manual", workspace;
        bool sessAllowEdits, sessAllowReads; readonly HashSet<string> sessAllowCmds = new HashSet<string>();
        bool agentAborted; int activitySeq;

        bool CodeAllowed { get { return authOk && codeUnlocked && activeMode == "code"; } }

        public MainForm()
        {
            var dev = Environment.GetEnvironmentVariable("CHOIMINI_DEV_SITE");
            siteUrl = !string.IsNullOrEmpty(dev) && dev.StartsWith("http") ? dev : Cfg.SiteUrl;
            siteOrigin = new Uri(siteUrl).GetLeftPart(UriPartial.Authority);
            Text = "Choimini Desktop"; Width = 1320; Height = 840; StartPosition = FormStartPosition.CenterScreen; BackColor = Color.FromArgb(10, 11, 15);
            try { Icon = Icon.ExtractAssociatedIcon(Application.ExecutablePath); } catch (Exception) { }
            try { codePromptBase = File.ReadAllText(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "code-prompt.txt"), Encoding.UTF8); } catch (Exception) { }
            var s = Json.Dict(SafeRead(Cfg.SettingsFile)); var w = Json.Str(s, "workspace"); if (w.Length > 0 && Directory.Exists(w)) workspace = w;
            BuildMenu();
            wv.Dock = DockStyle.Fill; Controls.Add(wv); wv.BringToFront();
            Shown += async delegate { await InitWeb(); };
            FormClosing += delegate { DenyAllPending(); KillProcs(); };
        }
        static string SafeRead(string p) { try { return File.ReadAllText(p); } catch (Exception) { return "{}"; } }
        void SaveWorkspace() { try { Directory.CreateDirectory(Cfg.DataRoot); File.WriteAllText(Cfg.SettingsFile, Json.To(new Dictionary<string, object> { { "workspace", workspace } })); } catch (Exception) { } }
        void KillProcs() { foreach (var p in procs.Values.ToList()) KillTree(p); procs.Clear(); }
        static void KillTree(Process p)
        {
            try { if (p != null && !p.HasExited) Process.Start(new ProcessStartInfo("taskkill", "/PID " + p.Id + " /T /F") { CreateNoWindow = true, UseShellExecute = false }); } catch (Exception) { }
            try { if (p != null && !p.HasExited) p.Kill(); } catch (Exception) { }
        }

        void BuildMenu()
        {
            var ms = new MenuStrip();
            var m = new ToolStripMenuItem("앱");
            m.DropDownItems.Add("작업 폴더 변경 (Local)", null, delegate { PickWorkspace(); });
            m.DropDownItems.Add("저장공간 보기/정리", null, delegate { ShowStorage(); });
            m.DropDownItems.Add("새로고침", null, delegate { if (wv.CoreWebView2 != null) wv.CoreWebView2.Reload(); });
            m.DropDownItems.Add("정보", null, delegate { MessageBox.Show(this, "Choimini Desktop " + Cfg.Version + " (WebView2)\n데이터 폴더: " + Cfg.DataRoot, "정보"); });
            ms.Items.Add(m); ms.Dock = DockStyle.Top; MainMenuStrip = ms; Controls.Add(ms);
        }

        async Task InitWeb()
        {
            string ver;
            try { ver = CoreWebView2Environment.GetAvailableBrowserVersionString(); } catch (Exception) { ver = null; }
            if (string.IsNullOrEmpty(ver))
            {
                if (MessageBox.Show(this, "Microsoft Edge WebView2 런타임이 필요해요. (Windows 11 에는 기본 포함)\n다운로드 페이지를 열까요?", "Choimini Desktop", MessageBoxButtons.YesNo, MessageBoxIcon.Information) == DialogResult.Yes)
                    try { Process.Start("https://go.microsoft.com/fwlink/p/?LinkId=2124703"); } catch (Exception) { }
                Close(); return;
            }
            Directory.CreateDirectory(Cfg.WebData);
            Disk.PurgeCaches(Cfg.WebData); // 시작 전에 다시 만들어지는 캐시를 비운다
            var opts = new CoreWebView2EnvironmentOptions("--disk-cache-size=" + Cfg.CacheLimit + " --media-cache-size=8388608 --disable-gpu-shader-disk-cache --disable-features=msSmartScreenProtection,msEdgeShopping,msWebOAuth --no-first-run");
            var env = await CoreWebView2Environment.CreateAsync(null, Cfg.WebData, opts);
            await wv.EnsureCoreWebView2Async(env);
            var core = wv.CoreWebView2;
            core.Settings.AreDevToolsEnabled = false;
            core.Settings.AreDefaultContextMenusEnabled = true;
            core.Settings.IsStatusBarEnabled = false;
            core.Settings.IsZoomControlEnabled = true;
            core.Settings.UserAgent = core.Settings.UserAgent + " " + Cfg.UaSuffix;
            core.AddWebResourceRequestedFilter(siteOrigin + "/*", CoreWebView2WebResourceContext.All);
            core.AddWebResourceRequestedFilter("https://challenges.cloudflare.com/*", CoreWebView2WebResourceContext.All);
            core.WebResourceRequested += OnResourceRequested;
            core.NewWindowRequested += delegate (object s, CoreWebView2NewWindowRequestedEventArgs e) { e.Handled = true; OpenExternal(e.Uri); };
            core.NavigationStarting += delegate (object s, CoreWebView2NavigationStartingEventArgs e)
            {
                Uri u; if (!Uri.TryCreate(e.Uri, UriKind.Absolute, out u)) return;
                if (u.Scheme == "about" || u.Scheme == "data" || u.Scheme == "blob") return;
                if (u.GetLeftPart(UriPartial.Authority) != siteOrigin) { e.Cancel = true; OpenExternal(e.Uri); }
            };
            core.WebMessageReceived += OnMessage;
            core.PermissionRequested += delegate (object s, CoreWebView2PermissionRequestedEventArgs e) { if (e.PermissionKind != CoreWebView2PermissionKind.ClipboardRead) e.State = CoreWebView2PermissionState.Default; };
            core.DocumentTitleChanged += delegate { Text = "Choimini Desktop v" + Cfg.Version; };
            await RegisterScript();
            core.Navigate(siteUrl);
        }

        void OpenExternal(string url)
        {
            try { Uri u = new Uri(url); if (u.Scheme == "https" || u.Scheme == "http") Process.Start(u.AbsoluteUri); } catch (Exception) { }
        }

        void OnResourceRequested(object sender, CoreWebView2WebResourceRequestedEventArgs e)
        {
            if (e.Request.Uri.StartsWith("https://challenges.cloudflare.com/") || e.Request.Uri.Contains(".challenges.cloudflare.com/"))
            {
                e.Response = wv.CoreWebView2.Environment.CreateWebResourceResponse(null, 403, "Blocked", "");
                return;
            }
            e.Request.Headers.SetHeader(Cfg.AppHeaderName, Cfg.AppHeaderValue);
        }

        /* ---------- 사이트에 주입하는 브리지 (문서가 만들어지기 전에 실행) ---------- */
        string BuildBridgeScript()
        {
            var st = CodeAllowed ? Json.To(new Dictionary<string, object> { { "mode", "code" }, { "prompt", BuildCodePrompt() }, { "perm", permMode } }) : "{\"mode\":\"chat\",\"prompt\":\"\",\"perm\":\"manual\"}";
            return @"(function(){
  if (window.__chmBridge) return;
  var st = " + st + @", seq = 0, pend = {};
  function ro(n, v){ try{ Object.defineProperty(window, n, { value: v, writable:false, enumerable:true, configurable:false }); }catch(e){} }
  function rg(n, g){ try{ Object.defineProperty(window, n, { get:g, enumerable:true, configurable:false }); }catch(e){} }
  function post(o){ try{ window.chrome.webview.postMessage(JSON.stringify(o)); }catch(e){} }
  function call(type, payload){ return new Promise(function(res){ var id = 'r' + (++seq) + '_' + Date.now(); pend[id] = res; post({type:type, id:id, payload:payload}); }); }
  window.chrome.webview.addEventListener('message', function(ev){
    var m = ev.data; if (typeof m === 'string') { try{ m = JSON.parse(m); }catch(e){ return; } }
    if (m.type === 'result'){ var r = pend[m.id]; if (r){ delete pend[m.id]; r(m.value); } }
    else if (m.type === 'state'){
      st.mode = m.mode === 'code' ? 'code' : 'chat'; st.prompt = st.mode === 'code' ? String(m.prompt||'') : ''; st.perm = (m.perm==='auto'||m.perm==='full') ? m.perm : 'manual';
      try{ window.dispatchEvent(new CustomEvent(m.kind === 'perm' ? 'choimini-perm' : 'choimini-mode', {detail:{mode:st.mode, perm:st.perm}})); }catch(e){}
    }
    else if (m.type === 'auth-callback'){ try{ window.__choiminiHandleAuthCallback && window.__choiminiHandleAuthCallback(String(m.url)); }catch(e){} }
  });
  ro('__chmBridge', true); ro('CHOIMINI_APP', 'desktop'); ro('CHOIMINI_SKIP_CLOUDFLARE', true);
  rg('CHOIMINI_MODE', function(){ return st.mode; }); rg('CHOIMINI_CODE_MODE_PROMPT', function(){ return st.prompt; }); rg('CHOIMINI_PERM', function(){ return st.perm; });
  ro('DesktopBridge', Object.freeze({
    openAuth: function(url){ post({type:'open-auth', payload:String(url)}); },
    callTool: function(tool, args){ return call('tool-call', {tool:String(tool), args:(args && typeof args==='object') ? args : {}}); },
    reportAuth: function(v){ post({type:'auth-state', payload: !!v}); },
    setLocal: function(on){ return call('set-local', !!on); },
    setPerm: function(m){ post({type:'set-perm', payload:String(m)}); }
  }));
  /* Cloudflare 확인 제거 (앱은 웹사이트가 아니다) */
  function unlock(){ try{ var r = document.documentElement; if (r && r.classList.contains('jcv2-locked')) r.classList.remove('jcv2-locked'); var g = document.getElementById('jcv2-gate'); if (g) g.remove(); }catch(e){} }
  function watch(root){ unlock(); var mo = new MutationObserver(unlock); mo.observe(root, {childList:true, subtree:true, attributes:true, attributeFilter:['class']}); window.addEventListener('load', function(){ setTimeout(function(){ unlock(); mo.disconnect(); }, 8000); }); }
  if (document.documentElement) watch(document.documentElement);
  else { var w = new MutationObserver(function(){ if (document.documentElement){ w.disconnect(); watch(document.documentElement); } }); w.observe(document, {childList:true}); }
})();";
        }
        async Task RegisterScript()
        {
            try { if (scriptId != null) wv.CoreWebView2.RemoveScriptToExecuteOnDocumentCreated(scriptId); } catch (Exception) { }
            scriptId = await wv.CoreWebView2.AddScriptToExecuteOnDocumentCreatedAsync(BuildBridgeScript());
        }

        void Post(object o) { try { if (wv.CoreWebView2 != null) wv.CoreWebView2.PostWebMessageAsString(Json.To(o)); } catch (Exception) { } }
        void PushState(string kind)
        {
            bool code = CodeAllowed;
            Post(new Dictionary<string, object> { { "type", "state" }, { "kind", kind }, { "mode", code ? "code" : "chat" }, { "prompt", code ? BuildCodePrompt() : "" }, { "perm", code ? permMode : "manual" } });
            var _ = RegisterScript(); // 다음 새로고침에서도 값이 맞도록 초기 상태를 갱신
        }
        public void ForwardAuthCallback(string url)
        {
            if (!url.StartsWith("choimini://")) return;
            Post(new Dictionary<string, object> { { "type", "auth-callback" }, { "url", url } });
            if (WindowState == FormWindowState.Minimized) WindowState = FormWindowState.Normal; Activate();
        }

        string BuildCodePrompt()
        {
            string w = workspace != null ? "작업 폴더: " + workspace : "작업 폴더: (아직 선택되지 않음 — 사용자에게 상단 메뉴의 '앱 > 작업 폴더 변경'을 눌러 달라고 안내하세요)";
            string m = permMode == "full" ? "전체 승인(사용자 승인 창 없이 진행 — 그래도 파괴적인 작업은 신중하게)" : permMode == "auto" ? "자동 승인(안전한 읽기/파일 수정/읽기 전용 명령은 자동, 다운로드·설치·삭제·코드 실행처럼 사용자 동의가 필요한 작업은 승인)" : "수동 승인(읽기·수정·명령 모두 작업할 때마다 사용자가 승인)";
            return codePromptBase + "\n\n[현재 상태]\n실행 위치: Local(사용자 컴퓨터)\n" + w + "\nAI 권한: " + m;
        }

        /* ---------- 메시지 처리 ---------- */
        async void OnMessage(object sender, CoreWebView2WebMessageReceivedEventArgs e)
        {
            try
            {
                Uri src; if (!Uri.TryCreate(e.Source, UriKind.Absolute, out src) || src.GetLeftPart(UriPartial.Authority) != siteOrigin) return; // 우리 사이트가 아니면 무시
                string raw; try { raw = e.TryGetWebMessageAsString(); } catch (Exception) { return; }
                var m = Json.Dict(raw); if (m == null) return;
                string type = Json.Str(m, "type"), id = Json.Str(m, "id");
                object payload; m.TryGetValue("payload", out payload);
                switch (type)
                {
                    case "open-auth": { string u = Convert.ToString(payload); Uri uu; if (Uri.TryCreate(u, UriKind.Absolute, out uu) && uu.Scheme == "https") OpenExternal(u); break; }
                    case "auth-state":
                        authOk = payload is bool && (bool)payload;
                        if (!authOk) { bool was = activeMode == "code"; ForceChat(); KillProcs(); if (was) { PushState("mode"); } }
                        break;
                    case "set-perm": await SetPerm(Convert.ToString(payload)); break;
                    case "set-local": { bool ok = await SetLocal(payload is bool && (bool)payload); Post(new Dictionary<string, object> { { "type", "result" }, { "id", id }, { "value", ok } }); break; }
                    case "tool-call":
                        {
                            var d = payload as Dictionary<string, object>; var args = d != null && d.ContainsKey("args") ? d["args"] as Dictionary<string, object> : null;
                            var res = await HandleTool(Json.Str(d, "tool"), args ?? new Dictionary<string, object>());
                            Post(new Dictionary<string, object> { { "type", "result" }, { "id", id }, { "value", res } });
                            break;
                        }
                }
            }
            catch (Exception ex) { Debug.WriteLine(ex); }
        }

        void ResetPerm() { permMode = "manual"; fullAllowed = false; }
        void ResetSession() { sessAllowEdits = false; sessAllowReads = false; sessAllowCmds.Clear(); }
        void ForceChat() { activeMode = "chat"; ResetPerm(); DenyAllPending(); ResetSession(); }

        bool AskCaptcha(string purpose)
        {
            if (captcha.Locked) { MessageBox.Show(this, captcha.RetrySec + "초 뒤에 다시 시도하세요.", "보안문자", MessageBoxButtons.OK, MessageBoxIcon.Information); return false; }
            using (var f = new CaptchaForm(captcha, purpose)) return f.ShowDialog(this) == DialogResult.OK;
        }

        async Task<bool> SetLocal(bool on)
        {
            await Task.Yield();
            if (!on) { if (activeMode == "code") { ForceChat(); PushState("mode"); } return true; }
            if (!authOk) { MessageBox.Show(this, "먼저 로그인해 주세요.", "Local", MessageBoxButtons.OK, MessageBoxIcon.Information); return false; }
            if (!codeUnlocked) { if (!AskCaptcha("code")) return false; codeUnlocked = true; }
            if (workspace == null || !Directory.Exists(workspace)) { if (!PickWorkspace()) { return false; } }
            activeMode = "code"; ResetPerm(); PushState("mode"); return true;
        }

        async Task SetPerm(string mode)
        {
            await Task.Yield();
            if (mode != "manual" && mode != "auto" && mode != "full") return;
            if (mode == "full")
            {
                if (!CodeAllowed) { PushState("perm"); return; }
                if (!AskCaptcha("full")) { PushState("perm"); return; }
                fullAllowed = true;
                if (!(CodeAllowed && fullAllowed)) { PushState("perm"); return; }
                fullAllowed = false;
            }
            else fullAllowed = false;
            permMode = mode; PushState("perm");
        }

        bool PickWorkspace()
        {
            using (var d = new FolderBrowserDialog { Description = "AI 가 작업할 폴더를 선택하세요 (이 폴더 밖은 접근할 수 없어요)", ShowNewFolderButton = true })
            {
                if (workspace != null && Directory.Exists(workspace)) d.SelectedPath = workspace;
                if (d.ShowDialog(this) != DialogResult.OK || !Directory.Exists(d.SelectedPath)) return false;
                workspace = d.SelectedPath; SaveWorkspace(); ResetSession(); if (permMode == "full") ResetPerm();
                if (activeMode == "code") PushState("perm");
                return true;
            }
        }

        /* ---------- 승인 ---------- */
        bool NeedsAsk(PermReq r)
        {
            if (permMode == "full") return false;
            if (permMode == "manual") return true;
            if (r.Kind == "read") return false;
            if (r.Kind == "edit") return r.Sensitive;
            if (r.Kind == "command") return r.Risk != "safe";
            return true;
        }
        void DenyAllPending() { foreach (var f in openPerm.ToList()) { try { f.Choice = "deny"; f.Close(); } catch (Exception) { } } }
        async Task<bool> RequestPermission(PermReq r)
        {
            if (!NeedsAsk(r)) return true;
            if (r.Kind == "read" && sessAllowReads) return true;
            if (r.Kind == "edit" && sessAllowEdits && !r.Sensitive) return true;
            if (r.Kind == "command" && sessAllowCmds.Contains(r.Key)) return true;
            await Task.Yield();
            using (var f = new PermissionForm(r))
            {
                openPerm.Add(f);
                try { f.ShowDialog(this); } finally { openPerm.Remove(f); }
                if (f.Choice == "session") { if (r.Kind == "edit") sessAllowEdits = true; else if (r.Kind == "read") sessAllowReads = true; else sessAllowCmds.Add(r.Key); }
                return f.Choice == "once" || f.Choice == "session";
            }
        }

        /* ---------- 도구 실행 ---------- */
        static string Clip(string s, int n) { return s != null && s.Length > n ? s.Substring(0, n) + "…" : (s ?? ""); }
        static Dictionary<string, object> Err(string m) { return new Dictionary<string, object> { { "ok", false }, { "error", m } }; }
        static Dictionary<string, object> Deny(string what) { return new Dictionary<string, object> { { "ok", false }, { "denied", true }, { "error", "[거부] 사용자가 " + what + "을(를) 허용하지 않았어요. 다른 방법을 제안하거나 이유를 물어보세요." } }; }
        static Dictionary<string, object> Res(ToolResult r) { var d = new Dictionary<string, object> { { "ok", r.Ok }, { "output", r.Output } }; return d; }
        static string A(Dictionary<string, object> a, string k) { object v; return a.TryGetValue(k, out v) && v != null ? Convert.ToString(v) : ""; }

        async Task<Dictionary<string, object>> HandleTool(string tool, Dictionary<string, object> a)
        {
            if (!authOk) return Err("[차단] 로그인이 필요해요. 로그인한 뒤에 사용할 수 있어요.");
            if (!codeUnlocked) return Err("[차단] Local 모드 보안문자 인증이 필요해요.");
            if (activeMode != "code") return Err("[차단] Local 모드에서만 도구를 쓸 수 있어요.");
            if (agentAborted) { agentAborted = false; return new Dictionary<string, object> { { "ok", false }, { "aborted", true }, { "error", "[중단됨] 사용자가 작업을 중단했어요." } }; }
            try
            {
                if (tool == "todo_write") { var t = Tools.TodoWrite(a); return Res(t); }
                if (workspace == null) throw new ToolError("작업 폴더가 선택되지 않았어요. 사용자에게 상단 메뉴 '앱 > 작업 폴더 변경'을 눌러 달라고 안내하세요.");
                var ws = Tools.MakeWorkspace(workspace);
                switch (tool)
                {
                    case "read_file": case "list_dir": case "glob": case "grep":
                        {
                            string sum = tool == "read_file" ? "읽기 " + A(a, "path") : tool == "list_dir" ? "폴더 보기 " + (A(a, "path").Length > 0 ? A(a, "path") : ".") : tool == "glob" ? "파일 찾기 " + A(a, "pattern") : "내용 검색 " + A(a, "pattern");
                            if (!await RequestPermission(new PermReq { Kind = "read", Title = sum, Detail = sum + "\n\n(작업 폴더: " + ws.Root + ")" })) return Deny("읽기");
                            ToolResult r = tool == "read_file" ? Tools.ReadFile(ws, a) : tool == "list_dir" ? Tools.ListDir(ws, a) : tool == "glob" ? Tools.Glob(ws, a) : Tools.Grep(ws, a);
                            return Res(r);
                        }
                    case "write_file": case "edit_file":
                        {
                            Prepared p = tool == "write_file" ? Tools.PrepareWriteFile(ws, a) : Tools.PrepareEditFile(ws, a);
                            bool sens = Tools.IsSensitivePath(p.Rel);
                            if (!await RequestPermission(new PermReq { Kind = "edit", Title = p.Title, Detail = p.Rel + (sens ? "\n\n비밀 값/설정/자동 실행 파일일 수 있는 민감한 파일이에요" : ""), Diff = p.Diff, Sensitive = sens, Risk = sens ? "danger" : "normal" })) return Deny("변경");
                            return Res(p.Apply());
                        }
                    case "run_command":
                        {
                            string cmd = A(a, "command").Trim();
                            if (cmd.Length == 0) throw new ToolError("command 가 필요해요.");
                            if (cmd.Length > 8000) throw new ToolError("명령이 너무 길어요.");
                            var cls = Tools.ClassifyCommand(cmd);
                            if (!await RequestPermission(new PermReq { Kind = "command", Title = "명령 실행", Detail = (cls.Key != "safe" && !string.IsNullOrEmpty(cls.Value) ? "⚠ " + cls.Value + "\n\n" : "") + cmd + "\n\n(작업 폴더: " + ws.Root + ")", Key = cmd, Risk = cls.Key, Reason = cls.Value })) return Deny("명령 실행");
                            int to = 120000; try { to = Math.Min(Math.Max(Convert.ToInt32(a.ContainsKey("timeout_ms") ? a["timeout_ms"] : 120000), 1000), 600000); } catch (Exception) { }
                            var r = await RunShell(cmd, ws.Root, to);
                            string output = ("종료코드 " + r.Item1 + "\n" + r.Item2).TrimEnd();
                            return new Dictionary<string, object> { { "ok", true }, { "exitCode", r.Item1 }, { "output", Clip(output, 30000) } };
                        }
                    default: throw new ToolError("알 수 없는 도구예요: " + tool);
                }
            }
            catch (ToolError te) { return Err(te.Message); }
            catch (Exception ex) { return Err("예상치 못한 오류: " + ex.Message); }
        }

        Task<Tuple<int, string>> RunShell(string cmd, string cwd, int timeoutMs)
        {
            var tcs = new TaskCompletionSource<Tuple<int, string>>();
            var sb = new StringBuilder(); bool done = false; Process p = null;
            var psi = new ProcessStartInfo(Environment.GetEnvironmentVariable("COMSPEC") ?? "cmd.exe") { Arguments = "/d /s /c \"" + cmd + "\"", WorkingDirectory = cwd, UseShellExecute = false, CreateNoWindow = true, RedirectStandardOutput = true, RedirectStandardError = true, RedirectStandardInput = true, StandardOutputEncoding = Encoding.UTF8, StandardErrorEncoding = Encoding.UTF8 };
            Action<int, string> finish = (code, extra) =>
            {
                lock (sb) { if (done) return; done = true; }
                string o; lock (sb) o = sb.ToString() + (extra ?? "");
                tcs.TrySetResult(Tuple.Create(code, o));
            };
            try
            {
                p = Process.Start(psi);
                try { p.StandardInput.Close(); } catch (Exception) { }
                DataReceivedEventHandler h = (s, ev) => { if (ev.Data == null) return; lock (sb) { sb.AppendLine(ev.Data); if (sb.Length > 60000) { var t = sb.ToString(); sb.Clear(); sb.Append("…(앞부분 생략)…\n" + t.Substring(t.Length - 30000)); } } };
                // 사용자가 중간에 앱을 닫아도 남지 않도록 추적
                string pid = Guid.NewGuid().ToString(); procs[pid] = p;
                p.OutputDataReceived += h; p.ErrorDataReceived += h; p.BeginOutputReadLine(); p.BeginErrorReadLine();
                var timer = new System.Threading.Timer(_ => { KillTree(p); finish(-4, "\n[시간 초과] " + (timeoutMs / 1000) + "초를 넘어 중단했어요."); }, null, timeoutMs, Timeout.Infinite);
                var waiter = new Thread(() => { try { p.WaitForExit(); } catch (Exception) { } try { timer.Dispose(); } catch (Exception) { } int code = -1; try { code = p.ExitCode; } catch (Exception) { } finish(code, null); BeginInvoke((Action)(() => procs.Remove(pid))); }) { IsBackground = true };
                waiter.Start();
            }
            catch (Exception ex) { finish(-1, "\n[오류] " + ex.Message); }
            return tcs.Task;
        }

        /* ---------- 저장공간 ---------- */
        void ShowStorage()
        {
            long total = Disk.Size(Cfg.DataRoot), cache = 0, site = 0;
            var legacy = Disk.FindLegacy();
            try
            {
                foreach (var d in Directory.GetDirectories(Cfg.WebData, "*", SearchOption.AllDirectories))
                {
                    var n = Path.GetFileName(d);
                    if (Cfg.PurgeNames.Contains(n, StringComparer.OrdinalIgnoreCase) || n == "Cache") cache += Disk.Size(d);
                    else if (n == "Local Storage" || n == "IndexedDB") site += Disk.Size(d);
                }
            }
            catch (Exception) { }
            var sb = new StringBuilder();
            sb.AppendLine("앱 데이터 폴더: " + Cfg.DataRoot);
            sb.AppendLine("전체: " + Disk.Fmt(total));
            sb.AppendLine("  캐시(지워도 됨): " + Disk.Fmt(cache));
            sb.AppendLine("  사이트 데이터(로그인·Linux Local): " + Disk.Fmt(site));
            if (legacy.Count > 0)
            {
                sb.AppendLine().AppendLine("⚠ 예전 Electron 판이 남긴 폴더:");
                foreach (var p in legacy) sb.AppendLine("  " + p + "  (" + Disk.Fmt(Disk.Size(p)) + ")");
            }
            sb.AppendLine().AppendLine("[예]를 누르면 " + (legacy.Count > 0 ? "예전 폴더와 " : "") + "캐시를 정리해요. 예전 폴더 안의 Linux Local 파일은 새 앱으로 옮겨지지 않아요.");
            if (MessageBox.Show(this, sb.ToString(), "저장공간", MessageBoxButtons.YesNo, MessageBoxIcon.Information) != DialogResult.Yes) return;
            if (legacy.Count > 0 && MessageBox.Show(this, "예전 Electron 판 데이터 폴더를 삭제할까요? 되돌릴 수 없어요.\n\n" + string.Join("\n", legacy), "예전 데이터 삭제", MessageBoxButtons.YesNo, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
                foreach (var p in legacy) { try { Directory.Delete(p, true); } catch (Exception) { } }
            try { if (wv.CoreWebView2 != null) wv.CoreWebView2.Profile.ClearBrowsingDataAsync(CoreWebView2BrowsingDataKinds.DiskCache | CoreWebView2BrowsingDataKinds.CacheStorage | CoreWebView2BrowsingDataKinds.ServiceWorkers); } catch (Exception) { }
        }

        /* 시작 시 한 번: 예전 Electron 판 데이터가 있으면 알려 준다 */
        public void OfferLegacyCleanup()
        {
            var legacy = Disk.FindLegacy(); if (legacy.Count == 0) return;
            long sz = legacy.Sum(p => Disk.Size(p));
            if (sz < 50L * 1024 * 1024) return;
            var r = MessageBox.Show(this, "예전 Electron 판이 남긴 데이터가 " + Disk.Fmt(sz) + " 있어요.\n\n" + string.Join("\n", legacy) + "\n\n지금 삭제할까요? (새 앱은 별도 폴더를 쓰며 훨씬 작아요. 예전 Linux Local 파일은 옮겨지지 않으니 필요하면 먼저 백업하세요.)", "예전 데이터 정리", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2);
            if (r == DialogResult.Yes) foreach (var p in legacy) { try { Directory.Delete(p, true); } catch (Exception) { } }
        }
    }

    static class Program
    {
        const string PipeName = "ChoiminiDesktop.Handoff";
        static MainForm form;

        static void RegisterProtocol()
        {
            try
            {
                string exe = Application.ExecutablePath;
                using (var k = Microsoft.Win32.Registry.CurrentUser.CreateSubKey(@"Software\Classes\choimini"))
                {
                    k.SetValue("", "URL:Choimini"); k.SetValue("URL Protocol", "");
                    using (var c = k.CreateSubKey(@"shell\open\command")) c.SetValue("", "\"" + exe + "\" \"%1\"");
                }
            }
            catch (Exception) { }
        }

        [STAThread]
        static void Main(string[] args)
        {
            string url = args.FirstOrDefault(a => a.StartsWith("choimini://"));
            bool created;
            var mutex = new Mutex(true, "Choimini.Desktop.SingleInstance", out created);
            if (!created)
            {
                // 이미 실행 중 → 로그인 콜백 URL 만 전달하고 끝낸다
                try { using (var c = new NamedPipeClientStream(".", PipeName, PipeDirection.Out)) { c.Connect(1500); var b = Encoding.UTF8.GetBytes(url ?? "focus"); c.Write(b, 0, b.Length); } } catch (Exception) { }
                return;
            }
            RegisterProtocol();
            Application.EnableVisualStyles(); Application.SetCompatibleTextRenderingDefault(false);
            form = new MainForm();
            var t = new Thread(PipeLoop) { IsBackground = true }; t.Start();
            form.Shown += delegate { form.BeginInvoke((Action)(() => { form.OfferLegacyCleanup(); })); if (url != null) form.BeginInvoke((Action)(() => form.ForwardAuthCallback(url))); };
            Application.Run(form);
            GC.KeepAlive(mutex);
        }

        static void PipeLoop()
        {
            while (true)
            {
                try
                {
                    using (var s = new NamedPipeServerStream(PipeName, PipeDirection.In, 1))
                    {
                        s.WaitForConnection();
                        var buf = new byte[4096]; int n = s.Read(buf, 0, buf.Length);
                        string msg = Encoding.UTF8.GetString(buf, 0, n);
                        var f = form; if (f != null && !f.IsDisposed) f.BeginInvoke((Action)(() => { if (msg.StartsWith("choimini://")) f.ForwardAuthCallback(msg); else { if (f.WindowState == FormWindowState.Minimized) f.WindowState = FormWindowState.Normal; f.Activate(); } }));
                    }
                }
                catch (Exception) { Thread.Sleep(300); }
            }
        }
    }
}
