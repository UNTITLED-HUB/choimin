// Cloudflare 확인 제거 테스트 — 사이트가 "아직 예전 버전"이어도 앱이 직접 지우는지 확인한다.
// 실제 GitHub 에 올라가 있던 예전 index.html(site/index.original.html)을 로컬 서버로 그대로 서빙한다.
const { spawn } = require("child_process"), http = require("http"), fs = require("fs"), os = require("os"), path = require("path");
const WebSocket = require("ws");
const PORT = 9339, SITE_PORT = 8767;
const APP = process.env.APP || path.join(__dirname, "..");
const ELECTRON = process.env.ELECTRON_BIN || path.join(__dirname, "..", "node_modules", "electron", "dist", "electron");
const OLD_SITE = path.join(__dirname, "..", "..", "site", "index.original.html");
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
let pass = 0, failN = 0;
const check = (n, ok, x) => { ok ? pass++ : failN++; console.log((ok ? "  PASS " : "  FAIL ") + n + (ok ? "" : "  " + (x || ""))); };
const getJson = (u) => new Promise((res, rej) => http.get(u, (r) => { let b = ""; r.on("data", (d) => (b += d)); r.on("end", () => res(JSON.parse(b))); }).on("error", rej));

const html = fs.readFileSync(OLD_SITE, "utf8");
const requested = [];
const site = http.createServer((q, r) => { requested.push(q.url); if (q.url.split("?")[0] === "/") { r.writeHead(200, { "Content-Type": "text/html; charset=utf-8" }); r.end(html); } else { r.writeHead(404); r.end(); } });

(async () => {
  await new Promise((r) => site.listen(SITE_PORT, "127.0.0.1", r));
  const ud = fs.mkdtempSync(path.join(os.tmpdir(), "nocf-"));
  const el = spawn(ELECTRON, [APP, "--no-sandbox", "--disable-gpu", `--remote-debugging-port=${PORT}`, `--user-data-dir=${ud}`],
    { env: { ...process.env, DISPLAY: process.env.DISPLAY || ":99", CHOIMINI_DEV_SITE: `http://127.0.0.1:${SITE_PORT}/` }, stdio: "ignore" });
  let targets;
  for (let i = 0; i < 50; i++) { try { targets = await getJson(`http://127.0.0.1:${PORT}/json`); if (targets.some((t) => /renderer\/index\.html/.test(t.url))) break; } catch (_) {} await sleep(400); }
  const page = (targets || []).find((t) => /renderer\/index\.html/.test(t.url));
  if (!page) { console.log("no page"); el.kill(); process.exit(1); }
  const cdp = new WebSocket(page.webSocketDebuggerUrl); await new Promise((r) => cdp.on("open", r));
  let id = 0; const pend = {}; cdp.on("message", (m) => { const j = JSON.parse(m); if (j.id && pend[j.id]) { pend[j.id](j); delete pend[j.id]; } });
  const host = (expr) => new Promise((res) => { const i = ++id; pend[i] = res; cdp.send(JSON.stringify({ id: i, method: "Runtime.evaluate", params: { expression: expr, awaitPromise: true, returnByValue: true } })); }).then((r) => (r.result && r.result.result ? r.result.result.value : undefined));
  const inPage = (code) => host(`document.getElementById('choimini').executeJavaScript(${JSON.stringify(code)})`);
  await sleep(6000);   // 예전 사이트가 뜰 시간 (외부 CDN 은 오프라인이라 실패해도 게이트 마크업은 그대로 있다)

  console.log("\n[Desktop + the OLD live site]");
  check("(sanity) the page really is the old site and it contains the Cloudflare gate markup in its source", html.includes('id="jcv2-gate"') && html.includes('class="jcv2-locked"') && html.includes("challenges.cloudflare.com/turnstile"));
  check("(sanity) the old site was actually loaded by the app", requested.includes("/") || requested.some((u) => u.startsWith("/")));
  check("Cloudflare gate element is gone", (await inPage("!document.getElementById('jcv2-gate')")) === true);
  check("page is not locked (html no longer has jcv2-locked)", (await inPage("!document.documentElement.classList.contains('jcv2-locked')")) === true);
  check("the page content is actually visible (not hidden behind the gate)", (await inPage("Array.from(document.body.children).filter(e=>!/^(SCRIPT|STYLE|LINK)$/.test(e.tagName)).some(e=>getComputedStyle(e).display!=='none')")) === true);
  check("no Cloudflare widget/iframe is on the page", (await inPage("document.querySelectorAll('.cf-turnstile iframe, iframe[src*=\"challenges.cloudflare.com\"]').length")) === 0);
  await sleep(2500);
  check("still unlocked a few seconds later (nothing re-locks it)", (await inPage("!document.getElementById('jcv2-gate') && !document.documentElement.classList.contains('jcv2-locked')")) === true);
  console.log(`\n${pass} passed, ${failN} failed`);
  cdp.close(); el.kill(); site.close(); await sleep(300); process.exit(failN ? 1 : 0);
})();
