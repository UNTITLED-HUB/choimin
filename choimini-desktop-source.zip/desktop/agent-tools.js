"use strict";
// Choimini Code 도구 계층 (Claude Code 와 같은 종류의 도구): read_file / list_dir / glob / grep / write_file / edit_file / todo_write
// - Electron 과 무관한 순수 모듈 → 단위 테스트 가능. run_command 는 프로세스 실행이라 main.js 에서 처리한다.
// - 모든 경로는 "작업 폴더" 안으로 제한된다(.. 이동, 절대경로, 심볼릭 링크 우회 차단). .git 내부는 쓰기 금지.
const fs = require("fs");
const path = require("path");

const MAX_READ_BYTES = 2 * 1024 * 1024;
const MAX_LINES = 2000;
const MAX_WRITE_BYTES = 1024 * 1024;
const MAX_WALK = 30000;
const SKIP_DIRS = new Set(["node_modules", ".git"]);

class ToolError extends Error {}
const fail = (m) => { throw new ToolError(m); };
const posix = (p) => p.split(path.sep).join("/");

function makeWorkspace(root) {
  if (!root) fail("작업 폴더가 선택되지 않았어요. 상단의 '작업 폴더 선택'을 눌러 주세요.");
  let real;
  try { real = fs.realpathSync(root); } catch (_) { fail("작업 폴더를 열 수 없어요: " + root); }
  function resolve(p) {
    const input = p == null || p === "" ? "." : String(p);
    if (input.includes("\0")) fail("잘못된 경로예요.");
    const abs = path.resolve(real, input);
    // 아직 없는 파일이면 "존재하는 가장 가까운 상위 폴더"의 실제 경로로 검사 (심볼릭 링크로 밖으로 나가는 것 방지)
    let probe = abs;
    while (!fs.existsSync(probe)) { const up = path.dirname(probe); if (up === probe) break; probe = up; }
    const rel = path.relative(real, fs.realpathSync(probe));
    if (rel === ".." || rel.startsWith(".." + path.sep) || path.isAbsolute(rel)) fail("작업 폴더 밖은 접근할 수 없어요: " + input);
    return abs;
  }
  return { root: real, resolve, rel: (abs) => posix(path.relative(real, abs)) || "." };
}

const isGitInternal = (ws, abs) => ws.rel(abs).split("/").includes(".git");
function statOrFail(abs, what) { try { return fs.statSync(abs); } catch (_) { fail(`${what || "파일"}이(가) 없어요: ${abs}`); } }
function readText(abs) {
  const st = statOrFail(abs);
  if (st.isDirectory()) fail("디렉터리예요. list_dir 를 쓰세요.");
  if (st.size > MAX_READ_BYTES) fail(`파일이 너무 커요 (${st.size}B, 최대 2MB). grep 으로 필요한 부분만 찾으세요.`);
  const buf = fs.readFileSync(abs);
  if (buf.subarray(0, 8192).includes(0)) fail("바이너리 파일이라 읽을 수 없어요.");
  return buf.toString("utf8");
}

/* ---------------- 읽기 도구 ---------------- */
function read_file(ws, a) {
  const abs = ws.resolve(a.path);
  const lines = readText(abs).split(/\r?\n/);
  const start = Math.max(1, Number(a.offset) || 1);
  const n = Math.min(Math.max(1, Number(a.limit) || MAX_LINES), MAX_LINES);
  const slice = lines.slice(start - 1, start - 1 + n);
  const body = slice.map((l, i) => String(start + i).padStart(5) + "\t" + (l.length > 2000 ? l.slice(0, 2000) + "…" : l)).join("\n");
  const more = start - 1 + n < lines.length ? `\n… (전체 ${lines.length}줄 중 ${start}-${start - 1 + slice.length} 표시. offset=${start + slice.length} 로 이어서 읽기)` : "";
  return { ok: true, output: (body || "(빈 파일)") + more };
}

function list_dir(ws, a) {
  const abs = ws.resolve(a.path || ".");
  if (!statOrFail(abs, "폴더").isDirectory()) fail("폴더가 아니에요: " + a.path);
  const ents = fs.readdirSync(abs, { withFileTypes: true }).sort((x, y) => (y.isDirectory() - x.isDirectory()) || x.name.localeCompare(y.name));
  const out = ents.slice(0, 500).map((e) => e.isDirectory() ? e.name + "/" : e.name + "  (" + fs.statSync(path.join(abs, e.name)).size + "B)");
  return { ok: true, output: (out.join("\n") || "(빈 폴더)") + (ents.length > 500 ? `\n… ${ents.length - 500}개 더 있음` : "") };
}

const escapeRe = (c) => c.replace(/[.+^$()|[\]\\]/g, "\\$&");
function globToRegex(g) {
  let re = "";
  for (let i = 0; i < g.length; i++) {
    const c = g[i];
    if (c === "*") {
      if (g[i + 1] === "*") { i++; if (g[i + 1] === "/") { i++; re += "(?:.*/)?"; } else re += ".*"; } else re += "[^/]*";
    } else if (c === "?") re += "[^/]";
    else if (c === "{") { const j = g.indexOf("}", i); if (j > i) { re += "(?:" + g.slice(i + 1, j).split(",").map((x) => x.replace(/[.+^$()|[\]\\*?]/g, "\\$&")).join("|") + ")"; i = j; } else re += "\\{"; }
    else re += escapeRe(c);
  }
  return new RegExp("^" + re + "$");
}
function* walk(ws, dirAbs, budget) {
  let entries; try { entries = fs.readdirSync(dirAbs, { withFileTypes: true }); } catch (_) { return; }
  for (const e of entries) {
    if (budget.n++ > MAX_WALK) return;
    const abs = path.join(dirAbs, e.name);
    if (e.isDirectory()) { if (!SKIP_DIRS.has(e.name)) yield* walk(ws, abs, budget); }
    else if (e.isFile()) yield abs;   // 심볼릭 링크는 따라가지 않는다(작업 폴더 밖 유출 방지)
  }
}

function glob(ws, a) {
  if (!a.pattern) fail("pattern 이 필요해요.");
  const base = ws.resolve(a.path || ".");
  const re = globToRegex(String(a.pattern));
  const out = [];
  for (const f of walk(ws, base, { n: 0 })) { const r = posix(path.relative(base, f)); if (re.test(r)) { out.push(ws.rel(f)); if (out.length >= 300) break; } }
  return { ok: true, output: out.length ? out.join("\n") + (out.length >= 300 ? "\n… (300개에서 자름)" : "") : "(일치하는 파일 없음)" };
}

function grep(ws, a) {
  if (!a.pattern) fail("pattern 이 필요해요.");
  let re; try { re = new RegExp(String(a.pattern), a.ignore_case ? "i" : ""); } catch (e) { fail("정규식이 올바르지 않아요: " + e.message); }
  const base = ws.resolve(a.path || ".");
  const gre = a.glob ? globToRegex(String(a.glob)) : null;
  const hits = [];
  const single = fs.statSync(base).isFile();
  for (const f of single ? [base] : walk(ws, base, { n: 0 })) {
    if (gre && !gre.test(posix(path.relative(single ? path.dirname(base) : base, f)))) continue;
    let st; try { st = fs.statSync(f); } catch (_) { continue; }
    if (st.size > 1024 * 1024) continue;
    let buf; try { buf = fs.readFileSync(f); } catch (_) { continue; }
    if (buf.subarray(0, 4096).includes(0)) continue;
    const lines = buf.toString("utf8").split(/\r?\n/);
    for (let i = 0; i < lines.length; i++) {
      if (re.test(lines[i])) { hits.push(`${ws.rel(f)}:${i + 1}:${lines[i].length > 300 ? lines[i].slice(0, 300) + "…" : lines[i]}`); if (hits.length >= 200) break; }
    }
    if (hits.length >= 200) break;
  }
  return { ok: true, output: hits.length ? hits.join("\n") + (hits.length >= 200 ? "\n… (200개에서 자름)" : "") : "(일치하는 내용 없음)" };
}

/* ---------------- diff (사용자에게 보여줄 변경 내용) ---------------- */
function makeDiff(oldText, newText, context = 3) {
  const a = oldText.split("\n"), b = newText.split("\n");
  if (a.length * b.length > 4e6) return `(변경이 커서 요약만 표시) -${a.length}줄 +${b.length}줄`;
  const n = a.length, m = b.length, dp = new Int32Array((n + 1) * (m + 1));
  for (let i = n - 1; i >= 0; i--) for (let j = m - 1; j >= 0; j--) dp[i * (m + 1) + j] = a[i] === b[j] ? dp[(i + 1) * (m + 1) + j + 1] + 1 : Math.max(dp[(i + 1) * (m + 1) + j], dp[i * (m + 1) + j + 1]);
  const ops = []; let i = 0, j = 0;
  while (i < n && j < m) {
    if (a[i] === b[j]) { ops.push([" ", a[i]]); i++; j++; }
    else if (dp[(i + 1) * (m + 1) + j] >= dp[i * (m + 1) + j + 1]) ops.push(["-", a[i++]]); else ops.push(["+", b[j++]]);
  }
  while (i < n) ops.push(["-", a[i++]]); while (j < m) ops.push(["+", b[j++]]);
  const keep = new Array(ops.length).fill(false);
  ops.forEach((o, k) => { if (o[0] !== " ") for (let d = -context; d <= context; d++) if (ops[k + d]) keep[k + d] = true; });
  const out = []; let gap = false;
  ops.forEach((o, k) => { if (keep[k]) { if (gap) out.push("…"); gap = false; out.push(o[0] + " " + o[1]); } else gap = true; });
  return out.join("\n").slice(0, 20000);
}

/* ---------------- 쓰기 도구: prepare(변경 미리보기) → apply(실제 적용) ---------------- */
function prepare_write_file(ws, a) {
  const abs = ws.resolve(a.path);
  if (isGitInternal(ws, abs)) fail(".git 내부는 수정할 수 없어요.");
  if (typeof a.content !== "string") fail("content(문자열)가 필요해요.");
  if (Buffer.byteLength(a.content) > MAX_WRITE_BYTES) fail("내용이 너무 커요 (최대 1MB).");
  let old = null;
  if (fs.existsSync(abs)) { if (fs.statSync(abs).isDirectory()) fail("폴더에는 쓸 수 없어요."); old = readText(abs); }
  const rel = ws.rel(abs);
  return {
    rel, creating: old === null,
    title: (old === null ? "새 파일 만들기: " : "파일 덮어쓰기: ") + rel,
    diff: old === null ? a.content.split("\n").slice(0, 200).map((l) => "+ " + l).join("\n") : makeDiff(old, a.content),
    apply() { fs.mkdirSync(path.dirname(abs), { recursive: true }); fs.writeFileSync(abs, a.content); return { ok: true, output: `${old === null ? "만들었어요" : "덮어썼어요"}: ${rel} (${a.content.split("\n").length}줄)` }; },
  };
}

function prepare_edit_file(ws, a) {
  const abs = ws.resolve(a.path);
  if (isGitInternal(ws, abs)) fail(".git 내부는 수정할 수 없어요.");
  if (typeof a.old_string !== "string" || a.old_string === "") fail("old_string(바꿀 기존 텍스트)이 필요해요.");
  if (typeof a.new_string !== "string") fail("new_string 이 필요해요.");
  if (a.old_string === a.new_string) fail("old_string 과 new_string 이 같아요.");
  const text = readText(abs);
  const count = text.split(a.old_string).length - 1;
  if (count === 0) fail("old_string 을 파일에서 찾지 못했어요. 공백/들여쓰기까지 정확히 같아야 해요. read_file 로 다시 확인하세요.");
  if (count > 1 && !a.replace_all) fail(`old_string 이 ${count}곳에서 발견돼 어디를 바꿀지 알 수 없어요. 앞뒤 문맥을 더 포함하거나 replace_all=true 를 쓰세요.`);
  const next = a.replace_all ? text.split(a.old_string).join(a.new_string) : text.replace(a.old_string, () => a.new_string);
  const rel = ws.rel(abs);
  return { rel, title: `수정: ${rel}${count > 1 ? ` (${count}곳)` : ""}`, diff: makeDiff(text, next),
    apply() { fs.writeFileSync(abs, next); return { ok: true, output: `수정했어요: ${rel}${count > 1 ? ` (${count}곳)` : ""}` }; } };
}

function todo_write(a) {
  if (!Array.isArray(a.items)) fail("items 배열이 필요해요.");
  const items = a.items.slice(0, 50).map((t) => ({ text: String(t && t.text || "").slice(0, 200), status: ["pending", "in_progress", "completed"].includes(t && t.status) ? t.status : "pending" }));
  return { ok: true, output: "할 일 목록을 갱신했어요.", items };
}

module.exports = { ToolError, makeWorkspace, read_file, list_dir, glob, grep, prepare_write_file, prepare_edit_file, todo_write, makeDiff, globToRegex };
