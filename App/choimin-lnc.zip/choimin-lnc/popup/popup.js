// 팝업 스크립트

let currentData = {};
let currentSiteEventActions = [];
let currentShortcutAction = 'openUrl';

// 초기화
document.addEventListener('DOMContentLoaded', init);

async function init() {
  await loadData();
  attachEventListeners();
  updateDashboard();
}

// 데이터 로드
async function loadData() {
  currentData = await StorageManager.load();
}

// 이벤트 리스너 부착
function attachEventListeners() {
  // 네비게이션
  document.querySelectorAll('.nav-btn').forEach(btn => {
    btn.addEventListener('click', (e) => {
      document.querySelectorAll('.nav-btn').forEach(b => b.classList.remove('active'));
      document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));
      e.target.classList.add('active');
      document.getElementById(e.target.dataset.tab).classList.add('active');
    });
  });

  // 확장앱 토글
  document.getElementById('extensionToggle').addEventListener('change', async (e) => {
    const enabled = e.target.checked;
    await StorageManager.toggleExtension(enabled);
    await TabSettingsManager.broadcastToggle(enabled);
    updateStatusDisplay(enabled);
    await loadData();
  });

  // 사이트 이벤트
  document.getElementById('addCloseTabAction').addEventListener('click', () => {
    addSiteEventAction('closeTab');
  });

  document.getElementById('addOpenUrlAction').addEventListener('click', () => {
    addSiteEventAction('openUrl');
  });

  document.getElementById('addRotateAction').addEventListener('click', () => {
    addSiteEventAction('rotateScreen');
  });

  document.getElementById('saveSiteEvent').addEventListener('click', saveSiteEvent);

  // 단축키 이벤트
  document.getElementById('shortcutType').addEventListener('change', (e) => {
    updateShortcutUIForType(e.target.value);
  });

  document.getElementById('shortcutAction').addEventListener('change', (e) => {
    currentShortcutAction = e.target.value;
    updateShortcutActionUI();
  });

  document.getElementById('saveShortcutEvent').addEventListener('click', saveShortcutEvent);

  // 전체 탭 설정
  document.getElementById('applyCursorBtn').addEventListener('click', applyCursor);
  document.getElementById('applyRotationBtn').addEventListener('click', applyRotation);
  document.getElementById('replaceImagesBtn').addEventListener('click', replaceImages);
  document.getElementById('restoreImagesBtn').addEventListener('click', restoreImages);
  document.getElementById('changePageTitleBtn').addEventListener('click', changePageTitle);
  document.getElementById('resetPageTitleBtn').addEventListener('click', resetPageTitle);

  // 설정
  document.getElementById('clearLogBtn').addEventListener('click', clearEventLog);
  document.getElementById('exportSettingsBtn').addEventListener('click', exportSettings);
  document.getElementById('importSettingsBtn').addEventListener('click', importSettings);
  document.getElementById('resetAllBtn').addEventListener('click', resetAll);

  // Event delegation for dynamic elements
  document.getElementById('actionsList').addEventListener('click', (e) => {
    if (e.target.classList.contains('action-remove')) {
      const index = parseInt(e.target.dataset.index);
      removeSiteEventAction(index);
    }
  });

  document.getElementById('siteEventsList').addEventListener('click', (e) => {
    if (e.target.dataset.action === 'toggle') {
      toggleSiteEvent(e.target.dataset.id);
    } else if (e.target.dataset.action === 'delete') {
      deleteSiteEvent(e.target.dataset.id);
    }
  });

  document.getElementById('shortcutEventsList').addEventListener('click', (e) => {
    if (e.target.dataset.action === 'toggle') {
      toggleShortcutEvent(e.target.dataset.id);
    } else if (e.target.dataset.action === 'delete') {
      deleteShortcutEvent(e.target.dataset.id);
    }
  });
}

// 상태 표시 업데이트
function updateStatusDisplay(enabled) {
  const text = enabled ? 'ON' : 'OFF';
  document.getElementById('statusText').textContent = text;
  document.getElementById('dashboardStatus').textContent = text;
  document.getElementById('extensionToggle').checked = enabled;
}

// 대시보드 업데이트
async function updateDashboard() {
  await loadData();

  const tabCount = await new Promise((resolve) => {
    chrome.tabs.query({}, (tabs) => resolve(tabs.length));
  });

  document.getElementById('siteEventCount').textContent = currentData.siteEvents.length;
  document.getElementById('shortcutEventCount').textContent = currentData.shortcutEvents.length;
  document.getElementById('tabCount').textContent = tabCount;
  updateStatusDisplay(currentData.enabled);
  updateEventLog();
  updateSiteEventsList();
  updateShortcutEventsList();
}

// 이벤트 로그 표시
function updateEventLog() {
  const logDiv = document.getElementById('eventLog');
  logDiv.innerHTML = '';

  if (!currentData.eventLog || currentData.eventLog.length === 0) {
    logDiv.innerHTML = '<p style="color: var(--text-muted); font-size: 11px;">최근 이벤트 없음</p>';
    return;
  }

  currentData.eventLog.slice(0, 10).forEach(log => {
    const item = document.createElement('div');
    item.className = 'event-item';
    item.innerHTML = `
      <div class="event-time">${log.timestamp || ''}</div>
      <div class="event-desc">${log.description || log.type || ''}</div>
    `;
    logDiv.appendChild(item);
  });
}

// 사이트 이벤트 액션 추가
function addSiteEventAction(type) {
  let actionHTML = '';
  const index = currentSiteEventActions.length;

  switch (type) {
    case 'closeTab':
      actionHTML = `
        <div class="action-item">
          <div class="action-text">
            <input type="number" min="1" max="3600" value="5" class="form-control" style="width: 50px; padding: 4px;">
            초 후 탭 닫기
          </div>
          <button class="action-remove" data-index="${index}">×</button>
        </div>
      `;
      currentSiteEventActions.push({ type: 'closeTab', delay: 5 });
      break;

    case 'openUrl':
      actionHTML = `
        <div class="action-item">
          <div class="action-text">
            <input type="text" placeholder="https://example.com" value="" class="form-control" style="width: 200px; padding: 4px;">
            열기
          </div>
          <button class="action-remove" data-index="${index}">×</button>
        </div>
      `;
      currentSiteEventActions.push({ type: 'openUrl', url: '' });
      break;

    case 'rotateScreen':
      actionHTML = `
        <div class="action-item">
          <div class="action-text">
            화면
            <input type="number" min="0" max="360" step="1" value="90" class="form-control" style="width: 60px; padding: 4px;">
            도 회전
          </div>
          <button class="action-remove" data-index="${index}">×</button>
        </div>
      `;
      currentSiteEventActions.push({ type: 'rotateScreen', degree: 90 });
      break;
  }

  const container = document.getElementById('actionsList');
  if (!container.querySelector('.action-item')) {
    container.innerHTML = '';
  }

  const div = document.createElement('div');
  div.innerHTML = actionHTML;
  container.appendChild(div.firstElementChild);
}

function removeSiteEventAction(index) {
  currentSiteEventActions.splice(index, 1);
  renderSiteEventActions();
}

function renderSiteEventActions() {
  const container = document.getElementById('actionsList');
  container.innerHTML = '';

  currentSiteEventActions.forEach((action, index) => {
    let actionHTML = '';

    switch (action.type) {
      case 'closeTab':
        actionHTML = `
          <div class="action-item">
            <div class="action-text">${action.delay}초 후 탭 닫기</div>
            <button class="action-remove" data-index="${index}">×</button>
          </div>
        `;
        break;
      case 'openUrl':
        actionHTML = `
          <div class="action-item">
            <div class="action-text">${action.url} 열기</div>
            <button class="action-remove" data-index="${index}">×</button>
          </div>
        `;
        break;
      case 'rotateScreen':
        actionHTML = `
          <div class="action-item">
            <div class="action-text">화면 ${action.degree}도 회전</div>
            <button class="action-remove" data-index="${index}">×</button>
          </div>
        `;
        break;
    }

    const div = document.createElement('div');
    div.innerHTML = actionHTML;
    container.appendChild(div.firstElementChild);
  });
}

// 사이트 이벤트 저장
async function saveSiteEvent() {
  const url = document.getElementById('siteUrl').value.trim();

  if (!url || !EventManager.isValidUrl(url)) {
    alert('올바른 URL을 입력해주세요.');
    return;
  }

  if (currentSiteEventActions.length === 0) {
    alert('최소 하나의 이벤트를 추가해주세요.');
    return;
  }

  // 폼 값 수집
  const actionsList = document.getElementById('actionsList');
  const actionInputs = actionsList.querySelectorAll('.action-item');
  const actions = [];

  actionInputs.forEach((item, index) => {
    const action = currentSiteEventActions[index];
    const inputs = item.querySelectorAll('input, select');

    if (action.type === 'closeTab') {
      action.delay = parseInt(inputs[0]?.value) || 5;
    } else if (action.type === 'openUrl') {
      action.url = inputs[0]?.value || '';
    } else if (action.type === 'rotateScreen') {
      let degree = parseInt(inputs[0]?.value);
      if (isNaN(degree)) degree = 90;
      degree = ((degree % 360) + 360) % 360;
      action.degree = degree;
    }

    actions.push(action);
  });

  const event = {
    url: url,
    actions: actions
  };

  await StorageManager.addSiteEvent(event);
  alert('규칙이 저장되었습니다.');

  // 초기화
  document.getElementById('siteUrl').value = '';
  document.getElementById('actionsList').innerHTML = '';
  currentSiteEventActions = [];

  await updateDashboard();
}

// 사이트 이벤트 목록 업데이트
async function updateSiteEventsList() {
  const container = document.getElementById('siteEventsList');
  container.innerHTML = '';

  if (currentData.siteEvents.length === 0) {
    container.innerHTML = '<p style="color: var(--text-muted); font-size: 11px;">등록된 규칙이 없습니다.</p>';
    return;
  }

  currentData.siteEvents.forEach(event => {
    const item = document.createElement('div');
    item.className = 'rule-item';
    item.innerHTML = `
      <div class="rule-info">
        <div class="rule-url">${event.url}</div>
        <div class="rule-actions">${event.actions.map(a => a.type).join(', ')}</div>
      </div>
      <div class="rule-buttons">
        <button class="rule-btn" data-action="toggle" data-id="${event.id}">
          ${event.enabled ? '비활성' : '활성'}
        </button>
        <button class="rule-btn delete" data-action="delete" data-id="${event.id}">삭제</button>
      </div>
    `;
    container.appendChild(item);
  });
}

async function toggleSiteEvent(id) {
  const event = currentData.siteEvents.find(e => e.id === id);
  if (event) {
    event.enabled = !event.enabled;
    await StorageManager.updateSiteEvent(id, event);
    await updateDashboard();
  }
}

async function deleteSiteEvent(id) {
  if (confirm('삭제하시겠습니까?')) {
    await StorageManager.deleteSiteEvent(id);
    await updateDashboard();
  }
}

// 단축키 이벤트 UI 업데이트
function updateShortcutUIForType(type) {
  if (type === 'anyKey') {
    document.getElementById('shortcutKey').style.display = 'none';
    document.querySelector('label[for="shortcutKey"]').style.display = 'none';
  } else {
    document.getElementById('shortcutKey').style.display = 'block';
    document.querySelector('label[for="shortcutKey"]').style.display = 'block';
  }
}

function updateShortcutActionUI() {
  const urlLabel = document.getElementById('urlLabel');
  const urlInput = document.getElementById('shortcutUrl');
  const closeCountLabel = document.getElementById('closeCountLabel');
  const closeCountInput = document.getElementById('shortcutCloseCount');

  if (currentShortcutAction === 'openUrl') {
    urlLabel.style.display = 'block';
    urlInput.style.display = 'block';
    closeCountLabel.style.display = 'none';
    closeCountInput.style.display = 'none';
  } else {
    urlLabel.style.display = 'none';
    urlInput.style.display = 'none';
    closeCountLabel.style.display = 'block';
    closeCountInput.style.display = 'block';
  }
}

// 단축키 이벤트 저장
async function saveShortcutEvent() {
  const type = document.getElementById('shortcutType').value;
  const count = parseInt(document.getElementById('shortcutCount').value);
  const key = document.getElementById('shortcutKey').value.toUpperCase();
  const action = currentShortcutAction;
  const timeLimit = parseInt(document.getElementById('shortcutTimeLimit').value);

  if (!EventManager.isValidNumber(count)) {
    alert('유효한 입력 횟수를 입력해주세요.');
    return;
  }

  const event = {
    type: type,
    key: key,
    count: count,
    action: action,
    timeLimit: timeLimit,
    caseSensitive: false
  };

  if (action === 'openUrl') {
    const url = document.getElementById('shortcutUrl').value.trim();
    if (!EventManager.isValidUrl(url)) {
      alert('올바른 URL을 입력해주세요.');
      return;
    }
    event.url = url;
  } else {
    event.closeCount = parseInt(document.getElementById('shortcutCloseCount').value);
  }

  await StorageManager.addShortcutEvent(event);
  alert('규칙이 저장되었습니다.');

  // 폼 초기화
  document.getElementById('shortcutType').value = 'specificKey';
  document.getElementById('shortcutKey').value = '';
  document.getElementById('shortcutCount').value = '5';
  document.getElementById('shortcutAction').value = 'openUrl';
  document.getElementById('shortcutUrl').value = '';
  document.getElementById('shortcutCloseCount').value = '1';
  document.getElementById('shortcutTimeLimit').value = '2';

  updateShortcutUIForType('specificKey');
  updateShortcutActionUI();
  await updateDashboard();
}

// 단축키 이벤트 목록 업데이트
async function updateShortcutEventsList() {
  const container = document.getElementById('shortcutEventsList');
  container.innerHTML = '';

  if (currentData.shortcutEvents.length === 0) {
    container.innerHTML = '<p style="color: var(--text-muted); font-size: 11px;">등록된 규칙이 없습니다.</p>';
    return;
  }

  currentData.shortcutEvents.forEach(event => {
    const actionText = event.action === 'openUrl' ? `${event.url} 열기` : `${event.closeCount}개 탭 닫기`;
    const item = document.createElement('div');
    item.className = 'rule-item';
    item.innerHTML = `
      <div class="rule-info">
        <div class="rule-url">${event.type === 'anyKey' ? '아무 키' : event.key} x${event.count}</div>
        <div class="rule-actions">${actionText}</div>
      </div>
      <div class="rule-buttons">
        <button class="rule-btn" data-action="toggle" data-id="${event.id}">
          ${event.enabled ? '비활성' : '활성'}
        </button>
        <button class="rule-btn delete" data-action="delete" data-id="${event.id}">삭제</button>
      </div>
    `;
    container.appendChild(item);
  });
}

async function toggleShortcutEvent(id) {
  const event = currentData.shortcutEvents.find(e => e.id === id);
  if (event) {
    event.enabled = !event.enabled;
    await StorageManager.updateShortcutEvent(id, event);
    await updateDashboard();
  }
}

async function deleteShortcutEvent(id) {
  if (confirm('삭제하시겠습니까?')) {
    await StorageManager.deleteShortcutEvent(id);
    await updateDashboard();
  }
}

// 전체 탭 설정
async function applyCursor() {
  const url = document.getElementById('cursorImageUrl').value.trim();
  if (!EventManager.isValidUrl(url)) {
    alert('올바른 URL을 입력해주세요.');
    return;
  }

  const result = await TabSettingsManager.applyCursorImage(url);
  if (!result.success) {
    if (result.reason === 'disabled') {
      alert('확장앱이 꺼져 있습니다. 먼저 상단의 토글을 켜주세요.');
    }
    return;
  }
  alert('커서가 적용되었습니다.');
}

async function applyRotation() {
  const degree = parseInt(document.getElementById('rotationDegree').value);

  if (isNaN(degree)) {
    alert('올바른 각도를 입력해주세요.');
    return;
  }

  const applyNewTabs = document.getElementById('applyNewTabs').checked;
  await StorageManager.updateTabSettings({ applyNewTabs: applyNewTabs });

  const result = await TabSettingsManager.applyRotation(degree);
  if (!result.success) {
    if (result.reason === 'disabled') {
      alert('확장앱이 꺼져 있습니다. 먼저 상단의 토글을 켜주세요.');
    }
    return;
  }
  alert('회전이 적용되었습니다.');
}

async function replaceImages() {
  const url = document.getElementById('replaceImageUrl').value.trim();
  if (!EventManager.isValidUrl(url)) {
    alert('올바른 URL을 입력해주세요.');
    return;
  }

  const result = await TabSettingsManager.replaceImages(url);
  if (!result.success) {
    if (result.reason === 'disabled') {
      alert('확장앱이 꺼져 있습니다. 먼저 상단의 토글을 켜주세요.');
    }
    return;
  }
  alert('이미지가 변경되었습니다.');
}

async function restoreImages() {
  await TabSettingsManager.restoreOriginalImages();
  alert('원본 이미지가 복구되었습니다.');
}

// 설정
async function clearEventLog() {
  if (confirm('이벤트 로그를 삭제하시겠습니까?')) {
    await StorageManager.clearEventLog();
    await updateDashboard();
  }
}

async function exportSettings() {
  const data = await StorageManager.load();
  const json = JSON.stringify(data, null, 2);
  const blob = new Blob([json], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = 'choimin-lnc-settings.json';
  a.click();
}

async function importSettings() {
  const input = document.createElement('input');
  input.type = 'file';
  input.accept = 'application/json';
  input.addEventListener('change', async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = async (event) => {
      try {
        const data = JSON.parse(event.target.result);
        await chrome.storage.local.set(data);
        alert('설정을 가져왔습니다.');
        await updateDashboard();
      } catch (error) {
        alert('올바른 설정 파일이 아닙니다.');
      }
    };
    reader.readAsText(file);
  });
  input.click();
}

async function resetAll() {
  if (confirm('모든 설정을 초기화하시겠습니까? 이 작업은 되돌릴 수 없습니다.')) {
    await chrome.storage.local.clear();
    await chrome.storage.local.set(StorageManager.defaultData);
    alert('모든 설정이 초기화되었습니다.');
    await updateDashboard();
  }
}

// 페이지 제목 변경
async function changePageTitle() {
  const title = document.getElementById('pageTitle').value.trim();
  
  if (!title) {
    alert('페이지 제목을 입력해주세요.');
    return;
  }

  const result = await TabSettingsManager.changePageTitle(title);
  if (!result.success) {
    if (result.reason === 'disabled') {
      alert('확장앱이 꺼져 있습니다. 먼저 상단의 토글을 켜주세요.');
    }
    return;
  }
  alert('페이지 제목이 변경되었습니다.');
  document.getElementById('pageTitle').value = '';
}

// 페이지 제목 원래대로
async function resetPageTitle() {
  await TabSettingsManager.changePageTitle(null);
  
  chrome.tabs.query({}, (tabs) => {
    tabs.forEach(tab => {
      chrome.tabs.sendMessage(tab.id, {
        type: 'resetPageTitle'
      }).catch(() => {});
    });
  });

  alert('페이지 제목이 원래대로 복구되었습니다.');
  document.getElementById('pageTitle').value = '';
}
