// agent.js 테스트 (jsdom): 커서 표시, 좌표 클릭, 제출 확인 유지, 키 입력, find/get_html, 민감 필드 보호
// 실행: NODE_PATH=<jsdom 경로> node test/agent.test.js
const { JSDOM } = require("jsdom"), fs = require("fs"), path = require("path");
let pass = 0, failN = 0;
const check = (n, ok, x) => { ok ? pass++ : failN++; console.log((ok ? "  PASS " : "  FAIL ") + n + (ok ? "" : "  " + (x || ""))); };

const html = `<body>
<a id="lnk" href="#go">Go page</a>
<button id="b1">좋아요</button>
<form id="f" action="/send"><input id="q" name="q" aria-label="검색어"><input id="pw" type="password" name="password"><button id="sb" type="submit">보내기</button></form>
<div id="hov">메뉴</div>
<input id="val" value="secret-token">
</body>`;
const dom = new JSDOM(html, { url: "https://example.com/", runScripts: "outside-only", pretendToBeVisual: true });
const w = dom.window, d = w.document;
// 레이아웃 흉내: 모든 요소 100x20 박스, id 별 위치
const pos = { lnk: [10, 10], b1: [10, 40], q: [10, 70], pw: [10, 100], sb: [10, 130], hov: [10, 160], val: [10, 190] };
w.HTMLElement.prototype.getBoundingClientRect = function () { const p = pos[this.id] || [0, 0]; return { left: p[0], top: p[1], width: 100, height: 20, right: p[0] + 100, bottom: p[1] + 20 }; };
w.HTMLElement.prototype.scrollIntoView = function () {};
d.elementFromPoint = (x, y) => { for (const id in pos) { const [l, t] = pos[id]; if (x >= l && x <= l + 100 && y >= t && y <= t + 20) return d.getElementById(id); } return null; };
w.devicePixelRatio = 2;
w.CSS = { escape: (x) => String(x).replace(/[^\w-]/g, (c) => "\\" + c) };
let handler = null;
w.chrome = { runtime: { onMessage: { addListener: (f) => { handler = f; } } } };
w.eval(fs.readFileSync(path.join(__dirname, "..", "agent.js"), "utf8"));
const act = (action, args) => new Promise((res) => handler({ target: "choimini-agent", action, args: args || {} }, {}, res));
const log = []; ["click", "dblclick", "contextmenu", "mouseover", "keydown", "submit"].forEach((t) => d.addEventListener(t, (e) => log.push(t + ":" + (e.target.id || e.target.tagName)), true));

(async () => {
  let r = await act("click", { x: 120, y: 100 });           // 이미지 좌표(dpr 2) → CSS (60,50) = b1
  check("스크린샷 좌표 클릭 → 그 위치 요소 클릭 (양식 밖 버튼은 확인 없이)", r.ok && log.includes("click:b1") && r.result.clicked.text === "좋아요", JSON.stringify(r));
  check("커서 오버레이가 페이지에 생김(클릭 안 막음)", !!d.querySelector("[data-choimini-cursor]") && d.querySelector("[data-choimini-cursor]").style.pointerEvents === "none");
  r = await act("click", { x: 120, y: 280 });               // sb (제출 버튼)
  check("좌표로 제출 버튼 → 확인 요구 (바로 제출 안 함)", r.ok && r.result.needsConfirmation && !log.includes("submit:f"), JSON.stringify(r));
  r = await act("double_click", { x: 120, y: 340 });
  check("double_click", r.ok && log.includes("dblclick:hov"));
  r = await act("right_click", { x: 120, y: 340 });
  check("right_click → contextmenu", r.ok && log.includes("contextmenu:hov"));
  r = await act("hover", { x: 120, y: 340 });
  check("hover → mouseover", r.ok && log.includes("mouseover:hov"));
  r = await act("find", { text: "검색" });
  check("find: aria-label 로 찾고 ref + 이미지 좌표", r.ok && r.result.count >= 1 && /^e\d+$/.test(r.result.elements[0].ref) && r.result.elements[0].x === 120, JSON.stringify(r.result));
  const qref = r.result.elements[0].ref;
  r = await act("press_key", { ref: qref, key: "Enter" });
  check("입력란에서 Enter → 양식 제출이므로 확인 요구", r.ok && r.result.needsConfirmation, JSON.stringify(r));
  r = await act("press_key", { key: "Tab" });
  check("Tab → 다음 요소로 포커스 이동", r.ok && d.activeElement && d.activeElement.id === "pw", d.activeElement && d.activeElement.id);
  r = await act("press_key", { key: "a" });
  check("비밀번호 칸에 글자 키 거부", r.ok && r.result.ok === false && r.result.error === "SENSITIVE_FIELD", JSON.stringify(r));
  r = await act("get_html", { selector: "body" });
  check("get_html: 입력값(value) 제거", r.ok && r.result.html.includes('id="val"') && !r.result.html.includes("secret-token"), r.result && r.result.html.slice(0, 200));
  r = await act("click", { x: 5000, y: 5000 });
  check("화면 밖 좌표는 오류", !r.ok && /화면 밖/.test(r.error), JSON.stringify(r));
  r = await act("snapshot", {});
  const bref = r.result.elements.find((e) => e.text === "좋아요").ref;
  r = await act("scroll_to", { ref: bref });
  check("scroll_to", r.ok && r.result.ok);
  console.log("\n" + pass + " passed, " + failN + " failed");
  process.exit(failN ? 1 : 0);
})();
