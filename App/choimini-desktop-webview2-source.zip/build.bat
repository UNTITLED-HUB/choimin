@echo off
rem Choimini Desktop build (Windows .NET Framework 4.x csc - no Visual Studio needed)
rem Result: out\ChoiminiDesktop.exe - a single EXE (WebView2 DLLs and code-prompt.txt are embedded)
setlocal
cd /d "%~dp0"
set CSC=%WINDIR%\Microsoft.NET\Framework64\v4.0.30319\csc.exe
if not exist "%CSC%" set CSC=%WINDIR%\Microsoft.NET\Framework\v4.0.30319\csc.exe
if not exist "%CSC%" ( echo [ERROR] csc.exe not found. .NET Framework 4.x is required. & exit /b 1 )
if not exist out mkdir out
"%CSC%" /nologo /target:winexe /platform:x64 /optimize+ /utf8output /codepage:65001 /main:Choimini.Boot ^
  /win32icon:res\icon.ico /win32manifest:res\app.manifest ^
  /out:out\ChoiminiDesktop.exe ^
  /r:System.dll /r:System.Core.dll /r:System.Windows.Forms.dll /r:System.Drawing.dll /r:System.Web.Extensions.dll /r:Accessibility.dll ^
  /r:lib\Microsoft.Web.WebView2.Core.dll /r:lib\Microsoft.Web.WebView2.WinForms.dll ^
  /resource:lib\Microsoft.Web.WebView2.Core.dll,lib.Microsoft.Web.WebView2.Core.dll ^
  /resource:lib\Microsoft.Web.WebView2.WinForms.dll,lib.Microsoft.Web.WebView2.WinForms.dll ^
  /resource:lib\WebView2Loader.dll,lib.WebView2Loader.dll ^
  /resource:res\code-prompt.txt,res.code-prompt.txt ^
  src\Tools.cs src\Program.cs src\DeviceUse.cs
if errorlevel 1 ( echo [ERROR] build failed & exit /b 1 )
echo [OK] out\ChoiminiDesktop.exe (single file - no DLLs needed)
exit /b 0
