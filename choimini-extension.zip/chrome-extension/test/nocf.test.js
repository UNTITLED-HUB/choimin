// nocf.js (사이트 iframe 안에서 실행되는 스크립트) 테스트 — 실제 GitHub 에 올라가 있던 "예전 index.html" 에 대해 실행한다.
// 실행: NODE_PATH=<jsdom 경로> node test/nocf.test.js
const { JSDOM, VirtualConsole } = require("jsdom");
const fs = require("fs"), path = require("path");
const SCRIPT = fs.readFileSync(path.join(__dirname, "..", "nocf.js"), "utf8");
const OLD = fs.readFileSync(path.join(__dirname, "..", "..", "site", "index.original.html"), "utf8");
const SITE = "https://untitled-hub.github.io/choimini/";
let pass = 0, failN = 0;
const check = (n, ok, x) => { ok ? pass++ : failN++; console.log((ok ? "  PASS " : "  FAIL ") + n + (ok ? "" : "  " + (x || ""))); };
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

/* opts: { embedded: iframe 안인가, search: "?app=chrome" 등, nav: Navigation API 를 흉내낼지, html } */
async function boot(opts) {
  const parentDom = new JSDOM("<html></html>", { url: "chrome-extension://abc/sidepanel.html" });
  const P = parentDom.window; const posted = [];
  P.postMessage = (m) => posted.push(m);
  let nav = null;
  const dom = new JSDOM(opts.html || OLD, { url: SITE + (opts.search || ""), runScripts: "dangerously", pretendToBeVisual: true, virtualConsole: new VirtualConsole(),
    beforeParse(w) {
      if (opts.nav) { nav = new w.EventTarget(); w.navigation = nav; }
      if (opts.authListenerFlag) w.__choiminiChromeAuthListener = true;
      if (opts.handler) w.__choiminiHandleAuthCallback = opts.handler;
      // jsdom 은 window.top/parent 를 바꿀 수 없어서, 스크립트가 보는 "window" 만 프록시로 바꿔 iframe 안(top/parent = 사이드 패널)을 흉내 낸다.
      // (iframe 이 아닐 때는 top 이 자기 자신을 가리키게 한다)
      const proxy = new Proxy(w, {
        get(t, k) {
          if (k === "top") return opts.embedded ? P : proxy;
          if (k === "parent") return opts.embedded ? P : proxy;
          const v = t[k]; return typeof v === "function" ? v.bind(t) : v;
        },
        set(t, k, v) { t[k] = v; return true; },
      });
      w.eval("(function(window){" + SCRIPT + "\n})")(proxy);
      w.__proxy = proxy;
    } });
  await sleep(300);
  return { w: dom.window, P, posted, nav, doc: dom.window.document };
}
const locked = (x) => !!x.doc.getElementById("jcv2-gate") || x.doc.documentElement.classList.contains("jcv2-locked");

(async () => {
  console.log("\n[1] Cloudflare: removed ONLY inside the extension's side panel");
  let x = await boot({ embedded: true, search: "?app=chrome" });
  check("embedded by the extension (?app=chrome, in an iframe) → gate removed on the OLD live site", !locked(x));
  check("…flags are set for the site (CHOIMINI_APP=chrome, SKIP_CLOUDFLARE)", x.w.CHOIMINI_APP === "chrome" && x.w.CHOIMINI_SKIP_CLOUDFLARE === true); x.w.close();
  x = await boot({ embedded: false });
  check("CONTROL — the website opened in a normal tab: gate is still there (Cloudflare stays on the website)", locked(x));
  check("CONTROL — …and no flags were set", x.w.CHOIMINI_APP === undefined && x.w.CHOIMINI_SKIP_CLOUDFLARE === undefined); x.w.close();
  x = await boot({ embedded: false, search: "?app=chrome" });
  check("CONTROL — a normal tab with ?app=chrome typed into the URL is NOT enough (must be inside a frame)", locked(x)); x.w.close();
  x = await boot({ embedded: true });
  check("CONTROL — embedded in some OTHER site's iframe (no ?app=chrome, not extension) is untouched", locked(x)); x.w.close();
  x = await boot({ embedded: true, search: "?app=chrome" });
  await sleep(700);
  { // 무한 루프의 원인: 클래스가 이미 없는데도 classList.remove 를 부르면 (실제 Chrome 에서) 변경 이벤트가 생겨 스스로를 다시 부른다.
    // jsdom 은 그 이벤트를 만들지 않아 루프 자체는 재현되지 않으므로, "원인"(불필요한 호출)을 직접 센다.
    let removeCalls = 0; const proto = x.w.DOMTokenList.prototype, orig = proto.remove;
    proto.remove = function () { removeCalls++; return orig.apply(this, arguments); };
    const div = x.doc.createElement("div"); x.doc.body.appendChild(div); x.doc.body.appendChild(x.doc.createElement("span"));   // DOM 을 건드려 감시 콜백을 실행시킨다
    await sleep(300); proto.remove = orig;
    check("once unlocked, DOM activity does NOT call classList.remove again (cause of the observer feedback loop)", removeCalls === 0 && !locked(x), "remove calls=" + removeCalls); }
  x.w.close();

  console.log("\n[2] Google login: the iframe's trip to Google is turned into 'open a real tab'");
  const SB = "https://cfozaatwytsitimvjkyz.supabase.co/auth/v1/authorize?provider=google&redirect_to=" + encodeURIComponent(SITE) + "&code_challenge=abc";
  const navigate = (x, url, cancelable = true) => { const ev = new x.w.Event("navigate", { cancelable }); ev.destination = { url }; x.nav.dispatchEvent(ev); return ev; };
  x = await boot({ embedded: true, search: "?app=chrome", nav: true });
  let ev = navigate(x, SB);
  check("navigation to the Supabase authorize URL is cancelled (iframe stays on the site)", ev.defaultPrevented === true);
  check("…and the parent side panel is asked to open it (open-auth)", x.posted.length === 1 && x.posted[0].type === "open-auth" && x.posted[0].source === "choimini-web" && x.posted[0].url === SB, JSON.stringify(x.posted));
  ev = navigate(x, SITE + "?x=1"); check("normal navigation inside the site is left alone", ev.defaultPrevented === false && x.posted.length === 1);
  ev = navigate(x, "https://evil.example/auth/v1/authorize"); check("other hosts are left alone", ev.defaultPrevented === false && x.posted.length === 1);
  ev = navigate(x, "http://cfozaatwytsitimvjkyz.supabase.co/auth/v1/authorize"); check("plain http is left alone", ev.defaultPrevented === false && x.posted.length === 1);
  ev = navigate(x, SB, false); check("a non-cancelable navigation is not cancelled, but the parent is still told", ev.defaultPrevented === false && x.posted.length === 2);
  x.w.close();
  x = await boot({ embedded: false, nav: true });
  ev = navigate(x, SB); check("CONTROL — in a normal tab, login navigation is NOT touched (web login keeps working)", ev.defaultPrevented === false && x.posted.length === 0); x.w.close();

  console.log("\n[3] The code coming back is handed to the site's own callback");
  const got = [];
  x = await boot({ embedded: true, search: "?app=chrome", handler: (u) => got.push(u) });
  const send = (data, o = {}) => { x.w.dispatchEvent(new x.w.MessageEvent("message", { data, origin: o.origin || "chrome-extension://abc", source: o.source === undefined ? x.P : o.source })); };
  const msg = { source: "choimini-ext", type: "auth-callback", url: "choimini://auth-callback?code=ABC" };
  send(msg); check("valid message from the extension → __choiminiHandleAuthCallback(url)", got.length === 1 && got[0] === "choimini://auth-callback?code=ABC", JSON.stringify(got));
  send(msg, { origin: "https://evil.example" }); check("message from another origin is ignored", got.length === 1);
  send(msg, { source: x.w }); check("message not from the parent frame is ignored", got.length === 1);
  send({ source: "choimini-ext", type: "other", url: "x" }); check("other message types are ignored", got.length === 1);
  send({ source: "choimini-ext", type: "auth-callback", url: 123 }); check("non-string url is ignored", got.length === 1); x.w.close();
  const got2 = [];
  x = await boot({ embedded: true, search: "?app=chrome", handler: (u) => got2.push(u), authListenerFlag: true });
  x.w.dispatchEvent(new x.w.MessageEvent("message", { data: msg, origin: "chrome-extension://abc", source: x.P }));
  check("when the NEW site handles it itself (flag set), this script does not handle it twice", got2.length === 0); x.w.close();
  x = await boot({ embedded: true, search: "?app=chrome" });
  let threw = false; try { x.w.dispatchEvent(new x.w.MessageEvent("message", { data: msg, origin: "chrome-extension://abc", source: x.P })); } catch (_) { threw = true; }
  check("no crash if the site has no callback function yet", !threw); x.w.close();

  console.log(`\n${pass} passed, ${failN} failed`);
  process.exit(failN ? 1 : 0);
})();
