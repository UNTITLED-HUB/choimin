﻿// Choimini Desktop — device_use: 최미나이가 Windows 화면을 직접 보고(캡처 + 접근성 목록) 마우스·키보드로 조작한다.
//  - 좌표는 항상 "화면 캡처 이미지" 기준(AI 가 보는 이미지 그대로). 실제 화면 좌표로는 여기서 바꾼다.
//  - 실제 마우스 커서가 부드럽게 움직여서 어디를 누르는지 보이고, 누를 때 파란 물결이 퍼진다.
//  - 조작 중에는 화면 아래에 [중지] 막대가 뜨고, Ctrl+Alt+S 로도 즉시 멈춘다. 멈추면 사용자가 새 요청을 보낼 때까지 다시 시작하지 않는다.
//  - 최미나이 자신의 창(승인 창·보안문자·채팅)은 클릭/입력하지 못한다(스스로 승인하는 것을 막는다).
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using Accessibility;

namespace Choimini
{
    static class Nat
    {
        [StructLayout(LayoutKind.Sequential)] public struct POINT { public int X, Y; }
        [StructLayout(LayoutKind.Sequential)] public struct RECT { public int L, T, R, B; }
        [StructLayout(LayoutKind.Sequential)] public struct MOUSEINPUT { public int dx, dy; public uint mouseData, dwFlags, time; public IntPtr extra; }
        [StructLayout(LayoutKind.Sequential)] public struct KEYBDINPUT { public ushort wVk, wScan; public uint dwFlags, time; public IntPtr extra; }
        [StructLayout(LayoutKind.Explicit)] public struct INPUT { [FieldOffset(0)] public int type; [FieldOffset(8)] public MOUSEINPUT mi; [FieldOffset(8)] public KEYBDINPUT ki; }
        public delegate bool EnumProc(IntPtr h, IntPtr l);
        [DllImport("user32.dll")] public static extern bool SetCursorPos(int x, int y);
        [DllImport("user32.dll")] public static extern bool GetCursorPos(out POINT p);
        [DllImport("user32.dll", SetLastError = true)] public static extern uint SendInput(uint n, INPUT[] inputs, int size);
        [DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
        [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr h);
        [DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr h, int cmd);
        [DllImport("user32.dll")] public static extern bool IsIconic(IntPtr h);
        [DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr h);
        [DllImport("user32.dll")] public static extern IntPtr WindowFromPoint(POINT p);
        [DllImport("user32.dll")] public static extern IntPtr GetAncestor(IntPtr h, uint flags);
        [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr h, out uint pid);
        [DllImport("user32.dll")] public static extern bool EnumWindows(EnumProc f, IntPtr l);
        [DllImport("user32.dll", CharSet = CharSet.Unicode)] public static extern int GetWindowText(IntPtr h, StringBuilder sb, int n);
        [DllImport("user32.dll", CharSet = CharSet.Unicode)] public static extern int GetClassName(IntPtr h, StringBuilder sb, int n);
        [DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr h, out RECT r);
        [DllImport("user32.dll")] public static extern IntPtr GetWindow(IntPtr h, uint cmd);
        [DllImport("user32.dll")] public static extern int GetWindowLong(IntPtr h, int idx);
        [DllImport("user32.dll")] public static extern bool SetWindowDisplayAffinity(IntPtr h, uint aff);
        [DllImport("user32.dll")] public static extern short VkKeyScan(char c);
        [DllImport("dwmapi.dll")] public static extern int DwmGetWindowAttribute(IntPtr h, int attr, out int v, int size);
        [DllImport("oleacc.dll")] public static extern int AccessibleObjectFromWindow(IntPtr h, uint id, ref Guid iid, [MarshalAs(UnmanagedType.Interface)] out object acc);
        [DllImport("oleacc.dll")] public static extern int AccessibleChildren(IAccessible container, int start, int count, [Out] object[] children, out int obtained);
        public static readonly Guid IID_IAccessible = new Guid("618736E0-3C3D-11CF-810C-00AA00389B71");
    }

    /* 누르는 곳에 퍼지는 파란 물결 (클릭이 통과되는 투명 창, 화면 캡처에는 찍히지 않음) */
    class RippleForm : Form
    {
        float t; readonly System.Windows.Forms.Timer tm = new System.Windows.Forms.Timer { Interval = 16 };
        const int S = 64;
        public RippleForm(Point center)
        {
            FormBorderStyle = FormBorderStyle.None; ShowInTaskbar = false; TopMost = true; StartPosition = FormStartPosition.Manual;
            BackColor = Color.Magenta; TransparencyKey = Color.Magenta; Bounds = new Rectangle(center.X - S / 2, center.Y - S / 2, S, S);
            DoubleBuffered = true;
            tm.Tick += delegate { t += 0.07f; if (t >= 1f) { tm.Stop(); Close(); } else Invalidate(); };
        }
        protected override bool ShowWithoutActivation { get { return true; } }
        protected override CreateParams CreateParams { get { var c = base.CreateParams; c.ExStyle |= 0x20 | 0x80000 | 0x08000000 | 0x80; return c; } } // TRANSPARENT|LAYERED|NOACTIVATE|TOOLWINDOW
        protected override void OnShown(EventArgs e) { base.OnShown(e); try { Nat.SetWindowDisplayAffinity(Handle, 0x11); } catch (Exception) { } tm.Start(); }
        protected override void OnPaint(PaintEventArgs e)
        {
            e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
            float r = 8 + (S / 2 - 6) * t; int a = (int)(230 * (1 - t));
            using (var p = new Pen(Color.FromArgb(Math.Max(a, 0), 59, 130, 246), 3)) e.Graphics.DrawEllipse(p, S / 2f - r, S / 2f - r, r * 2, r * 2);
        }
    }

    /* 조작 중 화면 아래 막대: 지금 하는 일 + [중지] (캡처에 찍히지 않음) */
    class StopBar : Form
    {
        readonly Label lbl = new Label { AutoSize = false, ForeColor = Color.White, TextAlign = ContentAlignment.MiddleLeft, Font = new Font("Malgun Gothic", 9f) };
        readonly Button btn = new Button { Text = "중지", ForeColor = Color.White, BackColor = Color.FromArgb(220, 38, 38), FlatStyle = FlatStyle.Flat, Font = new Font("Malgun Gothic", 9.5f, FontStyle.Bold) };
        public event Action StopClicked;
        public StopBar()
        {
            AutoScaleDimensions = new SizeF(96F, 96F); AutoScaleMode = AutoScaleMode.Dpi;
            FormBorderStyle = FormBorderStyle.None; ShowInTaskbar = false; TopMost = true; StartPosition = FormStartPosition.Manual;
            BackColor = Color.FromArgb(31, 41, 55); Size = new Size(460, 44); Opacity = 0.94;
            lbl.SetBounds(14, 4, 360, 36); btn.SetBounds(384, 7, 66, 30); btn.FlatAppearance.BorderSize = 0;
            btn.Click += delegate { var h = StopClicked; if (h != null) h(); };
            Controls.Add(lbl); Controls.Add(btn);
            var wa = Screen.PrimaryScreen.WorkingArea; Location = new Point(wa.Left + (wa.Width - Width) / 2, wa.Bottom - Height - 18);
        }
        protected override bool ShowWithoutActivation { get { return true; } }
        protected override CreateParams CreateParams { get { var c = base.CreateParams; c.ExStyle |= 0x08000000 | 0x80; return c; } } // NOACTIVATE|TOOLWINDOW
        protected override void OnShown(EventArgs e) { base.OnShown(e); try { Nat.SetWindowDisplayAffinity(Handle, 0x11); } catch (Exception) { } }
        public void SetText(string s) { lbl.Text = s; }
    }

    class DeviceDesk
    {
        public volatile string State = "idle";   // idle | running | stopped
        public int Steps;
        readonly Form host;                       // UI 스레드에서 막대/물결을 띄우기 위한 메인 창
        StopBar bar; string narration = "", lastAct = "";
        double scale = 1.0; Rectangle screen;     // 이미지 좌표 = (실제 - screen.Location) * scale
        int lastHash;
        class El { public IAccessible Acc; public int Child; public Rectangle R; public string Name, Role; public bool Editable; }
        List<El> els = new List<El>();
        System.Threading.Timer idle;
        public Func<bool> AskStart;               // 처음 조작할 때 사용자 승인 (UI 스레드에서 호출됨)

        public DeviceDesk(Form host) { this.host = host; screen = Screen.PrimaryScreen.Bounds; scale = Math.Min(1.0, 1280.0 / Math.Max(screen.Width, screen.Height)); }

        static Dictionary<string, object> Ok(string s) { return new Dictionary<string, object> { { "ok", true }, { "output", s } }; }
        static Dictionary<string, object> Er(string s) { return new Dictionary<string, object> { { "ok", false }, { "error", s } }; }
        static string S(Dictionary<string, object> a, string k) { object v; return a != null && a.TryGetValue(k, out v) && v != null ? Convert.ToString(v) : ""; }
        static bool Has(Dictionary<string, object> a, string k) { return a != null && a.ContainsKey(k) && a[k] != null && Convert.ToString(a[k]) != ""; }
        static double D(Dictionary<string, object> a, string k, double def) { try { return Has(a, k) ? Convert.ToDouble(a[k], System.Globalization.CultureInfo.InvariantCulture) : def; } catch (Exception) { return def; } }
        static bool B(Dictionary<string, object> a, string k) { object v; if (a == null || !a.TryGetValue(k, out v) || v == null) return false; if (v is bool) return (bool)v; var s = Convert.ToString(v).ToLowerInvariant(); return s == "true" || s == "1" || s == "yes"; }

        public const string HELP = "device_use (Windows) — 컴퓨터 화면을 직접 보고 마우스·키보드로 조작. ```tool 블록에 한 줄에 JSON 하나. 좌표는 항상 '화면 캡처 이미지' 기준.\n"
            + "[보기] {\"tool\":\"device_screen\"} 지금 창의 요소 목록([번호] 종류 \"이름\" (x,y)) + 캡처 이미지 / {\"tool\":\"device_screenshot\"} 이미지만 / {\"tool\":\"device_find\",\"text\":\"저장\"} 글자로 요소 찾기 / {\"tool\":\"device_windows\"} 열린 창 목록\n"
            + "[마우스] {\"tool\":\"device_click\",\"id\":7} 번호로(가장 정확) / {\"tool\":\"device_click\",\"x\":640,\"y\":360} / \"button\":\"right\" 오른쪽, \"double\":true 더블클릭 / {\"tool\":\"device_move\",\"x\":..,\"y\":..} / {\"tool\":\"device_drag\",\"x1\":..,\"y1\":..,\"x2\":..,\"y2\":..} / {\"tool\":\"device_scroll\",\"dir\":\"down\",\"amount\":5}\n"
            + "[키보드] {\"tool\":\"device_type\",\"text\":\"안녕\",\"enter\":true} / {\"tool\":\"device_key\",\"key\":\"ctrl+s\"} (enter, esc, tab, alt+tab, win+d, ctrl+shift+t, f5 …)\n"
            + "[창·앱] {\"tool\":\"device_focus\",\"title\":\"메모장\"} 창 앞으로 / {\"tool\":\"device_open_app\",\"name\":\"notepad\"} 또는 주소·파일 열기 / {\"tool\":\"device_wait_for\",\"text\":\"완료\",\"ms\":6000} / {\"tool\":\"device_wait\",\"ms\":1000}\n"
            + "[빠르게] 조작에 \"screen\":true 를 붙이면 조작 뒤 화면을 같이 돌려준다. 확인이 필요 없는 연속 동작은 한 블록에 여러 줄로.\n"
            + "규칙: 결과를 확인하며 진행한다. 결제·전송·삭제·로그인·설치처럼 되돌리기 어려운 동작은 먼저 묻는다. 비밀번호는 대신 입력하지 않는다. 최미나이 앱 자신의 창(승인 창 등)은 조작할 수 없다. '[중지됨]' 이면 즉시 멈추고 알린다.";

        /* ---------- 상태 ---------- */
        public void NewRequest() { if (State == "stopped") State = "idle"; narration = ""; }
        public void Narrate(string s) { narration = (s ?? "").Replace("\n", " ").Trim(); if (narration.Length > 90) narration = narration.Substring(0, 90) + "…"; UpdateBar(); }
        public void Stop(string who)
        {
            if (State == "idle" && who != "user") return;
            State = "stopped"; HideBar();
            var cb = OnStopped; if (cb != null) UI(() => cb("화면 조작을 중지했어요" + (who == "user" ? " (사용자가 중지했어요)" : "")));
        }
        public Action<string> OnStopped;          // 사이트에 "긴급 중지" 알림
        public void Finish() { if (State == "running") State = "idle"; HideBar(); }
        void UI(Action f) { try { if (host.IsHandleCreated) host.BeginInvoke(f); } catch (Exception) { } }
        void ShowBar() { UI(() => { if (bar == null || bar.IsDisposed) { bar = new StopBar(); bar.StopClicked += () => Stop("user"); bar.Show(); } UpdateBarNow(); }); }
        void UpdateBar() { UI(UpdateBarNow); }
        void UpdateBarNow() { if (bar != null && !bar.IsDisposed) bar.SetText((narration.Length > 0 ? narration : "최미나이가 화면 조작 중") + "\n▸ " + (lastAct.Length > 0 ? lastAct : "대기") + " · " + Steps + "단계 · Ctrl+Alt+S 중지"); }
        void HideBar() { UI(() => { if (bar != null && !bar.IsDisposed) bar.Close(); bar = null; }); }
        void Ripple(Point p) { UI(() => { try { new RippleForm(p).Show(); } catch (Exception) { } }); }
        Rectangle BarRect() { try { var b = bar; if (b != null && !b.IsDisposed) { Rectangle r = Rectangle.Empty; host.Invoke((Action)(() => r = b.Bounds)); return r; } } catch (Exception) { } return Rectangle.Empty; }

        /* ---------- 좌표 ---------- */
        Point ToScreen(double x, double y) { return new Point(screen.X + (int)Math.Round(x / scale), screen.Y + (int)Math.Round(y / scale)); }
        Point ToImage(Rectangle r) { return new Point((int)Math.Round((r.X + r.Width / 2.0 - screen.X) * scale), (int)Math.Round((r.Y + r.Height / 2.0 - screen.Y) * scale)); }
        static bool OwnWindow(IntPtr h)
        {
            if (h == IntPtr.Zero) return false;
            uint pid; Nat.GetWindowThreadProcessId(Nat.GetAncestor(h, 3), out pid); // GA_ROOTOWNER
            return pid == (uint)Process.GetCurrentProcess().Id;
        }
        string Guard(Point p)
        {
            if (BarRect().Contains(p)) return "그 위치에는 [중지] 막대가 있어요. 다른 위치를 누르세요.";
            if (OwnWindow(Nat.WindowFromPoint(new Nat.POINT { X = p.X, Y = p.Y }))) return "최미나이 앱 자신의 창(승인 창·채팅 등)은 조작할 수 없어요. 사용자에게 직접 해 달라고 하세요.";
            return null;
        }
        string GuardKeys() { return OwnWindow(Nat.GetForegroundWindow()) ? "지금 앞에 있는 창이 최미나이 앱이라 키보드 입력을 보낼 수 없어요. device_focus 로 작업할 창을 먼저 앞으로 가져오세요." : null; }

        /* ---------- 입력 ---------- */
        static void Send(params Nat.INPUT[] ins) { Nat.SendInput((uint)ins.Length, ins, Marshal.SizeOf(typeof(Nat.INPUT))); }
        static Nat.INPUT Mouse(uint flags, uint data = 0) { var i = new Nat.INPUT { type = 0 }; i.mi.dwFlags = flags; i.mi.mouseData = data; return i; }
        static Nat.INPUT Key(ushort vk, bool up, bool ext = false) { var i = new Nat.INPUT { type = 1 }; i.ki.wVk = vk; i.ki.dwFlags = (up ? 2u : 0u) | (ext ? 1u : 0u); return i; }
        static Nat.INPUT Uni(char c, bool up) { var i = new Nat.INPUT { type = 1 }; i.ki.wScan = c; i.ki.dwFlags = 4u | (up ? 2u : 0u); return i; }
        /* 커서를 부드럽게 이동 (어디를 누르는지 사용자 눈에 보이게) */
        static void Glide(Point to, int ms = 140)
        {
            Nat.POINT c; Nat.GetCursorPos(out c);
            int steps = Math.Max(1, ms / 14);
            for (int i = 1; i <= steps; i++)
            {
                double t = (double)i / steps, e = 1 - Math.Pow(1 - t, 3);
                Nat.SetCursorPos((int)(c.X + (to.X - c.X) * e), (int)(c.Y + (to.Y - c.Y) * e)); Thread.Sleep(14);
            }
            Nat.SetCursorPos(to.X, to.Y);
        }
        Dictionary<string, object> ClickAt(Point p, string button, bool dbl)
        {
            string g = Guard(p); if (g != null) return Er(g);
            Glide(p); Ripple(p);
            uint down = button == "right" ? 0x0008u : button == "middle" ? 0x0020u : 0x0002u, up = down << 1;
            Send(Mouse(down), Mouse(up));
            if (dbl) { Thread.Sleep(60); Send(Mouse(down), Mouse(up)); }
            return Ok((dbl ? "더블클릭" : button == "right" ? "오른쪽 클릭" : "클릭") + " (" + ImgStr(p) + ")");
        }
        string ImgStr(Point s) { return (int)Math.Round((s.X - screen.X) * scale) + "," + (int)Math.Round((s.Y - screen.Y) * scale); }

        static readonly Dictionary<string, ushort> VK = new Dictionary<string, ushort>(StringComparer.OrdinalIgnoreCase)
        {
            {"enter",0x0D},{"return",0x0D},{"esc",0x1B},{"escape",0x1B},{"tab",0x09},{"space",0x20},{"backspace",0x08},{"bs",0x08},{"delete",0x2E},{"del",0x2E},{"insert",0x2D},{"ins",0x2D},
            {"up",0x26},{"down",0x28},{"left",0x25},{"right",0x27},{"home",0x24},{"end",0x23},{"pageup",0x21},{"pgup",0x21},{"pagedown",0x22},{"pgdn",0x22},
            {"ctrl",0x11},{"control",0x11},{"alt",0x12},{"shift",0x10},{"win",0x5B},{"windows",0x5B},{"meta",0x5B},{"cmd",0x5B},{"super",0x5B},
            {"capslock",0x14},{"printscreen",0x2C},{"prtsc",0x2C},{"menu",0x5D},{"apps",0x5D},{"volumeup",0xAF},{"volumedown",0xAE},{"mute",0xAD},{"playpause",0xB3},
            {"hangul",0x15},{"한영",0x15},{"hanja",0x19},{"엔터",0x0D}
        };
        static readonly HashSet<ushort> EXT = new HashSet<ushort> { 0x21, 0x22, 0x23, 0x24, 0x25, 0x26, 0x27, 0x28, 0x2D, 0x2E, 0x5B, 0x5D };
        static bool ParseKey(string name, out ushort vk)
        {
            name = name.Trim().ToLowerInvariant().Replace("_", "").Replace("key", "") ;
            if (name.Length == 0) { vk = 0; return false; }
            if (VK.TryGetValue(name, out vk)) return true;
            if (name.Length > 1 && name[0] == 'f') { int n; if (int.TryParse(name.Substring(1), out n) && n >= 1 && n <= 24) { vk = (ushort)(0x70 + n - 1); return true; } }
            if (name.Length == 1) { char c = char.ToUpperInvariant(name[0]); if ((c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9')) { vk = c; return true; } short s = Nat.VkKeyScan(name[0]); if (s != -1) { vk = (ushort)(s & 0xFF); return true; } }
            vk = 0; return false;
        }
        Dictionary<string, object> PressCombo(string combo)
        {
            string g = GuardKeys(); if (g != null) return Er(g);
            var parts = combo.Split(new[] { '+' }, StringSplitOptions.RemoveEmptyEntries).Select(x => x.Trim()).Where(x => x.Length > 0).ToList();
            if (combo.Trim() == "+") parts = new List<string> { "+" };
            if (parts.Count == 0) return Er("key 가 필요해요. 예: {\"tool\":\"device_key\",\"key\":\"ctrl+s\"}");
            var vks = new List<ushort>();
            foreach (var p in parts) { ushort v; if (!ParseKey(p, out v)) return Er("알 수 없는 키: " + p + " (예: enter, esc, tab, ctrl+c, alt+tab, win+d, f5)"); vks.Add(v); }
            // 위험한 조합 차단: 잠금/로그아웃 화면, 작업 관리자 강제 종료 등
            string low = string.Join("+", parts).ToLowerInvariant();
            if (low == "win+l" || low.Contains("ctrl+alt+del")) return Er("이 키 조합은 보내지 않아요: " + combo);
            var list = new List<Nat.INPUT>();
            foreach (var v in vks) list.Add(Key(v, false, EXT.Contains(v)));
            for (int i = vks.Count - 1; i >= 0; i--) list.Add(Key(vks[i], true, EXT.Contains(vks[i])));
            Send(list.ToArray());
            return Ok(combo + " 누름");
        }
        Dictionary<string, object> TypeText(string text, bool enter)
        {
            string g = GuardKeys(); if (g != null) return Er(g);
            if (string.IsNullOrEmpty(text) && !enter) return Er("text 가 필요해요");
            var list = new List<Nat.INPUT>();
            foreach (char c in (text ?? "").Replace("\r\n", "\n"))
            {
                if (c == '\n') { list.Add(Key(0x0D, false)); list.Add(Key(0x0D, true)); }
                else if (c == '\t') { list.Add(Key(0x09, false)); list.Add(Key(0x09, true)); }
                else { list.Add(Uni(c, false)); list.Add(Uni(c, true)); }
                if (list.Count >= 200) { Send(list.ToArray()); list.Clear(); Thread.Sleep(5); }
            }
            if (enter) { list.Add(Key(0x0D, false)); list.Add(Key(0x0D, true)); }
            if (list.Count > 0) Send(list.ToArray());
            return Ok("입력했어요 (" + (text ?? "").Length + "자" + (enter ? " + Enter" : "") + ")");
        }

        /* ---------- 화면 ---------- */
        public Tuple<string, int, int> Capture()
        {
            screen = Screen.PrimaryScreen.Bounds;
            scale = Math.Min(1.0, 1280.0 / Math.Max(screen.Width, screen.Height));
            using (var full = new Bitmap(screen.Width, screen.Height, PixelFormat.Format24bppRgb))
            {
                // [중지] 막대는 캡처 제외 설정(Win10 2004+)이 돼 있지만, 예전 Windows 를 위해 캡처하는 순간에만 잠깐 투명하게
                double op = -1; try { host.Invoke((Action)(() => { if (bar != null && !bar.IsDisposed) { op = bar.Opacity; bar.Opacity = 0; } })); if (op >= 0) Thread.Sleep(40); } catch (Exception) { }
                try { using (var g = Graphics.FromImage(full)) g.CopyFromScreen(screen.Location, Point.Empty, screen.Size); }
                finally { if (op >= 0) try { host.BeginInvoke((Action)(() => { if (bar != null && !bar.IsDisposed) bar.Opacity = op; })); } catch (Exception) { } }
                int w = Math.Max(1, (int)Math.Round(screen.Width * scale)), h = Math.Max(1, (int)Math.Round(screen.Height * scale));
                using (var sm = new Bitmap(w, h, PixelFormat.Format24bppRgb))
                {
                    using (var g = Graphics.FromImage(sm)) { g.InterpolationMode = InterpolationMode.HighQualityBicubic; g.DrawImage(full, 0, 0, w, h); }
                    var enc = ImageCodecInfo.GetImageEncoders().First(e => e.MimeType == "image/jpeg");
                    var ps = new EncoderParameters(1); ps.Param[0] = new EncoderParameter(System.Drawing.Imaging.Encoder.Quality, 82L);
                    using (var ms = new MemoryStream()) { sm.Save(ms, enc, ps); return Tuple.Create(Convert.ToBase64String(ms.ToArray()), w, h); }
                }
            }
        }

        static string WinText(IntPtr h) { var sb = new StringBuilder(512); Nat.GetWindowText(h, sb, sb.Capacity); return sb.ToString(); }
        static bool Cloaked(IntPtr h) { int v; try { return Nat.DwmGetWindowAttribute(h, 14, out v, 4) == 0 && v != 0; } catch (Exception) { return false; } }
        static List<IntPtr> TopWindows()
        {
            var list = new List<IntPtr>();
            Nat.EnumWindows((h, l) =>
            {
                if (!Nat.IsWindowVisible(h) || Cloaked(h)) return true;
                if (Nat.GetWindow(h, 4) != IntPtr.Zero) return true;                         // GW_OWNER: 소유된(팝업) 창 제외
                if ((Nat.GetWindowLong(h, -20) & 0x80) != 0) return true;                    // WS_EX_TOOLWINDOW 제외
                if (WinText(h).Length == 0) return true;
                list.Add(h); return true;
            }, IntPtr.Zero);
            return list;
        }

        static readonly Dictionary<int, string> ROLE = new Dictionary<int, string> {
            {0x2B,"버튼"},{0x1E,"링크"},{0x2A,"입력"},{0x2C,"체크"},{0x2D,"라디오"},{0x2E,"콤보"},{0x0C,"메뉴항목"},{0x22,"목록항목"},{0x25,"탭"},{0x24,"트리항목"},
            {0x29,"글자"},{0x28,"그림"},{0x21,"목록"},{0x1C,"행"},{0x1D,"셀"},{0x39,"버튼메뉴"},{0x38,"분할버튼"},{0x2F,"드롭다운"},{0x3E,"버튼드롭다운"},{0x0B,"메뉴"},{0x0A,"메뉴바"},
            {0x0F,"문서"},{0x14,"그룹"},{0x09,"창"},{0x04,"제목줄"},{0x03,"스크롤바"},{0x33,"슬라이더"},{0x34,"스핀"},{0x30,"진행"},{0x16,"툴바"},{0x17,"상태줄"},{0x12,"대화상자"},{0x10,"창틀"}
        };
        static readonly HashSet<int> ACTIONABLE = new HashSet<int> { 0x2B, 0x1E, 0x2A, 0x2C, 0x2D, 0x2E, 0x0C, 0x22, 0x25, 0x24, 0x39, 0x38, 0x2F, 0x3E, 0x1D, 0x33, 0x34 };

        string ReadScreen(int max, string filter)
        {
            var fg = Nat.GetForegroundWindow();
            var sb = new StringBuilder();
            sb.Append("화면 ").Append((int)(screen.Width * scale)).Append('x').Append((int)(screen.Height * scale)).Append(" (이미지 좌표) · 앞 창: \"").Append(WinText(fg)).Append("\"");
            if (OwnWindow(fg)) sb.Append(" (최미나이 앱 — 조작 불가, device_focus 로 다른 창을 앞으로)");
            sb.Append('\n');
            var newEls = new List<El>(); int skipped = 0, visited = 0; var sw = Stopwatch.StartNew();
            object o; var iid = Nat.IID_IAccessible;
            if (!OwnWindow(fg) && Nat.AccessibleObjectFromWindow(fg, 0, ref iid, out o) == 0 && o is IAccessible)
            {
                Action<IAccessible, int> walk = null;
                Action<IAccessible, int, int> visit = (acc, child, depth) =>
                {
                    visited++;
                    try
                    {
                        int st = 0; try { st = Convert.ToInt32(acc.get_accState(child)); } catch (Exception) { }
                        if ((st & 0x8000) != 0 || (st & 0x10000) != 0) return;                // 보이지 않음 / 화면 밖
                        int role = 0; try { role = Convert.ToInt32(acc.get_accRole(child)); } catch (Exception) { }
                        string name = ""; try { name = acc.get_accName(child) ?? ""; } catch (Exception) { }
                        string val = ""; if (role == 0x2A || role == 0x2E) { try { val = acc.get_accValue(child) ?? ""; } catch (Exception) { } }
                        bool act = ACTIONABLE.Contains(role);
                        name = name.Replace("\r", " ").Replace("\n", " ").Trim();
                        if (!act && name.Length == 0) return;
                        if (filter != null && name.IndexOf(filter, StringComparison.OrdinalIgnoreCase) < 0 && val.IndexOf(filter, StringComparison.OrdinalIgnoreCase) < 0) return;
                        int l, t, w, h; acc.accLocation(out l, out t, out w, out h, child);
                        if (w <= 0 || h <= 0) return;
                        var r = new Rectangle(l, t, w, h);
                        if (!r.IntersectsWith(screen)) return;
                        if (newEls.Count >= max) { skipped++; return; }
                        bool pw = (st & 0x20000000) != 0;
                        var el = new El { Acc = acc, Child = child, R = r, Name = name, Role = ROLE.ContainsKey(role) ? ROLE[role] : "요소", Editable = role == 0x2A };
                        var c = ToImage(r);
                        sb.Append('[').Append(newEls.Count).Append("] ").Append(el.Role).Append(" \"").Append(name.Length > 60 ? name.Substring(0, 60) + "…" : name).Append("\" (").Append(c.X).Append(',').Append(c.Y).Append(')');
                        if (val.Length > 0 && !pw) sb.Append(" 값=\"").Append(val.Length > 40 ? val.Substring(0, 40) + "…" : val).Append('"');
                        if (pw) sb.Append(" 비밀번호");
                        if ((st & 0x4) != 0) sb.Append(" 포커스"); if ((st & 0x10) != 0) sb.Append(" 체크됨"); if ((st & 0x2) != 0) sb.Append(" 선택됨"); if ((st & 0x1) != 0) sb.Append(" 비활성");
                        sb.Append('\n'); newEls.Add(el);
                    }
                    catch (Exception) { }
                };
                walk = (acc, depth) =>
                {
                    if (depth > 30 || visited > 6000 || sw.ElapsedMilliseconds > 3500) return;
                    int n = 0; try { n = acc.accChildCount; } catch (Exception) { }
                    if (n <= 0) return;
                    var kids = new object[Math.Min(n, 2000)]; int got;
                    try { if (Nat.AccessibleChildren(acc, 0, kids.Length, kids, out got) != 0) return; } catch (Exception) { return; }
                    for (int i = 0; i < got; i++)
                    {
                        var k = kids[i];
                        var ka = k as IAccessible;
                        if (ka != null) { visit(ka, 0, depth + 1); walk(ka, depth + 1); }
                        else if (k is int) visit(acc, (int)k, depth + 1);
                    }
                };
                walk((IAccessible)o, 0);
            }
            if (skipped > 0) sb.Append("…(").Append(skipped).Append("개 더 — \"max\" 를 늘리거나 device_find)\n");
            if (newEls.Count == 0) sb.Append(filter != null ? "(\"" + filter + "\" 를 찾지 못했어요)\n" : "(이 창은 요소 목록을 주지 않아요 — 캡처 이미지를 보고 좌표로 조작하세요)\n");
            els = newEls;
            return sb.ToString().TrimEnd();
        }

        static string Norm(string tool)
        {
            var t = (tool ?? "").Trim().ToLowerInvariant().Replace(".", "_").Replace("-", "_").Replace(" ", "_");
            if (!t.StartsWith("device_")) t = "device_" + (t.StartsWith("device") ? t.Substring(6) : t);
            switch (t)
            {
                case "device_read": case "device_look": case "device_view": return "device_screen";
                case "device_capture": case "device_snap": return "device_screenshot";
                case "device_tap": case "device_press": case "device_left_click": return "device_click";
                case "device_double_click": case "device_double_tap": case "device_dblclick": return "device_double_click";
                case "device_right_click": case "device_context_click": return "device_right_click";
                case "device_mouse_move": case "device_hover": return "device_move";
                case "device_input": case "device_text": case "device_type_text": return "device_type";
                case "device_hotkey": case "device_keys": case "device_press_key": case "device_shortcut": return "device_key";
                case "device_search": case "device_find_text": return "device_find";
                case "device_window_list": case "device_list_windows": return "device_windows";
                case "device_activate": case "device_switch_window": case "device_focus_window": return "device_focus";
                case "device_open": case "device_launch": case "device_run": case "device_open_url": return "device_open_app";
                case "device_waitfor": case "device_wait_until": return "device_wait_for";
            }
            return t;
        }

        /* ---------- 진입점 (UI 스레드 밖에서 호출) ---------- */
        public Dictionary<string, object> Call(string rawTool, Dictionary<string, object> a)
        {
            string tool = Norm(rawTool);
            a = a ?? new Dictionary<string, object>();
            foreach (var w in new[] { "args", "arguments", "params" }) { var inner = a.ContainsKey(w) ? a[w] as Dictionary<string, object> : null; if (inner != null) foreach (var kv in inner) if (!a.ContainsKey(kv.Key)) a[kv.Key] = kv.Value; }
            if (!Has(a, "id") && Has(a, "index")) a["id"] = a["index"];
            switch (tool)
            {
                case "device_help": return Ok(HELP);
                case "device_status": return Ok("상태: " + State + " · " + Steps + "단계");
                case "device_end": Finish(); return Ok("끝냈어요");
                case "device_stop": Stop("ai"); return Ok("화면 조작을 중지했어요");
            }
            if (State == "stopped") return Er("[중지됨] 사용자가 화면 조작을 중지했어요. 새 요청을 받기 전에는 다시 시작하지 말고, 중지됐다고 알려주세요.");
            if (State == "idle")
            {
                bool okStart = false;
                try { host.Invoke((Action)(() => okStart = AskStart != null && AskStart())); } catch (Exception) { }
                if (!okStart) return Er("[거부] 사용자가 화면 조작을 허용하지 않았어요. 같은 시도를 반복하지 마세요.");
                if (State == "stopped") return Er("[중지됨] 사용자가 화면 조작을 중지했어요.");
                State = "running"; Steps = 0; lastHash = 0;
            }
            Steps++; lastAct = tool.Replace("device_", ""); ShowBar();
            if (idle != null) idle.Dispose();
            idle = new System.Threading.Timer(_ => Finish(), null, 90000, Timeout.Infinite);
            Dictionary<string, object> res;
            try { res = Perform(tool, a); }
            catch (Exception ex) { res = Er("화면 조작 중 오류: " + ex.Message); }
            if (State == "stopped") return Er("[중지됨] 사용자가 화면 조작을 중지했어요. 더 이상 조작하지 마세요.");
            bool ok = res.ContainsKey("ok") && res["ok"] is bool && (bool)res["ok"];
            string first = Convert.ToString(ok ? (res.ContainsKey("output") ? res["output"] : "") : (res.ContainsKey("error") ? res["error"] : "")).Split('\n')[0];
            res["desc"] = first.Length > 80 ? first.Substring(0, 80) : first;
            lastAct = Convert.ToString(res["desc"]); UpdateBar();
            bool wantImg = tool == "device_screen" || tool == "device_screenshot" || B(a, "screen");
            if (ok && wantImg)
            {
                if (tool != "device_screen" && tool != "device_screenshot") Thread.Sleep(350);
                try { var c = Capture(); res["thumb"] = c.Item1; res["thumbW"] = c.Item2; res["thumbH"] = c.Item3; res["screenW"] = c.Item2; res["screenH"] = c.Item3; } catch (Exception) { }
                if (tool != "device_screen" && tool != "device_screenshot" && B(a, "screen")) res["output"] = Convert.ToString(res["output"]) + "\n--- 화면 ---\n" + ReadScreen(Math.Max(10, (int)D(a, "max", 80)), null);
            }
            return res;
        }

        Point ElPoint(El e) { return new Point(e.R.X + e.R.Width / 2, e.R.Y + e.R.Height / 2); }
        El ById(Dictionary<string, object> a) { int i = (int)D(a, "id", -1); return i >= 0 && i < els.Count ? els[i] : null; }

        Dictionary<string, object> Perform(string tool, Dictionary<string, object> a)
        {
            switch (tool)
            {
                case "device_screen":
                    {
                        screen = Screen.PrimaryScreen.Bounds; scale = Math.Min(1.0, 1280.0 / Math.Max(screen.Width, screen.Height));
                        var s = ReadScreen(Math.Max(10, Math.Min(300, (int)D(a, "max", 150))), null);
                        int h = s.GetHashCode();
                        if (h == lastHash) return Ok("(이전과 같은 화면 — 변화 없음)\n" + s.Split('\n')[0]);
                        lastHash = h; return Ok(s);
                    }
                case "device_screenshot": return Ok("화면을 캡처했어요 (이미지는 다음 단계에 첨부)");
                case "device_find":
                    {
                        var t = S(a, "text"); if (t.Length == 0) return Er("text 가 필요해요. 예: {\"tool\":\"device_find\",\"text\":\"저장\"}");
                        return Ok(ReadScreen(60, t) + "\n(번호는 이 목록 기준으로 바뀌었어요)");
                    }
                case "device_windows":
                    {
                        var ws = TopWindows(); var fg = Nat.GetForegroundWindow(); var sb = new StringBuilder("열린 창 " + ws.Count + "개:\n");
                        foreach (var h in ws.Take(40)) { uint pid; Nat.GetWindowThreadProcessId(h, out pid); string pn = ""; try { pn = Process.GetProcessById((int)pid).ProcessName; } catch (Exception) { } sb.Append(h == fg ? " ★ " : " - ").Append('"').Append(WinText(h)).Append("\" · ").Append(pn).Append(Nat.IsIconic(h) ? " (최소화)" : "").Append('\n'); }
                        return Ok(sb.ToString().TrimEnd());
                    }
                case "device_focus":
                    {
                        var q = S(a, "title"); if (q.Length == 0) q = S(a, "name"); if (q.Length == 0) q = S(a, "text");
                        if (q.Length == 0) return Er("title 이 필요해요. 예: {\"tool\":\"device_focus\",\"title\":\"메모장\"}");
                        var hit = TopWindows().FirstOrDefault(h => WinText(h).IndexOf(q, StringComparison.OrdinalIgnoreCase) >= 0 || ProcName(h).Equals(q, StringComparison.OrdinalIgnoreCase));
                        if (hit == IntPtr.Zero) return Er("\"" + q + "\" 창을 찾지 못했어요. device_windows 로 목록을 확인하세요.");
                        if (OwnWindow(hit)) return Er("최미나이 앱 창은 조작할 수 없어요.");
                        if (Nat.IsIconic(hit)) Nat.ShowWindow(hit, 9);
                        // 다른 프로그램을 앞으로 가져오기: Alt 키를 한 번 눌러 포그라운드 제한을 풀고 전환
                        Send(Key(0x12, false), Key(0x12, true)); Nat.SetForegroundWindow(hit); Thread.Sleep(150);
                        return Ok("앞으로 가져옴: \"" + WinText(hit) + "\"");
                    }
                case "device_click": case "device_double_click": case "device_right_click":
                    {
                        string btn = tool == "device_right_click" ? "right" : S(a, "button").ToLowerInvariant();
                        bool dbl = tool == "device_double_click" || B(a, "double");
                        if (Has(a, "id"))
                        {
                            var e = ById(a); if (e == null) return Er("번호 " + S(a, "id") + " 요소가 없어요(이전 목록 " + els.Count + "개). device_screen 으로 다시 읽으세요.");
                            if (e.R.Width <= 0) { try { e.Acc.accDoDefaultAction(e.Child); return Ok("눌렀어요: " + e.Name); } catch (Exception) { return Er("누르지 못했어요"); } }
                            var r = ClickAt(ElPoint(e), btn, dbl); if (r["ok"] is bool && (bool)r["ok"]) r["output"] = Convert.ToString(r["output"]) + " · " + e.Role + " \"" + e.Name + "\""; return r;
                        }
                        if (Has(a, "text") && !Has(a, "x"))
                        {
                            ReadScreen(60, S(a, "text")); if (els.Count == 0) return Er("화면에서 \"" + S(a, "text") + "\" 를 찾지 못했어요. device_screen 으로 확인하세요.");
                            var e = els[0]; return ClickAt(ElPoint(e), btn, dbl);
                        }
                        if (!Has(a, "x") || !Has(a, "y")) return Er("id 또는 x,y 가 필요해요. 예: {\"tool\":\"device_click\",\"id\":3} 또는 {\"tool\":\"device_click\",\"x\":640,\"y\":360}");
                        return ClickAt(ToScreen(D(a, "x", 0), D(a, "y", 0)), btn, dbl);
                    }
                case "device_move":
                    {
                        Point p = Has(a, "id") && ById(a) != null ? ElPoint(ById(a)) : ToScreen(D(a, "x", 0), D(a, "y", 0));
                        Glide(p); return Ok("커서 이동 (" + ImgStr(p) + ")");
                    }
                case "device_drag":
                    {
                        if (!Has(a, "x1") || !Has(a, "y1") || !Has(a, "x2") || !Has(a, "y2")) return Er("x1,y1,x2,y2 가 필요해요");
                        Point p1 = ToScreen(D(a, "x1", 0), D(a, "y1", 0)), p2 = ToScreen(D(a, "x2", 0), D(a, "y2", 0));
                        string g = Guard(p1) ?? Guard(p2); if (g != null) return Er(g);
                        Glide(p1); Ripple(p1); Send(Mouse(0x0002)); Thread.Sleep(60); Glide(p2, Math.Max(150, (int)D(a, "ms", 400))); Thread.Sleep(40); Send(Mouse(0x0004)); Ripple(p2);
                        return Ok("끌어서 옮김 (" + ImgStr(p1) + " → " + ImgStr(p2) + ")");
                    }
                case "device_scroll":
                    {
                        string dir = S(a, "dir").ToLowerInvariant(); if (dir.Length == 0) dir = S(a, "direction").ToLowerInvariant(); if (dir.Length == 0) dir = "down";
                        int n = Math.Max(1, Math.Min(30, (int)D(a, "amount", 5)));
                        if (Has(a, "x") && Has(a, "y")) { var p = ToScreen(D(a, "x", 0), D(a, "y", 0)); string g = Guard(p); if (g != null) return Er(g); Glide(p, 100); }
                        else { Nat.POINT c; Nat.GetCursorPos(out c); string g = Guard(new Point(c.X, c.Y)); if (g != null) return Er(g + " (x,y 로 스크롤할 위치를 지정하세요)"); }
                        bool h = dir == "left" || dir == "right";
                        if (dir != "up" && dir != "down" && !h) return Er("dir 는 up|down|left|right");
                        int delta = ((dir == "up" || dir == "right") ? 120 : -120) * n;   // 세로: 위 +, 아래 - / 가로: 오른쪽 +, 왼쪽 -
                        Send(Mouse(h ? 0x1000u : 0x0800u, unchecked((uint)delta)));
                        return Ok("스크롤 " + dir + " ×" + n);
                    }
                case "device_type": return TypeText(S(a, "text"), B(a, "enter"));
                case "device_key": { var k = S(a, "key"); if (k.Length == 0) k = S(a, "keys"); return PressCombo(k); }
                case "device_open_app":
                    {
                        var n = S(a, "name"); if (n.Length == 0) n = S(a, "app"); if (n.Length == 0) n = S(a, "url"); if (n.Length == 0) n = S(a, "path");
                        if (n.Length == 0) return Er("name 이 필요해요. 예: {\"tool\":\"device_open_app\",\"name\":\"notepad\"}");
                        var low = n.Trim().ToLowerInvariant();
                        if (low.StartsWith("javascript:") || low.StartsWith("vbscript:") || low.EndsWith(".bat") || low.EndsWith(".cmd") || low.EndsWith(".ps1") || low.EndsWith(".vbs") || low.Contains("powershell") || low == "cmd" || low == "cmd.exe")
                            return Er("명령 실행은 device_open_app 으로 하지 않아요. run_command 도구를 쓰세요(승인 규칙 적용).");
                        Process.Start(new ProcessStartInfo(n) { UseShellExecute = true });
                        Thread.Sleep(600);
                        return Ok("열었어요: " + n);
                    }
                case "device_wait":
                    {
                        int ms = Math.Max(100, Math.Min(10000, (int)D(a, "ms", 1000))); var sw = Stopwatch.StartNew();
                        while (sw.ElapsedMilliseconds < ms && State == "running") Thread.Sleep(50);
                        return Ok("기다렸어요 (" + ms + "ms)");
                    }
                case "device_wait_for":
                    {
                        var t = S(a, "text"); if (t.Length == 0) return Er("text 가 필요해요");
                        int ms = Math.Max(300, Math.Min(20000, (int)D(a, "ms", 6000))); bool gone = B(a, "gone"); var sw = Stopwatch.StartNew();
                        while (State == "running")
                        {
                            ReadScreen(5, t); bool has = els.Count > 0;
                            if (gone ? !has : has) return Ok("\"" + t + "\" 가 " + (gone ? "사라졌어요" : "나타났어요") + " (" + sw.ElapsedMilliseconds + "ms)" + (has ? " 위치 (" + ToImage(els[0].R).X + "," + ToImage(els[0].R).Y + ")" : ""));
                            if (sw.ElapsedMilliseconds > ms) break; Thread.Sleep(200);
                        }
                        return Er(ms + "ms 안에 \"" + t + "\" 가 " + (gone ? "사라지지" : "나타나지") + " 않았어요");
                    }
            }
            return Er("알 수 없는 device 도구예요: " + tool + " (device_help 로 목록 확인)");
        }
        static string ProcName(IntPtr h) { uint pid; Nat.GetWindowThreadProcessId(h, out pid); try { return Process.GetProcessById((int)pid).ProcessName; } catch (Exception) { return ""; } }
    }
}
