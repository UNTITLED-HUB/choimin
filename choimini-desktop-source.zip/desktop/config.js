// 최미나이 배포 사이트 + 앱 식별 정보
module.exports = {
  SITE_URL: "https://untitled-hub.github.io/choimini/",

  // Cloudflare 챌린지 면제용 앱 식별자.
  // Cloudflare → Security → WAF → Custom rules 에서
  //   (http.request.headers["x-choimini-app"][0] eq "desktop")  → Action: Skip
  // 처럼 규칙을 만들면 이 앱은 챌린지 없이 통과한다. 헤더는 추측 가능하므로
  // 값을 임의의 긴 문자열로 바꾸고 WAF 규칙에도 같은 값을 넣는 걸 권장.
  APP_HEADER_NAME: "X-Choimini-App",
  APP_HEADER_VALUE: "desktop",
  UA_SUFFIX: "ChoiminiDesktop/1.0",
};
