// 이벤트 매니저
class EventManager {
  static eventCooldowns = {};

  static async checkCooldown(eventId) {
    const now = Date.now();
    const lastRun = this.eventCooldowns[eventId];
    if (lastRun && (now - lastRun) < 1000) {
      return false;
    }
    this.eventCooldowns[eventId] = now;
    return true;
  }

  static isValidUrl(url) {
    try {
      new URL(url);
      return true;
    } catch {
      return false;
    }
  }

  static isValidNumber(num) {
    return !isNaN(num) && num > 0 && num <= 3600;
  }
}

// 사이트 접속 이벤트 매니저
class SiteEventManager extends EventManager {
  static async handleUrlChange(url) {
    if (!url) return;

    const data = await StorageManager.load();
    if (!data.enabled) return;

    for (const event of data.siteEvents) {
      if (!event.enabled) continue;

      try {
        const eventUrl = new URL(event.url);
        const currentUrl = new URL(url);
        
        if (eventUrl.hostname === currentUrl.hostname) {
          if (!(await this.checkCooldown(event.id))) continue;
          
          for (const action of (event.actions || [])) {
            await this.executeAction(action, event.id);
          }
        }
      } catch (e) {
        console.error('URL 파싱 오류:', e);
      }
    }
  }

  static async executeAction(action, eventId) {
    try {
      switch (action.type) {
        case 'closeTab':
          setTimeout(() => {
            chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
              if (tabs[0]) {
                chrome.tabs.remove(tabs[0].id);
              }
            });
          }, action.delay * 1000);
          await StorageManager.addEventLog({
            type: 'close_tab',
            description: `${action.delay}초 후 탭 닫기`
          });
          break;

        case 'openUrl':
          if (this.isValidUrl(action.url)) {
            chrome.tabs.create({ url: action.url });
            await StorageManager.addEventLog({
              type: 'open_url',
              description: `URL 열기: ${action.url}`
            });
          }
          break;

        case 'rotateScreen':
          chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
            if (tabs[0]) {
              chrome.tabs.sendMessage(tabs[0].id, {
                type: 'rotate',
                degree: action.degree
              }).catch(() => {});
            }
          });
          await StorageManager.addEventLog({
            type: 'rotate',
            description: `화면 ${action.degree}도 회전`
          });
          break;

        case 'delayedEffect':
          setTimeout(async () => {
            await this.executeAction(action.effect, eventId);
          }, action.delay * 1000);
          break;
      }
    } catch (e) {
      console.error('액션 실행 오류:', e);
    }
  }
}

// 단축키 이벤트 매니저
class ShortcutEventManager extends EventManager {
  static keyBuffer = [];
  static keyTimers = {};

  static handleKeyPress(key) {
    StorageManager.load().then(d => {
      if (!d.enabled) return;

      for (const event of d.shortcutEvents) {
        if (!event.enabled) continue;

        if (event.type === 'specificKey') {
          this.handleSpecificKey(key, event).catch(e => console.error('단축키 처리 오류:', e));
        } else if (event.type === 'anyKey') {
          this.handleAnyKey(key, event).catch(e => console.error('단축키 처리 오류:', e));
        }
      }
    }).catch(e => console.error('저장소 로드 오류:', e));
  }

  static async handleSpecificKey(key, event) {
    const eventKey = event.key.toUpperCase();
    const pressedKey = event.caseSensitive ? key : key.toUpperCase();

    if (pressedKey !== eventKey) {
      event._keyCount = 0;
      return;
    }

    event._keyCount = (event._keyCount || 0) + 1;

    if (event._keyCount >= event.count) {
      if (!(await this.checkCooldown(event.id))) return;

      event._keyCount = 0;

      if (event.action === 'openUrl' && this.isValidUrl(event.url)) {
        chrome.tabs.create({ url: event.url });
        await StorageManager.addEventLog({
          type: 'shortcut_open',
          description: `키 ${event.key} x${event.count}: ${event.url} 열기`
        });
      } else if (event.action === 'closeTabs') {
        chrome.tabs.query({}, (tabs) => {
          const closeCount = Math.min(event.closeCount, tabs.length);
          for (let i = 0; i < closeCount; i++) {
            chrome.tabs.remove(tabs[i].id);
          }
        });
        await StorageManager.addEventLog({
          type: 'shortcut_close',
          description: `키 ${event.key} x${event.count}: ${event.closeCount}개 탭 닫기`
        });
      }
    }

    clearTimeout(event._keyTimer);
    event._keyTimer = setTimeout(() => {
      event._keyCount = 0;
    }, event.timeLimit * 1000);
  }

  static async handleAnyKey(key, event) {
    event._anyKeyCount = (event._anyKeyCount || 0) + 1;

    if (event._anyKeyCount >= event.count) {
      if (!(await this.checkCooldown(event.id))) return;

      event._anyKeyCount = 0;

      chrome.tabs.query({}, (tabs) => {
        const closeCount = Math.min(event.closeCount, tabs.length);
        for (let i = 0; i < closeCount; i++) {
          chrome.tabs.remove(tabs[i].id);
        }
      });

      await StorageManager.addEventLog({
        type: 'anykey_close',
        description: `아무 키 ${event.count}개 입력: ${event.closeCount}개 탭 닫기`
      });
    }

    clearTimeout(event._keyTimer);
    event._keyTimer = setTimeout(() => {
      event._anyKeyCount = 0;
    }, event.timeLimit * 1000);
  }
}

// 탭 설정 매니저
class TabSettingsManager extends EventManager {
  static async applyCursorImage(imageUrl) {
    if (!this.isValidUrl(imageUrl)) return;

    const data = await StorageManager.load();
    data.tabSettings.cursorImage = imageUrl;
    await StorageManager.save(data);

    chrome.tabs.query({}, (tabs) => {
      tabs.forEach(tab => {
        chrome.tabs.sendMessage(tab.id, {
          type: 'setCursor',
          imageUrl: imageUrl
        }).catch(() => {});
      });
    });
  }

  static async applyRotation(degree) {
    const data = await StorageManager.load();
    data.tabSettings.rotation = degree;
    await StorageManager.save(data);

    chrome.tabs.query({}, (tabs) => {
      tabs.forEach(tab => {
        chrome.tabs.sendMessage(tab.id, {
          type: 'rotate',
          degree: degree
        }).catch(() => {});
      });
    });
  }

  static async replaceImages(imageUrl) {
    if (!this.isValidUrl(imageUrl)) return;

    const data = await StorageManager.load();
    data.tabSettings.replaceImages = true;
    data.tabSettings.replacementImage = imageUrl;
    await StorageManager.save(data);

    chrome.tabs.query({}, (tabs) => {
      tabs.forEach(tab => {
        chrome.tabs.sendMessage(tab.id, {
          type: 'replaceImages',
          imageUrl: imageUrl
        }).catch(() => {});
      });
    });
  }

  static async restoreOriginalImages() {
    const data = await StorageManager.load();
    data.tabSettings.replaceImages = false;
    await StorageManager.save(data);

    chrome.tabs.query({}, (tabs) => {
      tabs.forEach(tab => {
        chrome.tabs.sendMessage(tab.id, {
          type: 'restoreImages'
        }).catch(() => {});
      });
    });
  }

  static async changePageTitle(title) {
    const data = await StorageManager.load();
    data.tabSettings.pageTitle = title || null;
    await StorageManager.save(data);

    chrome.tabs.query({}, (tabs) => {
      tabs.forEach(tab => {
        chrome.tabs.sendMessage(tab.id, {
          type: 'setPageTitle',
          title: title
        }).catch(() => {});
      });
    });
  }
}
