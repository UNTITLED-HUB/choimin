// Chrome in Choimini — 사이트(iframe) 안에서 실행되는 스크립트 (manifest content_scripts, world: MAIN, document_start)
//
// "확장앱의 사이드 패널 안에 임베드된 최미나이"에서만 동작한다. 사이트를 일반 탭으로 직접 열었을 때(웹사이트 접속)는
// 아무 것도 하지 않는다 → 웹사이트에서는 Cloudflare 확인이 그대로 유지된다.
//
// 하는 일 (사이트가 아직 예전 버전이어도 동작하도록 확장이 직접 처리):
//  1) Cloudflare 확인 화면 제거
//  2) Google 로그인: 구글은 iframe 안 로그인을 막는다 → iframe 이 구글(Supabase authorize)로 이동하려는 순간을 가로채서
//     부모(사이드 패널)에게 "실제 탭으로 열어 달라"고 요청. 로그인 후 돌아온 code 를 받아 사이트의 콜백 함수에 넘긴다.
(function () {
  "use strict";
  var inFrame = false, embeddedByExtension = false;
  try {
    inFrame = window.top !== window;
    var ao = window.location.ancestorOrigins;
    embeddedByExtension = !!(ao && ao.length && /^chrome-extension:/.test(ao[0])) ||
      new URLSearchParams(window.location.search).get("app") === "chrome";
  } catch (e) { inFrame = false; }
  if (!inFrame || !embeddedByExtension) return;   // 일반 웹 탭 → 건드리지 않는다

  try { window.CHOIMINI_APP = "chrome"; window.CHOIMINI_SKIP_CLOUDFLARE = true; } catch (e) {}

  /* ---- 1) Cloudflare 확인 제거 ---- */
  function unlock() {
    try {
      var root = document.documentElement;
      // 클래스가 있을 때만 지운다 (classList.remove 는 없어도 속성을 다시 써서 변경 이벤트 → 무한 루프가 된다)
      if (root && root.classList.contains("jcv2-locked")) root.classList.remove("jcv2-locked");
      var g = document.getElementById("jcv2-gate");
      if (g) g.remove();
    } catch (e) {}
  }
  function watch(root) {
    unlock();
    var mo = new MutationObserver(unlock);
    mo.observe(root, { childList: true, subtree: true, attributes: true, attributeFilter: ["class"] });
    window.addEventListener("load", function () { setTimeout(function () { unlock(); mo.disconnect(); }, 8000); });
  }
  try {
    if (document.documentElement) watch(document.documentElement);
    else {
      var wait = new MutationObserver(function () { if (document.documentElement) { wait.disconnect(); watch(document.documentElement); } });
      wait.observe(document, { childList: true });
    }
  } catch (e) {}

  /* ---- 2) Google 로그인을 실제 탭으로 ---- */
  function isAuthorizeUrl(u) {
    return u.protocol === "https:" && /\.supabase\.co$/.test(u.hostname) && u.pathname.indexOf("/auth/v1/authorize") === 0;
  }
  try {
    if (window.navigation && window.navigation.addEventListener) {
      window.navigation.addEventListener("navigate", function (e) {
        try {
          var u = new URL(e.destination.url);
          if (!isAuthorizeUrl(u)) return;
          if (e.cancelable) e.preventDefault();       // iframe 안에서는 구글이 막으므로 이동을 취소하고
          window.parent.postMessage({ source: "choimini-web", type: "open-auth", url: u.href }, "*");   // 부모가 실제 탭으로 연다
        } catch (err) {}
      });
    }
  } catch (e) {}

  // 로그인이 끝나 돌아온 code 를 사이트의 콜백 함수(auth.js)에 전달. (새 auth.js 는 자체 리스너를 쓰므로 중복 처리하지 않는다)
  window.addEventListener("message", function (e) {
    try {
      if (window.__choiminiChromeAuthListener) return;
      if (e.source !== window.parent || !/^chrome-extension:/.test(e.origin)) return;
      var d = e.data;
      if (!d || d.source !== "choimini-ext" || d.type !== "auth-callback" || typeof d.url !== "string") return;
      if (typeof window.__choiminiHandleAuthCallback === "function") window.__choiminiHandleAuthCallback(d.url);
    } catch (err) {}
  });
})();
