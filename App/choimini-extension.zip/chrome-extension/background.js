// Chrome in Choimini — 백그라운드 서비스 워커 (MV3)
//  1) 아이콘 클릭 → 사이드 패널
//  2) 사이드 패널이 보낸 "브라우저 제어" 요청을 활성 탭에 전달
//     - navigate / new_tab / list_tabs : 여기서 직접 처리
//     - 그 외(snapshot/click/type/...)  : agent.js를 주입하고 콘텐츠 스크립트로 전달

// 사이드 패널은 "창 전체(전역)" 패널로 고정한다. 탭별(tabId) 설정을 쓰면 다른 탭으로 갔다 올 때 패널이 닫힌다.
const PANEL = { path: "sidepanel.html", enabled: true };
function setupPanel() {
  chrome.sidePanel.setOptions(PANEL).catch((e) => console.error(e));
  chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }).catch((e) => console.error(e));
}
chrome.runtime.onInstalled.addListener(setupPanel);
chrome.runtime.onStartup.addListener(setupPanel);
setupPanel(); // 서비스 워커가 다시 깨어날 때마다 전역 설정을 다시 확인

// 지금 보고 있는 탭을 사이드 패널(→ 사이트)에 실시간으로 알린다. 탭을 옮겨도 패널은 그대로 유지된다.
function tabInfo(tab) { return tab ? { id: tab.id, title: tab.title || "", url: tab.url || "" } : null; }
async function broadcastCurrentTab() {
  try {
    const [tab] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
    if (tab) chrome.runtime.sendMessage({ type: "CURRENT_TAB", tab: tabInfo(tab) }).catch(() => {});
  } catch (_) {}
}
chrome.tabs.onActivated.addListener(() => broadcastCurrentTab());
chrome.tabs.onUpdated.addListener((id, info, tab) => { if (tab.active && (info.status === "complete" || info.title || info.url)) broadcastCurrentTab(); });
chrome.windows.onFocusChanged.addListener(() => broadcastCurrentTab());
chrome.runtime.onMessage.addListener((m, _s, send) => { if (m && m.type === "GET_CURRENT_TAB") { chrome.tabs.query({ active: true, lastFocusedWindow: true }).then(([t]) => send({ tab: tabInfo(t) })).catch(() => send({ tab: null })); return true; } });

chrome.action.onClicked.addListener(async (tab) => {
  try { await chrome.sidePanel.open({ windowId: tab.windowId }); }
  catch (e) { chrome.tabs.create({ url: chrome.runtime.getURL("sidepanel.html") }); }
});

const AGENT_ACTIONS = new Set(["snapshot", "read_text", "click", "type", "select", "check", "submit", "scroll", "wait"]);

function isHttp(url) { try { const p = new URL(url).protocol; return p === "http:" || p === "https:"; } catch (_) { return false; } }

async function activeTab() {
  const [tab] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
  if (!tab) throw new Error("활성 탭이 없어요.");
  if (!isHttp(tab.url || "")) throw new Error("이 페이지는 제어할 수 없어요 (chrome:// 등 브라우저 내부 페이지). 일반 웹페이지를 열어주세요.");
  return tab;
}

function waitForComplete(tabId, timeoutMs = 15000) {
  return new Promise((resolve) => {
    const done = () => { chrome.tabs.onUpdated.removeListener(onUpd); clearTimeout(t); resolve(); };
    const onUpd = (id, info) => { if (id === tabId && info.status === "complete") done(); };
    const t = setTimeout(done, timeoutMs);
    chrome.tabs.onUpdated.addListener(onUpd);
  });
}

async function hasHostAccess() {
  return chrome.permissions.contains({ origins: ["<all_urls>"] });
}

async function handleBrowserAction(action, args) {
  args = args || {};

  if (!(await hasHostAccess())) {
    return { ok: false, error: "NO_PERMISSION", message: "사이드 패널의 '페이지 제어 허용' 버튼을 먼저 눌러주세요." };
  }

  if (action === "list_tabs") {
    const tabs = await chrome.tabs.query({ lastFocusedWindow: true });
    return { ok: true, result: tabs.filter((t) => isHttp(t.url || "")).map((t) => ({ id: t.id, title: t.title, url: t.url, active: t.active })) };
  }

  if (action === "navigate" || action === "new_tab") {
    if (!isHttp(args.url)) return { ok: false, error: "BAD_URL", message: "http(s) 주소만 열 수 있어요." };
    let tab;
    if (action === "new_tab") tab = await chrome.tabs.create({ url: args.url });
    else { const cur = await activeTab().catch(() => null); tab = cur ? await chrome.tabs.update(cur.id, { url: args.url }) : await chrome.tabs.create({ url: args.url }); }
    await waitForComplete(tab.id);
    return { ok: true, result: { tabId: tab.id, url: args.url } };
  }

  if (!AGENT_ACTIONS.has(action)) return { ok: false, error: "UNKNOWN_ACTION", message: "지원하지 않는 액션: " + action };

  const tab = await activeTab();
  await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ["agent.js"] });
  const resp = await chrome.tabs.sendMessage(tab.id, { target: "choimini-agent", action, args });
  if (!resp) return { ok: false, error: "NO_RESPONSE" };
  if (!resp.ok) return { ok: false, error: "AGENT_ERROR", message: resp.error };
  return { ok: true, result: resp.result };
}

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (!msg || msg.type !== "BROWSER_ACTION") return;
  handleBrowserAction(msg.action, msg.args)
    .then(sendResponse)
    .catch((e) => sendResponse({ ok: false, error: "EXCEPTION", message: String(e && e.message || e) }));
  return true;
});
