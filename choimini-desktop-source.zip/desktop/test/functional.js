// Choimini Desktop / Choimini Code 기능 테스트 — 실제 Electron 을 가상 화면에서 띄워 CDP 로 조작한다.
// 준비: apt install xvfb / npm i ws / Xvfb :99 &   실행: node test/functional.js   (APP=/path/to/app.asar 로 패키징본도 검사)
// 사이트는 로컬 테스트 서버로 대체(CHOIMINI_DEV_SITE, 패키징된 앱에서는 무시됨) → 사이트→webview→앱→메인 프로세스 경로를 그대로 탄다.
const { spawn } = require("child_process"), http = require("http"), fs = require("fs"), os = require("os"), path = require("path");
const WebSocket = require("ws");
const PORT = 9337, SITE_PORT = 8765;
const APP = process.env.APP || path.join(__dirname, "..");
const ELECTRON = process.env.ELECTRON_BIN || path.join(__dirname, "..", "node_modules", "electron", "dist", "electron");
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
let pass = 0, failN = 0;
const check = (n, ok, x) => { ok ? pass++ : failN++; console.log((ok ? "  PASS " : "  FAIL ") + n + (ok ? "" : "  " + (x || ""))); };
const getJson = (u) => new Promise((res, rej) => http.get(u, (r) => { let b = ""; r.on("data", (d) => (b += d)); r.on("end", () => res(JSON.parse(b))); }).on("error", rej));

// ---- 테스트용 작업 폴더 + "밖" 폴더 ----
const ws = fs.realpathSync(fs.mkdtempSync(path.join(os.tmpdir(), "cws-")));
const outside = fs.realpathSync(fs.mkdtempSync(path.join(os.tmpdir(), "cout-")));
fs.writeFileSync(path.join(outside, "secret.txt"), "TOP-SECRET");
fs.writeFileSync(path.join(ws, "hello.txt"), "line one\nline two\nline three\n");
fs.mkdirSync(path.join(ws, "src")); fs.writeFileSync(path.join(ws, "src", "app.js"), "function main() {\n  return 1;\n}\n// TODO later\n");
fs.symlinkSync(outside, path.join(ws, "escape"));

// ---- 로컬 테스트 사이트 ----
const siteHtml = `<html><body>site<script>window.__atParse={app:window.CHOIMINI_APP,cf:window.CHOIMINI_SKIP_CLOUDFLARE,mode:window.CHOIMINI_MODE,mult:window.CHOIMINI_TOKEN_MULTIPLIER};
window.__events=[];window.addEventListener("choimini-mode",function(e){window.__events.push(e.detail.mode)});</script></body></html>`;
const site = http.createServer((q, r) => { r.writeHead(200, { "Content-Type": "text/html" }); r.end(siteHtml); });

(async () => {
  await new Promise((r) => site.listen(SITE_PORT, "127.0.0.1", r));
  const ud = fs.mkdtempSync(path.join(os.tmpdir(), "cud-"));
  const el = spawn(ELECTRON, [APP, "--no-sandbox", "--disable-gpu", `--remote-debugging-port=${PORT}`, `--user-data-dir=${ud}`],
    { env: { ...process.env, DISPLAY: process.env.DISPLAY || ":99", CHOIMINI_DEV_SITE: `http://127.0.0.1:${SITE_PORT}/`, CHOIMINI_TEST_WORKSPACE: ws }, stdio: ["ignore", "pipe", "pipe"] });
  let logs = ""; el.stdout.on("data", (d) => (logs += d)); el.stderr.on("data", (d) => (logs += d));
  let targets;
  for (let i = 0; i < 50; i++) { try { targets = await getJson(`http://127.0.0.1:${PORT}/json`); if (targets.some((t) => /renderer\/index\.html/.test(t.url))) break; } catch (_) {} await sleep(400); }
  const page = (targets || []).find((t) => /renderer\/index\.html/.test(t.url));
  if (!page) { console.log("no page\n" + logs.slice(-800)); el.kill(); process.exit(1); }
  const cdp = new WebSocket(page.webSocketDebuggerUrl); await new Promise((r) => cdp.on("open", r));
  let id = 0; const pend = {}; cdp.on("message", (m) => { const j = JSON.parse(m); if (j.id && pend[j.id]) { pend[j.id](j); delete pend[j.id]; } });
  const host = (expr) => new Promise((res) => { const i = ++id; pend[i] = res; cdp.send(JSON.stringify({ id: i, method: "Runtime.evaluate", params: { expression: expr, awaitPromise: true, returnByValue: true } })); }).then((r) => (r.result && r.result.result ? r.result.result.value : undefined));
  const inPage = async (code) => { const r = await host(`document.getElementById('choimini').executeJavaScript(${JSON.stringify(code)})`); return r; };
  const waitFor = async (fn, ms = 6000) => { const t0 = Date.now(); while (Date.now() - t0 < ms) { if (await fn()) return true; await sleep(120); } return false; };
  const callTool = (tool, args) => inPage(`window.DesktopBridge.callTool(${JSON.stringify(tool)}, ${JSON.stringify(args || {})})`);
  const modalShown = () => host("document.getElementById('permModal').classList.contains('show')");
  const clickPerm = (which) => host(`document.getElementById('${which}').click()`);
  const read = (f) => fs.readFileSync(path.join(ws, f), "utf8");
  const navSite = async () => { await host(`new Promise(r=>{const w=document.getElementById('choimini');w.addEventListener('dom-ready',()=>setTimeout(()=>r(1),700),{once:true});w.src='http://127.0.0.1:${SITE_PORT}/?'+Date.now();setTimeout(()=>r(0),12000)})`); };
  await waitFor(async () => (await host("!!document.getElementById('choimini')")) === true); await sleep(1500);

  console.log("\n[1] Baseline: not logged in");
  check("window title / Chat mode / no Code panel", (await host("document.title")) === "Choimini Desktop" && (await host("!document.body.classList.contains('code')")) === true);
  check("Code button looks locked and status says login required", (await host("document.getElementById('modeCode').classList.contains('locked')")) === true && /로그인 필요/.test(await host("document.getElementById('authState').textContent")));
  check("NO token multiplier badge in the UI anymore", (await host("!document.getElementById('mult') && !/토큰\\s*\\d/.test(document.body.innerText)")) === true);
  check("xterm bundled locally", (await host("typeof Terminal")) === "function");
  let r = await host("window.desktop.setMode('code')");
  check("Code mode refused without login (reason=login)", r && r.ok === false && r.reason === "login", JSON.stringify(r));
  r = await callTool("read_file", { path: "hello.txt" });
  check("tools refused without login", r && r.ok === false && /로그인/.test(r.error), JSON.stringify(r));
  await host("document.getElementById('modeCode').click()"); await sleep(400);
  check("clicking Code while logged out does nothing (no captcha, still Chat)", (await host("!document.body.classList.contains('code') && !document.getElementById('captchaModal').classList.contains('show')")) === true);

  console.log("\n[2] The site reports login (real webview → host → main path)");
  fs.writeFileSync("/tmp/other-origin.html", "<html><body>other</body></html>");
  await host(`new Promise(r=>{const w=document.getElementById('choimini');w.addEventListener('dom-ready',()=>setTimeout(()=>r(1),700),{once:true});w.src='file:///tmp/other-origin.html';setTimeout(()=>r(0),12000)})`);
  await inPage("window.DesktopBridge.reportAuth(true); 1"); await sleep(500);
  check("a page from ANOTHER origin cannot mark the user as logged in", /로그인 필요/.test(await host("document.getElementById('authState').textContent")) && (await host("window.desktop.codeStatus()")).authOk === false);
  await navSite();
  const atParse = JSON.parse(await inPage("JSON.stringify(window.__atParse)") || "{}");
  check("site sees app=desktop + Cloudflare-skip flag at parse time; NO multiplier value", atParse.app === "desktop" && atParse.cf === true && atParse.mult === undefined, JSON.stringify(atParse));
  await inPage("window.DesktopBridge.reportAuth(true); 1");
  check("real site origin: 로그인됨 shown and Code button unlocked", await waitFor(async () => /로그인됨/.test(await host("document.getElementById('authState').textContent")) && (await host("!document.getElementById('modeCode').classList.contains('locked')")) === true));
  r = await host("window.desktop.setMode('code')");
  check("still needs the captcha even when logged in (reason=captcha)", r && r.ok === false && r.reason === "captcha", JSON.stringify(r));
  r = await callTool("read_file", { path: "hello.txt" });
  check("tools still refused before captcha", r && r.ok === false && /캡차/.test(r.error), JSON.stringify(r));

  console.log("\n[3] Captcha → Code mode");
  await host("document.getElementById('modeCode').click()"); await sleep(400);
  check("captcha modal opens", (await host("document.getElementById('captchaModal').classList.contains('show')")) === true);
  const svg = Buffer.from((await host("document.getElementById('captchaImg').src")).split(",")[1], "base64").toString("utf8");
  const answer = [...svg.matchAll(/<text[^>]*>([A-Z0-9])<\/text>/g)].map((m) => m[1]).join(""); // 테스트 전용: 사람은 이미지를 본다
  await host(`document.getElementById('captchaInput').value='${answer}'; document.getElementById('captchaOk').click()`); await sleep(900);
  check("correct answer → Code mode, panel visible, workspace shown", (await host("document.body.classList.contains('code')")) === true && /cws-/.test(await host("document.getElementById('wsBtn').title")));
  check("webview now reports mode=code and gets the agent prompt (tools + workspace + permission mode)", await waitFor(async () => {
    const v = JSON.parse((await inPage("JSON.stringify({m:window.CHOIMINI_MODE,p:window.CHOIMINI_CODE_MODE_PROMPT||''})")) || "{}");
    return v.m === "code" && /read_file/.test(v.p) && /edit_file/.test(v.p) && v.p.includes(ws) && /권한 모드: 묻기/.test(v.p);
  }));
  check("terminal starts inside the workspace", await (async () => { await host("window.desktop.termInput('main','pwd\\n')"); await sleep(1200); const b = await host("(()=>{const b=term.buffer.active;let o='';for(let i=0;i<b.length;i++){const l=b.getLine(i);if(l)o+=l.translateToString(true)+'\\n'}return o})()"); return (b || "").includes(ws); })());

  console.log("\n[4] Read tools (no approval needed)");
  r = await callTool("read_file", { path: "hello.txt" });
  check("read_file", r.ok && /1\tline one/.test(r.output) && /3\tline three/.test(r.output), JSON.stringify(r));
  r = await callTool("list_dir", {}); check("list_dir", r.ok && /src\//.test(r.output) && /hello\.txt/.test(r.output));
  r = await callTool("glob", { pattern: "**/*.js" }); check("glob", r.ok && /src\/app\.js/.test(r.output));
  r = await callTool("grep", { pattern: "TODO" }); check("grep", r.ok && /src\/app\.js:4:/.test(r.output));
  check("no approval dialog appeared for reads", (await modalShown()) === false);
  check("activity panel lists the calls with a check mark", (await host("document.querySelectorAll('#activity .act.ok').length")) >= 4);

  console.log("\n[5] Sandbox (through the real app path)");
  for (const [name, p] of [["'..' escape", "../" + path.basename(outside) + "/secret.txt"], ["absolute path outside", path.join(outside, "secret.txt")], ["symlinked folder out", "escape/secret.txt"]]) {
    r = await callTool("read_file", { path: p });
    check(`${name} is blocked`, r.ok === false && /밖은 접근할 수 없어요/.test(r.error) && !/TOP-SECRET/.test(JSON.stringify(r)), JSON.stringify(r));
  }
  r = callTool("write_file", { path: "escape/pwned.txt", content: "x" }); r = await r;
  check("writing through the symlink is blocked, nothing created outside", r.ok === false && !fs.existsSync(path.join(outside, "pwned.txt")) && (await modalShown()) === false, JSON.stringify(r));

  console.log("\n[6] Editing needs approval (ask mode)");
  await inPage("window.__p = window.DesktopBridge.callTool('edit_file', {path:'hello.txt', old_string:'line two', new_string:'LINE 2 CHANGED'}); 1");
  check("approval dialog appears with a real diff", await waitFor(modalShown) && /LINE 2 CHANGED/.test(await host("document.getElementById('permBody').innerText")) && (await host("document.querySelectorAll('#permBody .ln-add').length")) >= 1 && (await host("document.querySelectorAll('#permBody .ln-del').length")) >= 1);
  check("file is NOT changed while waiting", read("hello.txt").includes("line two"));
  await clickPerm("permDeny"); r = await inPage("window.__p");
  check("deny → tool result says denied, file untouched", r.ok === false && r.denied === true && /거부/.test(r.error) && read("hello.txt").includes("line two"), JSON.stringify(r));
  await inPage("window.__p = window.DesktopBridge.callTool('edit_file', {path:'hello.txt', old_string:'line two', new_string:'LINE 2 CHANGED'}); 1");
  await waitFor(modalShown); await clickPerm("permAllow"); r = await inPage("window.__p");
  check("allow → file edited exactly once", r.ok === true && read("hello.txt") === "line one\nLINE 2 CHANGED\nline three\n", JSON.stringify(r) + read("hello.txt"));
  check("activity panel shows the diff for that edit", (await host("[...document.querySelectorAll('#activity .act.ok')].some(e=>e.querySelector('.ln-add'))")) === true);
  r = await callTool("edit_file", { path: "hello.txt", old_string: "does not exist", new_string: "x" });
  check("failed edit reports why, without asking", r.ok === false && /찾지 못했어요/.test(r.error) && (await modalShown()) === false);

  console.log("\n[7] New file + 'allow for this session'");
  await inPage("window.__p = window.DesktopBridge.callTool('write_file', {path:'notes/new.md', content:'# hi\\n'}); 1");
  check("write_file asks first", await waitFor(modalShown) && !fs.existsSync(path.join(ws, "notes")));
  await clickPerm("permSession"); r = await inPage("window.__p");
  check("created after 'session' approval", r.ok === true && read("notes/new.md") === "# hi\n");
  r = await callTool("edit_file", { path: "notes/new.md", old_string: "# hi", new_string: "# hello" });
  check("later edits are auto-approved (no dialog) for the session", r.ok === true && read("notes/new.md") === "# hello\n" && (await modalShown()) === false, JSON.stringify(r));

  console.log("\n[8] Commands need approval and run in the workspace");
  await inPage("window.__p = window.DesktopBridge.callTool('run_command', {command:'pwd && echo CMD_OK_$((6*7))'}); 1");
  check("command dialog shows the command", await waitFor(modalShown) && /CMD_OK_\$\(\(6\*7\)\)/.test(await host("document.getElementById('permBody').innerText")));
  await clickPerm("permAllow"); r = await inPage("window.__p");
  check("ran inside the workspace and returned output + exit code", r.ok && r.exitCode === 0 && r.output.includes(ws) && /CMD_OK_42/.test(r.output), JSON.stringify(r));
  await inPage("window.__p = window.DesktopBridge.callTool('run_command', {command:'echo SHOULD_NOT_RUN > ran.txt'}); 1");
  await waitFor(modalShown); await clickPerm("permDeny"); r = await inPage("window.__p");
  check("denied command never runs", r.denied === true && !fs.existsSync(path.join(ws, "ran.txt")));
  await inPage("window.__p = window.DesktopBridge.callTool('run_command', {command:'echo before-fail; sh -c \"exit 3\"'}); 1");
  await waitFor(modalShown); await clickPerm("permAllow"); r = await inPage("window.__p");
  check("non-zero exit code is reported to the model (not hidden)", r.ok === true && r.exitCode === 3 && /종료코드 3/.test(r.output) && /before-fail/.test(r.output), JSON.stringify(r));
  await inPage("window.__p = window.DesktopBridge.callTool('run_command', {command:'echo again'}); 1"); await waitFor(modalShown); await clickPerm("permSession"); await inPage("window.__p");
  r = await callTool("run_command", { command: "echo again" });
  check("same command approved for the session runs without a dialog", r.ok && /again/.test(r.output) && (await modalShown()) === false);

  console.log("\n[9] Permission modes");
  await host("(()=>{const s=document.getElementById('permMode');s.value='plan';s.dispatchEvent(new Event('change'))})()"); await sleep(700);
  check("plan mode is reflected in the prompt the site gets", /계획 전용/.test(await inPage("window.CHOIMINI_CODE_MODE_PROMPT")));
  r = await callTool("read_file", { path: "hello.txt" }); check("plan mode: reading still works", r.ok);
  r = await callTool("edit_file", { path: "hello.txt", old_string: "line one", new_string: "X" });
  check("plan mode: edit is refused without asking, file untouched", r.ok === false && /계획 모드/.test(r.error) && read("hello.txt").startsWith("line one") && (await modalShown()) === false, JSON.stringify(r));
  r = await callTool("run_command", { command: "touch plan-ran.txt" });
  check("plan mode: commands refused too", r.ok === false && /계획 모드/.test(r.error) && !fs.existsSync(path.join(ws, "plan-ran.txt")));
  await host("(()=>{const s=document.getElementById('permMode');s.value='acceptEdits';s.dispatchEvent(new Event('change'))})()"); await sleep(500);
  r = await callTool("write_file", { path: "auto.txt", content: "auto\n" });
  check("acceptEdits: file changes need no dialog", r.ok && read("auto.txt") === "auto\n" && (await modalShown()) === false);
  await inPage("window.__p = window.DesktopBridge.callTool('run_command', {command:'echo needs-approval'}); 1");
  check("acceptEdits: commands STILL ask", await waitFor(modalShown)); await clickPerm("permDeny"); await inPage("window.__p");
  await host("(()=>{const s=document.getElementById('permMode');s.value='ask';s.dispatchEvent(new Event('change'))})()");

  console.log("\n[10] Interrupt");
  await host("document.getElementById('abortBtn').click()"); await sleep(300);
  r = await callTool("read_file", { path: "hello.txt" });
  check("after ⏹ the next tool call returns aborted=true", r.ok === false && r.aborted === true, JSON.stringify(r));
  r = await callTool("read_file", { path: "hello.txt" }); check("…and work can continue afterwards", r.ok === true);

  console.log("\n[11] Leaving Code mode / logging out closes everything");
  await host("document.getElementById('modeChat').click()"); await sleep(500);
  r = await callTool("read_file", { path: "hello.txt" });
  check("Chat mode: tools refused", r.ok === false && /Code 모드에서만/.test(r.error), JSON.stringify(r));
  check("Chat mode: webview loses the agent prompt", (await inPage("window.CHOIMINI_MODE")) === "chat" && (await inPage("window.CHOIMINI_CODE_MODE_PROMPT")) === "");
  await host("document.getElementById('modeCode').click()"); await sleep(700);
  check("back to Code needs no second captcha", (await host("document.body.classList.contains('code')")) === true);
  await inPage("window.__p = window.DesktopBridge.callTool('run_command', {command:'echo pending-at-logout'}); 1"); await waitFor(modalShown);
  await inPage("window.DesktopBridge.reportAuth(false); 1"); await sleep(700);
  check("logout: forced back to Chat, the pending approval is cancelled AND its dialog is closed", (await host("!document.body.classList.contains('code')")) === true && /로그인 필요/.test(await host("document.getElementById('authState').textContent")) && (await modalShown()) === false);
  r = await inPage("window.__p"); check("logout: the pending command never ran", r.ok === false && r.denied === true, JSON.stringify(r));
  r = await callTool("read_file", { path: "hello.txt" }); check("logout: tools refused again", r.ok === false && /로그인/.test(r.error));
  await host("window.desktop.setAuth(true)"); r = await host("window.desktop.setMode('code')");
  check("logging back in re-enters Code mode (captcha memory kept)", r && r.ok === true, JSON.stringify(r));
  await host("window.__hp = window.desktop.callTool('run_command', {command:'echo again'}); 1");
  check("logout cleared the 'allowed for this session' memory (dialog is back for the same command)", await waitFor(modalShown));
  await clickPerm("permDeny"); await host("window.__hp");

  console.log(`\n${pass} passed, ${failN} failed`);
  cdp.close(); el.kill(); site.close(); await sleep(300); process.exit(failN ? 1 : 0);
})();
