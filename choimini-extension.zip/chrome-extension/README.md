# Chrome in Choimini (크롬 확장)

최미나이를 사이드 패널에서 쓰고, **최미나이가 브라우저를 직접 탐색하며 양식을 채워주는** 확장. (Chrome in Claude와 같은 개념)
**Google 로그인 필수 · Cloudflare 확인 없음(웹사이트로 직접 접속할 때만 사용) · 토큰 배수 없음.**

## 설치 (개발자 모드)
1. `config.js`의 `CHOIMINI_SITE_URL` 확인
2. `chrome://extensions` → 개발자 모드 → "압축해제된 확장 프로그램을 로드" → 이 폴더
3. 툴바 아이콘 → 사이드 패널. 상단의 **[페이지 제어 허용]** 을 눌러야 브라우저 제어가 켜진다(모든 사이트 접근 권한 요청).

## 브라우저 자동 제어
`sidepanel.js`가 최미나이 iframe ↔ 확장을 postMessage로 중계 → `background.js` → 활성 탭에 `agent.js` 주입.
액션: `navigate new_tab list_tabs snapshot read_text click type select check submit scroll wait`.
사이트(웹앱) 쪽 연동은 `web/choimini-browser.js` + `web/INTEGRATION.md` 9번.

### Cloudflare 확인 제거 + Google 로그인 (사이트가 예전 버전이어도 동작)
- `nocf.js`(manifest의 content script, MAIN world)가 **사이드 패널 안에 임베드된 사이트에서만** 실행된다. 사이트를 일반 탭으로 열면 아무 것도 하지 않아서 **웹사이트에서는 Cloudflare가 그대로 유지**된다(`?app=chrome`을 주소창에 직접 쳐도 소용없음 — iframe 안이어야 함).
- **Google 로그인이 안 되던 원인**: 사이드 패널은 iframe인데 구글은 iframe 안 로그인을 막는다. 이제 iframe이 구글(Supabase authorize)로 이동하려는 순간을 가로채(Navigation API) 사이드 패널에 알리고, 사이드 패널이 **실제 탭**으로 로그인 창을 연다. 로그인 후 사이트로 돌아오면 URL의 `code`를 iframe에 전달해 세션으로 교환하고 탭을 닫는다. (PKCE라서 `code`는 iframe이 가진 verifier가 있어야만 쓸 수 있다)
- 안전: 로그인 탭으로 여는 주소는 `https://*.supabase.co/auth/v1/authorize`만 허용(다른 주소·http·javascript:·비슷한 도메인 거부), 우리가 연 탭에서 온 것만 처리, 코드는 1회만.
- 사이트의 새 `choimini-auth.js`를 올리면 사이트 자체도 같은 흐름을 쓴다(이 경우 `nocf.js`는 중복 처리하지 않는다).
- **⚠ 진짜 Chrome에서는 확인하지 못했다.** `content_scripts`가 확장 페이지 안의 iframe에도 주입되는지, Navigation API가 이동을 취소해 주는지는 이 환경(Chrome 없음)에서 검증할 수 없어 jsdom+가짜 환경으로만 확인했다. 안 되면 사이트의 새 `choimini-auth.js`(사이트 업로드)가 확실한 경로다.
- 확장을 갱신했으면 `chrome://extensions`에서 **새로고침**하고 사이드 패널을 다시 열어야 한다(content script가 바뀜).

### 로그인 필수
사이트가 로그인 상태를 알려주고(`postMessage`, origin/source 엄격 검사), **로그인 전에는 페이지 제어 요청 자체를 확장이 거부**한다(상태 표시: "로그인 필요"). 로그아웃하면 즉시 다시 막힌다.
다른 origin이 보낸 "로그인됨" 위조 메시지는 무시한다. (`test/sidepanel.test.js` 28개: 로그인 강제/위조 무시/정지/로그아웃/로그인 탭 흐름/사이트 버전 감지, `test/nocf.test.js` 21개: **실제 예전 index.html**에 대해 실행 — 사이드 패널에서만 제거되고 웹 탭은 그대로인지 포함)

### 안전장치 (확장이 강제 — 사이트/모델이 못 끔)
- 사용자가 버튼으로 권한을 준 뒤에만 동작, **[정지]** 버튼으로 즉시 차단
- 비밀번호·카드번호·CVV·인증번호 필드는 입력 거부 (사용자가 직접 입력)
- **제출(submit / 제출 버튼 클릭)은 확인창에서 [제출 허용]을 눌러야 실행** — 전송 대상 도메인과 채워진 필드 목록을 보여줌
- http(s) 페이지만 제어 (chrome://, 확장 페이지 제외)

### 한계
최상위 문서만 다룬다 (iframe 내부/Shadow DOM/캔버스 UI는 못 봄). 캡차·2단계 인증은 사용자가 직접.
확인창(제출 허용)은 사이드 패널이 열려 있어야 보인다.

## 임베드(iframe) 허용
사이드 패널은 사이트를 iframe으로 로드하므로 사이트가 프레이밍을 막으면 브라우저 제어가 동작하지 않고 "새 탭에서 열기" 폴백만 뜬다.
```
Content-Security-Policy: frame-ancestors 'self' chrome-extension://<확장ID>;
```
(GitHub Pages는 응답 헤더를 못 바꾸므로 Cloudflare 등을 앞에 두거나, 확장 쪽에서 로컬 번들로 여는 방식이 필요할 수 있음)

## 참고
이전 버전 manifest에 `default_locale`이 있었는데 `_locales/` 폴더가 없어 크롬이 로드를 거부하므로 제거했다.
