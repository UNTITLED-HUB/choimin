// Choimini Code 도구 계층 (Electron 판 agent-tools.js 를 그대로 옮긴 것)
// read_file / list_dir / glob / grep / write_file / edit_file / todo_write + 명령 위험도 분류 + 민감 파일 판별
// - WinForms/WebView2 와 무관한 순수 코드 → Linux(Mono)에서도 단위 테스트한다 (tests/ToolsTest.cs)
// - 모든 경로는 "작업 폴더" 안으로 제한: .. 이동, 절대경로, 심볼릭 링크/정션으로 밖을 가리키는 경우 차단. .git 내부는 쓰기 금지.
using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;

namespace Choimini
{
    public class ToolError : Exception { public ToolError(string m) : base(m) { } }

    public class ToolResult
    {
        public bool Ok = true;
        public string Output = "";
        public List<Dictionary<string, object>> Items; // todo_write
    }

    public class Prepared
    {
        public string Rel, Title, Diff;
        public bool Creating;
        public Func<ToolResult> Apply;
    }

    public class Workspace
    {
        public readonly string Root;
        public Workspace(string root) { Root = root; }

        public string Resolve(object p)
        {
            string input = p == null ? "." : Convert.ToString(p);
            if (input == "") input = ".";
            if (input.IndexOf('\0') >= 0) throw new ToolError("잘못된 경로예요.");
            string abs;
            try { abs = Path.GetFullPath(Path.IsPathRooted(input) ? input : Path.Combine(Root, input)); }
            catch (Exception) { throw new ToolError("잘못된 경로예요: " + input); }
            // 아직 없는 파일이면 "존재하는 가장 가까운 상위 폴더"의 실제 경로로 검사 (링크로 밖에 나가는 것 방지)
            string probe = abs;
            while (!File.Exists(probe) && !Directory.Exists(probe))
            {
                string up = Path.GetDirectoryName(probe);
                if (string.IsNullOrEmpty(up) || up == probe) break;
                probe = up;
            }
            string real = Tools.RealPath(probe);
            if (!Tools.IsInside(Root, real)) throw new ToolError("작업 폴더 밖은 접근할 수 없어요: " + input);
            return abs;
        }

        public string Rel(string abs)
        {
            string r = Tools.Relative(Root, abs);
            return r == "" ? "." : r;
        }
    }

    public static class Tools
    {
        const long MAX_READ_BYTES = 2 * 1024 * 1024;
        const int MAX_LINES = 2000;
        const long MAX_WRITE_BYTES = 1024 * 1024;
        const int MAX_WALK = 30000;
        static readonly HashSet<string> SKIP_DIRS = new HashSet<string> { "node_modules", ".git" };
        static readonly bool IsWindows = Path.DirectorySeparatorChar == '\\';
        static StringComparison PathCmp { get { return IsWindows ? StringComparison.OrdinalIgnoreCase : StringComparison.Ordinal; } }

        static void Fail(string m) { throw new ToolError(m); }

        /* ---------------- 경로 유틸 ---------------- */
        public static string Posix(string p) { return p.Replace('\\', '/'); }

        public static bool IsInside(string root, string p)
        {
            string r = root.TrimEnd('\\', '/');
            if (string.Equals(p.TrimEnd('\\', '/'), r, PathCmp)) return true;
            return p.StartsWith(r + Path.DirectorySeparatorChar, PathCmp);
        }

        public static string Relative(string root, string abs)
        {
            string r = root.TrimEnd('\\', '/');
            if (string.Equals(abs.TrimEnd('\\', '/'), r, PathCmp)) return "";
            if (abs.StartsWith(r + Path.DirectorySeparatorChar, PathCmp)) return Posix(abs.Substring(r.Length + 1));
            return Posix(abs);
        }

        // 링크(심볼릭 링크·정션)를 모두 풀어 "진짜" 경로를 돌려준다
        public static string RealPath(string p)
        {
            p = Path.GetFullPath(p);
            if (IsWindows)
            {
                string r = WinFinalPath(p);
                if (r != null) return r;
                return p;
            }
            // Unix(테스트용): 경로를 앞에서부터 한 칸씩 링크를 풀어 나간다
            string[] parts = p.Split(new[] { '/' }, StringSplitOptions.RemoveEmptyEntries);
            string cur = "/";
            int guard = 0;
            var queue = new List<string>(parts);
            while (queue.Count > 0 && guard++ < 200)
            {
                string part = queue[0]; queue.RemoveAt(0);
                string next = Path.Combine(cur, part);
                string target = UnixReadLink(next);
                if (target != null)
                {
                    string t = Path.IsPathRooted(target) ? target : Path.Combine(cur, target);
                    t = Path.GetFullPath(t);
                    var rest = t.Split(new[] { '/' }, StringSplitOptions.RemoveEmptyEntries).ToList();
                    rest.AddRange(queue); queue = rest; cur = "/";
                }
                else cur = next;
            }
            return cur;
        }

        [DllImport("libc", EntryPoint = "readlink", SetLastError = true)]
        static extern int readlink(string path, byte[] buf, int len);
        static string UnixReadLink(string p)
        {
            try
            {
                var buf = new byte[4096];
                int n = readlink(p, buf, buf.Length);
                if (n <= 0) return null;
                return Encoding.UTF8.GetString(buf, 0, n);
            }
            catch (Exception) { return null; }
        }

        [DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
        static extern IntPtr CreateFileW(string name, uint access, uint share, IntPtr sec, uint disp, uint flags, IntPtr tmpl);
        [DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
        static extern uint GetFinalPathNameByHandleW(IntPtr h, StringBuilder buf, uint len, uint flags);
        [DllImport("kernel32.dll", SetLastError = true)]
        static extern bool CloseHandle(IntPtr h);
        static string WinFinalPath(string p)
        {
            IntPtr h = CreateFileW(p, 0, 7, IntPtr.Zero, 3 /*OPEN_EXISTING*/, 0x02000000 /*BACKUP_SEMANTICS(폴더도 열기)*/, IntPtr.Zero);
            if (h == IntPtr.Zero || h == new IntPtr(-1)) return null;
            try
            {
                var sb = new StringBuilder(1024);
                uint n = GetFinalPathNameByHandleW(h, sb, (uint)sb.Capacity, 0);
                if (n == 0 || n > sb.Capacity) return null;
                string s = sb.ToString();
                if (s.StartsWith(@"\\?\UNC\")) s = @"\\" + s.Substring(8);
                else if (s.StartsWith(@"\\?\")) s = s.Substring(4);
                return s;
            }
            finally { CloseHandle(h); }
        }

        public static Workspace MakeWorkspace(string root)
        {
            if (string.IsNullOrEmpty(root)) Fail("작업 폴더가 선택되지 않았어요. 오른쪽 위 '작업 폴더 선택'을 눌러 주세요.");
            if (!Directory.Exists(root)) Fail("작업 폴더를 열 수 없어요: " + root);
            return new Workspace(RealPath(root));
        }

        static bool IsGitInternal(Workspace ws, string abs) { return ws.Rel(abs).Split('/').Contains(".git"); }

        static string ReadText(string abs)
        {
            if (Directory.Exists(abs)) Fail("디렉터리예요. list_dir 를 쓰세요.");
            if (!File.Exists(abs)) Fail("파일이(가) 없어요: " + abs);
            long size = new FileInfo(abs).Length;
            if (size > MAX_READ_BYTES) Fail("파일이 너무 커요 (" + size + "B, 최대 2MB). grep 으로 필요한 부분만 찾으세요.");
            byte[] buf = File.ReadAllBytes(abs);
            int lim = Math.Min(buf.Length, 8192);
            for (int i = 0; i < lim; i++) if (buf[i] == 0) Fail("바이너리 파일이라 읽을 수 없어요.");
            return new UTF8Encoding(false).GetString(buf).TrimStart('\uFEFF');
        }

        static string[] SplitLines(string t) { return Regex.Split(t, "\r?\n"); }
        static string S(Dictionary<string, object> a, string k) { object v; return a != null && a.TryGetValue(k, out v) && v != null ? Convert.ToString(v) : null; }
        static bool B(Dictionary<string, object> a, string k) { object v; return a != null && a.TryGetValue(k, out v) && v is bool && (bool)v; }
        static int N(Dictionary<string, object> a, string k, int def)
        {
            object v; if (a == null || !a.TryGetValue(k, out v) || v == null) return def;
            try { return Convert.ToInt32(v); } catch (Exception) { return def; }
        }

        /* ---------------- 읽기 도구 ---------------- */
        public static ToolResult ReadFile(Workspace ws, Dictionary<string, object> a)
        {
            string abs = ws.Resolve(S(a, "path"));
            string[] lines = SplitLines(ReadText(abs));
            int start = Math.Max(1, N(a, "offset", 1));
            int n = Math.Min(Math.Max(1, N(a, "limit", MAX_LINES)), MAX_LINES);
            var sb = new StringBuilder();
            int shown = 0;
            for (int i = start - 1; i < lines.Length && shown < n; i++, shown++)
            {
                string l = lines[i];
                if (shown > 0) sb.Append('\n');
                sb.Append((i + 1).ToString().PadLeft(5)).Append('\t').Append(l.Length > 2000 ? l.Substring(0, 2000) + "…" : l);
            }
            string body = sb.ToString();
            string more = start - 1 + n < lines.Length ? "\n… (전체 " + lines.Length + "줄 중 " + start + "-" + (start - 1 + shown) + " 표시. offset=" + (start + shown) + " 로 이어서 읽기)" : "";
            return new ToolResult { Output = (body == "" ? "(빈 파일)" : body) + more };
        }

        public static ToolResult ListDir(Workspace ws, Dictionary<string, object> a)
        {
            string p = S(a, "path") ?? ".";
            string abs = ws.Resolve(p);
            if (!Directory.Exists(abs)) { if (File.Exists(abs)) Fail("폴더가 아니에요: " + p); Fail("폴더이(가) 없어요: " + abs); }
            var dirs = new DirectoryInfo(abs).GetDirectories().OrderBy(d => d.Name, StringComparer.Ordinal).Select(d => d.Name + "/");
            var files = new DirectoryInfo(abs).GetFiles().OrderBy(f => f.Name, StringComparer.Ordinal).Select(f => f.Name + "  (" + f.Length + "B)");
            var all = dirs.Concat(files).ToList();
            string outp = string.Join("\n", all.Take(500));
            return new ToolResult { Output = (outp == "" ? "(빈 폴더)" : outp) + (all.Count > 500 ? "\n… " + (all.Count - 500) + "개 더 있음" : "") };
        }

        public static Regex GlobToRegex(string g)
        {
            var re = new StringBuilder();
            for (int i = 0; i < g.Length; i++)
            {
                char c = g[i];
                if (c == '*')
                {
                    if (i + 1 < g.Length && g[i + 1] == '*')
                    {
                        i++;
                        if (i + 1 < g.Length && g[i + 1] == '/') { i++; re.Append("(?:.*/)?"); } else re.Append(".*");
                    }
                    else re.Append("[^/]*");
                }
                else if (c == '?') re.Append("[^/]");
                else if (c == '{')
                {
                    int j = g.IndexOf('}', i);
                    if (j > i) { re.Append("(?:" + string.Join("|", g.Substring(i + 1, j - i - 1).Split(',').Select(x => Regex.Escape(x))) + ")"); i = j; }
                    else re.Append("\\{");
                }
                else re.Append(Regex.Escape(c.ToString()));
            }
            return new Regex("^" + re + "$");
        }

        static bool IsLink(FileSystemInfo fi) { try { return (fi.Attributes & FileAttributes.ReparsePoint) != 0 || (!IsWindows && UnixReadLink(fi.FullName) != null); } catch (Exception) { return true; } }

        // 심볼릭 링크/정션은 따라가지 않는다(작업 폴더 밖 유출 방지)
        static IEnumerable<string> Walk(string dir, int[] budget)
        {
            DirectoryInfo di; FileSystemInfo[] ents;
            try { di = new DirectoryInfo(dir); ents = di.GetFileSystemInfos(); } catch (Exception) { yield break; }
            foreach (var e in ents.OrderBy(x => x.Name, StringComparer.Ordinal))
            {
                if (budget[0]++ > MAX_WALK) yield break;
                if (IsLink(e)) continue;
                if (e is DirectoryInfo) { if (!SKIP_DIRS.Contains(e.Name)) foreach (var f in Walk(e.FullName, budget)) yield return f; }
                else yield return e.FullName;
            }
        }

        public static ToolResult Glob(Workspace ws, Dictionary<string, object> a)
        {
            string pat = S(a, "pattern"); if (string.IsNullOrEmpty(pat)) Fail("pattern 이 필요해요.");
            string bas = ws.Resolve(S(a, "path") ?? ".");
            var re = GlobToRegex(pat);
            var outl = new List<string>();
            foreach (var f in Walk(bas, new int[1]))
            {
                string r = Relative(bas, f);
                if (re.IsMatch(r)) { outl.Add(ws.Rel(f)); if (outl.Count >= 300) break; }
            }
            return new ToolResult { Output = outl.Count > 0 ? string.Join("\n", outl) + (outl.Count >= 300 ? "\n… (300개에서 자름)" : "") : "(일치하는 파일 없음)" };
        }

        public static ToolResult Grep(Workspace ws, Dictionary<string, object> a)
        {
            string pat = S(a, "pattern"); if (string.IsNullOrEmpty(pat)) Fail("pattern 이 필요해요.");
            Regex re = null;
            try { re = new Regex(pat, B(a, "ignore_case") ? RegexOptions.IgnoreCase : RegexOptions.None, TimeSpan.FromSeconds(2)); }
            catch (ArgumentException e) { Fail("정규식이 올바르지 않아요: " + e.Message); }
            string bas = ws.Resolve(S(a, "path") ?? ".");
            string gl = S(a, "glob");
            Regex gre = gl != null ? GlobToRegex(gl) : null;
            bool single = File.Exists(bas);
            var hits = new List<string>();
            IEnumerable<string> files = single ? new[] { bas } : Walk(bas, new int[1]);
            foreach (var f in files)
            {
                if (gre != null && !gre.IsMatch(Relative(single ? Path.GetDirectoryName(bas) : bas, f))) continue;
                byte[] buf;
                try { if (new FileInfo(f).Length > 1024 * 1024) continue; buf = File.ReadAllBytes(f); } catch (Exception) { continue; }
                bool bin = false; for (int i = 0; i < Math.Min(buf.Length, 4096); i++) if (buf[i] == 0) { bin = true; break; }
                if (bin) continue;
                string[] lines = SplitLines(new UTF8Encoding(false).GetString(buf));
                for (int i = 0; i < lines.Length; i++)
                {
                    bool m; try { m = re.IsMatch(lines[i]); } catch (RegexMatchTimeoutException) { m = false; }
                    if (m) { string l = lines[i]; hits.Add(ws.Rel(f) + ":" + (i + 1) + ":" + (l.Length > 300 ? l.Substring(0, 300) + "…" : l)); if (hits.Count >= 200) break; }
                }
                if (hits.Count >= 200) break;
            }
            return new ToolResult { Output = hits.Count > 0 ? string.Join("\n", hits) + (hits.Count >= 200 ? "\n… (200개에서 자름)" : "") : "(일치하는 내용 없음)" };
        }

        /* ---------------- diff ---------------- */
        public static string MakeDiff(string oldText, string newText, int context = 3)
        {
            string[] a = oldText.Split('\n'), b = newText.Split('\n');
            if ((long)a.Length * b.Length > 4000000) return "(변경이 커서 요약만 표시) -" + a.Length + "줄 +" + b.Length + "줄";
            int n = a.Length, m = b.Length;
            var dp = new int[(n + 1) * (m + 1)];
            for (int i = n - 1; i >= 0; i--) for (int j = m - 1; j >= 0; j--)
                    dp[i * (m + 1) + j] = a[i] == b[j] ? dp[(i + 1) * (m + 1) + j + 1] + 1 : Math.Max(dp[(i + 1) * (m + 1) + j], dp[i * (m + 1) + j + 1]);
            var ops = new List<KeyValuePair<char, string>>();
            int x = 0, y = 0;
            while (x < n && y < m)
            {
                if (a[x] == b[y]) { ops.Add(new KeyValuePair<char, string>(' ', a[x])); x++; y++; }
                else if (dp[(x + 1) * (m + 1) + y] >= dp[x * (m + 1) + y + 1]) ops.Add(new KeyValuePair<char, string>('-', a[x++]));
                else ops.Add(new KeyValuePair<char, string>('+', b[y++]));
            }
            while (x < n) ops.Add(new KeyValuePair<char, string>('-', a[x++]));
            while (y < m) ops.Add(new KeyValuePair<char, string>('+', b[y++]));
            var keep = new bool[ops.Count];
            for (int k = 0; k < ops.Count; k++) if (ops[k].Key != ' ') for (int d = -context; d <= context; d++) if (k + d >= 0 && k + d < ops.Count) keep[k + d] = true;
            var outl = new List<string>(); bool gap = false;
            for (int k = 0; k < ops.Count; k++)
            {
                if (keep[k]) { if (gap) outl.Add("…"); gap = false; outl.Add(ops[k].Key + " " + ops[k].Value); }
                else gap = true;
            }
            string s = string.Join("\n", outl);
            return s.Length > 20000 ? s.Substring(0, 20000) : s;
        }

        /* ---------------- 쓰기 도구: Prepare(미리보기) → Apply(적용) ---------------- */
        public static Prepared PrepareWriteFile(Workspace ws, Dictionary<string, object> a)
        {
            string abs = ws.Resolve(S(a, "path"));
            if (IsGitInternal(ws, abs)) Fail(".git 내부는 수정할 수 없어요.");
            object cv; if (a == null || !a.TryGetValue("content", out cv) || !(cv is string)) Fail("content(문자열)가 필요해요.");
            string content = (string)a["content"];
            if (Encoding.UTF8.GetByteCount(content) > MAX_WRITE_BYTES) Fail("내용이 너무 커요 (최대 1MB).");
            string old = null;
            if (Directory.Exists(abs)) Fail("폴더에는 쓸 수 없어요.");
            if (File.Exists(abs)) old = ReadText(abs);
            string rel = ws.Rel(abs);
            var p = new Prepared
            {
                Rel = rel, Creating = old == null,
                Title = (old == null ? "새 파일 만들기: " : "파일 덮어쓰기: ") + rel,
                Diff = old == null ? string.Join("\n", content.Split('\n').Take(200).Select(l => "+ " + l)) : MakeDiff(old, content),
            };
            p.Apply = () =>
            {
                Directory.CreateDirectory(Path.GetDirectoryName(abs));
                File.WriteAllText(abs, content, new UTF8Encoding(false));
                return new ToolResult { Output = (old == null ? "만들었어요" : "덮어썼어요") + ": " + rel + " (" + content.Split('\n').Length + "줄)" };
            };
            return p;
        }

        static int CountOf(string text, string sub) { int c = 0, i = 0; while ((i = text.IndexOf(sub, i, StringComparison.Ordinal)) >= 0) { c++; i += sub.Length; } return c; }

        public static Prepared PrepareEditFile(Workspace ws, Dictionary<string, object> a)
        {
            string abs = ws.Resolve(S(a, "path"));
            if (IsGitInternal(ws, abs)) Fail(".git 내부는 수정할 수 없어요.");
            object ov, nv;
            if (a == null || !a.TryGetValue("old_string", out ov) || !(ov is string) || (string)ov == "") Fail("old_string(바꿀 기존 텍스트)이 필요해요.");
            if (!a.TryGetValue("new_string", out nv) || !(nv is string)) Fail("new_string 이 필요해요.");
            string os = (string)a["old_string"], ns = (string)a["new_string"];
            if (os == ns) Fail("old_string 과 new_string 이 같아요.");
            string text = ReadText(abs);
            int count = CountOf(text, os);
            if (count == 0) Fail("old_string 을 파일에서 찾지 못했어요. 공백/들여쓰기까지 정확히 같아야 해요. read_file 로 다시 확인하세요.");
            bool all = B(a, "replace_all");
            if (count > 1 && !all) Fail("old_string 이 " + count + "곳에서 발견돼 어디를 바꿀지 알 수 없어요. 앞뒤 문맥을 더 포함하거나 replace_all=true 를 쓰세요.");
            string next;
            if (all) next = text.Replace(os, ns);
            else { int i = text.IndexOf(os, StringComparison.Ordinal); next = text.Substring(0, i) + ns + text.Substring(i + os.Length); }
            string rel = ws.Rel(abs);
            string suffix = count > 1 ? " (" + count + "곳)" : "";
            var p = new Prepared { Rel = rel, Title = "수정: " + rel + suffix, Diff = MakeDiff(text, next) };
            p.Apply = () => { File.WriteAllText(abs, next, new UTF8Encoding(false)); return new ToolResult { Output = "수정했어요: " + rel + suffix }; };
            return p;
        }

        public static ToolResult TodoWrite(Dictionary<string, object> a)
        {
            object iv; if (a == null || !a.TryGetValue("items", out iv) || !(iv is IEnumerable) || iv is string) Fail("items 배열이 필요해요.");
            var items = new List<Dictionary<string, object>>();
            foreach (var o in ((IEnumerable)a["items"]).Cast<object>().Take(50))
            {
                var d = o as Dictionary<string, object>;
                string text = d != null && d.ContainsKey("text") && d["text"] != null ? Convert.ToString(d["text"]) : "";
                if (text.Length > 200) text = text.Substring(0, 200);
                string st = d != null && d.ContainsKey("status") ? Convert.ToString(d["status"]) : "";
                if (st != "pending" && st != "in_progress" && st != "completed") st = "pending";
                items.Add(new Dictionary<string, object> { { "text", text }, { "status", st } });
            }
            return new ToolResult { Output = "할 일 목록을 갱신했어요.", Items = items };
        }

        /* ---------------- 자동 승인용 분류기 ----------------
           level: "safe"(자동 실행) | "ask"(승인 필요) | "danger"(위험 경고와 함께 승인) */
        static readonly HashSet<string> SAFE_CMDS = new HashSet<string> { "ls", "dir", "pwd", "cat", "type", "echo", "head", "tail", "wc", "grep", "rg", "findstr", "which", "where", "whoami", "date", "tree", "stat", "file", "basename", "dirname", "sort", "uniq", "cut", "diff", "cd", "true", "hostname", "uname", "more", "less", "ver", "chcp" };
        static readonly HashSet<string> SAFE_GIT = new HashSet<string> { "status", "log", "diff", "show", "ls-files", "rev-parse", "blame", "describe", "shortlog", "ls-tree", "cat-file" };
        static readonly HashSet<string> DANGER_CMDS = new HashSet<string> { "rm", "rmdir", "del", "erase", "rd", "format", "mkfs", "dd", "shutdown", "reboot", "halt", "poweroff", "sudo", "su", "doas", "chmod", "chown", "chgrp", "kill", "killall", "pkill", "taskkill", "reg", "regedit", "diskpart", "remove-item", "format-volume", "clear-content", "set-executionpolicy", "icacls", "takeown", "fdisk", "mount", "umount", "crontab", "schtasks", "sc", "net", "netsh", "bcdedit", "cipher", "vssadmin", "wmic" };
        static readonly HashSet<string> NET_CMDS = new HashSet<string> { "curl", "wget", "invoke-webrequest", "iwr", "invoke-restmethod", "irm", "ssh", "scp", "sftp", "ftp", "nc", "ncat", "telnet", "rsync", "apt", "apt-get", "yum", "dnf", "brew", "choco", "winget", "scoop", "snap", "pacman", "bitsadmin", "certutil" };

        public static KeyValuePair<string, string> ClassifyCommand(string cmd)
        {
            string c = (cmd ?? "").Trim();
            if (c == "") return KV("ask", "빈 명령");
            if (Regex.IsMatch(c, @"[`]|\$\(|\$\{|<\(")) return KV("ask", "명령 치환($(...), 백틱)이 있어 내용을 확인해야 해요");
            if (Regex.IsMatch(c, @"%[A-Za-z_][A-Za-z0-9_]*%|![A-Za-z_][A-Za-z0-9_]*!")) return KV("ask", "환경 변수를 펼쳐 쓰는 명령이에요");
            string stripped = Regex.Replace(c, @"\d?>&\d", "");
            stripped = Regex.Replace(stripped, @"\d?>\s*/dev/null", "");
            stripped = Regex.Replace(stripped, @"\d?>\s*nul\b", "", RegexOptions.IgnoreCase);
            if (Regex.IsMatch(stripped, "[<>]")) return KV("ask", "파일에 쓰거나(>) 입력을 연결(<)해요");
            if (Regex.IsMatch(stripped, @"\|\s*(sh|bash|zsh|dash|powershell|pwsh|iex|cmd)(\.exe)?\b", RegexOptions.IgnoreCase)) return KV("danger", "받은 내용을 그대로 셸에서 실행하는 명령이에요");
            var segs = Regex.Split(stripped, @"\r?\n|;|&&|\|\||\||&").Select(s => s.Trim()).Where(s => s != "").ToList();
            if (segs.Count == 0) return KV("ask", "해석할 수 없는 명령");
            var worst = KV("safe", "");
            var rank = new Dictionary<string, int> { { "safe", 0 }, { "ask", 1 }, { "danger", 2 } };
            Action<string, string> bump = (lv, reason) => { if (rank[lv] > rank[worst.Key]) worst = KV(lv, reason); };
            foreach (var seg in segs)
            {
                var toks = Regex.Split(seg, @"\s+").ToList();
                while (toks.Count > 0 && Regex.IsMatch(toks[0], @"^[A-Za-z_][A-Za-z0-9_]*=")) toks.RemoveAt(0);
                if (toks.Count == 0) continue;
                string first = toks[0].Trim('"', '\'').ToLowerInvariant();
                first = Regex.Replace(first, @"^.*[\\/]", "");
                first = Regex.Replace(first, @"\.(exe|cmd|bat|ps1|com)$", "");
                var rest = toks.Skip(1).ToList();
                string restJ = string.Join(" ", rest);
                if (first == "") continue;
                if (first == "cmd" || first == "powershell" || first == "pwsh" || first == "bash" || first == "sh" || first == "start" || first == "call") { bump("ask", "'" + first + "' 로 다른 명령을 실행해요"); continue; }
                if (DANGER_CMDS.Contains(first)) { bump("danger", "'" + first + "' 는 삭제/시스템/권한을 바꿀 수 있는 명령이에요"); continue; }
                if (NET_CMDS.Contains(first)) { bump("ask", "'" + first + "' 는 다운로드/설치/네트워크 작업이에요"); continue; }
                if (first == "git")
                {
                    string sub = rest.FirstOrDefault(t => !t.StartsWith("-")) ?? "";
                    if (Regex.IsMatch(sub, "reset|clean|push|rebase|checkout|restore|rm|gc|prune") && Regex.IsMatch(restJ, @"--hard|--force|-f\b|clean|push|rm|prune")) { bump("danger", "'git " + sub + "' 는 작업물이나 원격을 되돌리기 어렵게 바꿀 수 있어요"); continue; }
                    if (SAFE_GIT.Contains(sub)) continue;
                    if (sub == "branch" && rest.All(t => Regex.IsMatch(t, "^(-a|-r|-v|-vv|--list|--all|branch)$"))) continue;
                    if (sub == "tag" && rest.Count <= 1) continue;
                    if (sub == "remote" && rest.All(t => Regex.IsMatch(t, "^(-v|remote)$"))) continue;
                    if (rest.Count == 1 && Regex.IsMatch(rest[0], "^(--version|-v)$")) continue;
                    bump("ask", "'git " + sub + "' 는 저장소나 네트워크를 바꿀 수 있어요"); continue;
                }
                if (Regex.IsMatch(first, "^(npm|npx|pnpm|yarn|pip|pip3|pipx|cargo|go|gem|composer|dotnet|bun)$"))
                {
                    if (rest.Count == 1 && Regex.IsMatch(rest[0], "^(-v|--version|-V|version)$")) continue;
                    if (Regex.IsMatch(restJ, @"\b(install|i|add|update|upgrade|get|publish|remove|uninstall|create)\b")) { bump("ask", "'" + first + "' 패키지를 내려받거나 설치/제거해요"); continue; }
                    bump("ask", "'" + first + "' 는 프로젝트 코드를 실행할 수 있어요"); continue;
                }
                if (first == "find") { if (Regex.IsMatch(restJ, @"(^|\s)-(delete|exec|execdir|ok|okdir|fprint\w*|fls)\b")) bump("danger", "find 의 삭제/실행 옵션이 있어요"); continue; }
                if (Regex.IsMatch(first, "^(node|python|python3|py|deno|ruby|perl|php|java|javac)$"))
                {
                    if (rest.Count == 1 && Regex.IsMatch(rest[0], "^(-v|--version|-V)$")) continue;
                    bump("ask", "'" + first + "' 로 코드를 실행해요"); continue;
                }
                if (first == "sed" && !Regex.IsMatch(restJ, @"(^|\s)-i")) continue;
                if (SAFE_CMDS.Contains(first)) continue;
                bump("ask", "'" + first + "' 는 안전한 읽기 전용 명령 목록에 없어요");
            }
            return worst;
        }
        static KeyValuePair<string, string> KV(string a, string b) { return new KeyValuePair<string, string>(a, b); }

        static readonly Regex[] SENSITIVE = {
            new Regex(@"(^|/)\.env(\.|$)", RegexOptions.IgnoreCase),
            new Regex(@"\.(pem|key|p12|pfx|crt|cer|kdbx)$", RegexOptions.IgnoreCase),
            new Regex(@"(^|/)id_(rsa|dsa|ecdsa|ed25519)", RegexOptions.IgnoreCase),
            new Regex(@"(^|/)(credentials|secrets?)(\.|$)", RegexOptions.IgnoreCase),
            new Regex(@"(^|/)\.(npmrc|netrc|pypirc|htpasswd)$", RegexOptions.IgnoreCase),
            new Regex(@"(^|/)\.github/workflows/", RegexOptions.IgnoreCase),
            new Regex(@"(^|/)(\.ssh|\.aws|\.gnupg)/", RegexOptions.IgnoreCase),
        };
        public static bool IsSensitivePath(string rel) { string r = Posix(rel ?? ""); return SENSITIVE.Any(x => x.IsMatch(r)); }
    }
}
