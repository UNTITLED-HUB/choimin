// <webview>(최미나이 사이트)에 주입되는 preload. 사이트 스크립트보다 먼저 실행된다.
// Electron 은 webview 에서도 contextIsolation 을 끌 수 없어서 contextBridge + webFrame(main world getter)으로 전달한다.
//
// 사이트가 읽는 값 (읽기 전용 — 페이지가 덮어쓸 수 없다):
//   CHOIMINI_APP = 'desktop' · CHOIMINI_SKIP_CLOUDFLARE = true (Cloudflare 확인 없음)
//   CHOIMINI_MODE = 'chat' | 'code'  → 호스트의 토글에 따라 실시간 변경
//   CHOIMINI_CODE_MODE_PROMPT        → Code 모드일 때만 코딩 에이전트 프롬프트
//   DesktopBridge.openAuth(url) / callTool(tool, args) / reportAuth(loggedIn)
// (도구 실행 허용 여부는 메인 프로세스가 로그인·캡차·모드·작업 폴더·사용자 승인으로 따로 판단한다. 여기 값은 표시용이지 보안 경계가 아니다.)
const { ipcRenderer, contextBridge, webFrame } = require("electron");

const state = { mode: "chat", prompt: "" };
try { // 시작 시점의 실제 모드를 메인 프로세스에서 받아온다 (Code 모드에서 새로고침해도 처음부터 맞게)
  const init = ipcRenderer.sendSync("guest-get-state");
  if (init && init.mode === "code") { state.mode = "code"; state.prompt = String(init.prompt || ""); }
} catch (_) {}

let seq = 0;
const pending = new Map();
contextBridge.exposeInMainWorld("__choiminiHost", { getMode: () => state.mode, getPrompt: () => state.prompt });
contextBridge.exposeInMainWorld("DesktopBridge", {
  openAuth: (url) => ipcRenderer.sendToHost("open-auth", String(url)),
  // 에이전트 도구 호출. Promise<{ok, output|error, ...}>. 실제 차단/승인은 앱이 한다.
  callTool: (tool, args) => {
    const reqId = "t" + (++seq) + "_" + Date.now();
    return new Promise((resolve) => { pending.set(reqId, resolve); ipcRenderer.sendToHost("tool-call", { reqId, tool: String(tool), args: args && typeof args === "object" ? args : {} }); });
  },
  // 사이트가 로그인 상태를 알린다 → 앱이 로그인 안 된 상태에서는 Code 모드/도구를 막는다
  reportAuth: (loggedIn) => ipcRenderer.sendToHost("auth-state", !!loggedIn),
});

webFrame.executeJavaScript(`(function () {
  var H = window.__choiminiHost;
  function ro(name, getter) { try { Object.defineProperty(window, name, { get: getter, enumerable: true, configurable: false }); } catch (e) {} }
  ro("CHOIMINI_APP", function () { return "desktop"; });
  ro("CHOIMINI_SKIP_CLOUDFLARE", function () { return true; });
  ro("CHOIMINI_MODE", function () { return H.getMode(); });
  ro("CHOIMINI_CODE_MODE_PROMPT", function () { return H.getPrompt(); });
})();`);

ipcRenderer.on("mode-change", (_e, mode, prompt) => {
  state.mode = mode === "code" ? "code" : "chat";
  state.prompt = state.mode === "code" ? String(prompt || "") : "";
  webFrame.executeJavaScript(`try{window.dispatchEvent(new CustomEvent("choimini-mode",{detail:{mode:${JSON.stringify(state.mode)}}}))}catch(e){}`);
});
ipcRenderer.on("auth-callback", (_e, url) => {
  webFrame.executeJavaScript(`window.__choiminiHandleAuthCallback && window.__choiminiHandleAuthCallback(${JSON.stringify(String(url))})`);
});
ipcRenderer.on("tool-result", (_e, { reqId, result }) => {
  const resolve = pending.get(reqId);
  if (resolve) { pending.delete(reqId); resolve(result); }
});
