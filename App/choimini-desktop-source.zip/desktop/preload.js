// 렌더러(호스트 페이지)용 preload — contextBridge 로 안전하게 API 노출. 이 창은 사이트(webview)와 별개의 신뢰 영역이다.
const { contextBridge, ipcRenderer } = require("electron");
const on = (ch, cb) => ipcRenderer.on(ch, (_e, m) => cb(m));

contextBridge.exposeInMainWorld("desktop", {
  // 로그인 / 캡차 / 모드
  setAuth: (v) => ipcRenderer.invoke("set-auth", !!v),
  captchaNew: () => ipcRenderer.invoke("captcha-new"),
  captchaVerify: (input) => ipcRenderer.invoke("captcha-verify", input),
  codeStatus: () => ipcRenderer.invoke("code-status"),
  setMode: (m) => ipcRenderer.invoke("set-mode", m),
  getCodePrompt: () => ipcRenderer.invoke("get-code-prompt"),
  getSiteUrl: () => ipcRenderer.invoke("get-site-url"),
  getAppInfo: () => ipcRenderer.invoke("get-app-info"),
  onForceChat: (cb) => on("force-chat", cb),

  // 작업 폴더 / 권한
  workspaceGet: () => ipcRenderer.invoke("workspace-get"),
  workspacePick: () => ipcRenderer.invoke("workspace-pick"),
  setPermMode: (m) => ipcRenderer.invoke("perm-mode-set", m),
  onWorkspaceChanged: (cb) => on("workspace-changed", cb),
  onPermissionRequest: (cb) => on("permission-request", cb),
  onPermissionCancel: (cb) => ipcRenderer.on("permission-cancel", () => cb()),
  respondPermission: (id, choice) => ipcRenderer.send("permission-response", { id, choice }),

  // 에이전트
  callTool: (tool, args) => ipcRenderer.invoke("agent-tool", { tool, args }),
  abortAgent: () => ipcRenderer.send("agent-abort"),
  onActivity: (cb) => on("agent-activity", cb),

  // 터미널
  termCreate: (opts) => ipcRenderer.invoke("term-create", opts),
  termInput: (id, data) => ipcRenderer.send("term-input", { id, data }),
  termResize: (id, cols, rows) => ipcRenderer.send("term-resize", { id, cols, rows }),
  termKill: (id) => ipcRenderer.send("term-kill", { id }),
  onTermData: (cb) => on("term-data", cb),
  onTermExit: (cb) => on("term-exit", cb),

  // OAuth
  openAuth: (url) => ipcRenderer.send("open-auth", url),
  onAuthCallback: (cb) => ipcRenderer.on("auth-callback", (_e, url) => cb(url)),
});
