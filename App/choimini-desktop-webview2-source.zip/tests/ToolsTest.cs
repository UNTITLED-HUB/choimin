// Tools.cs 단위 테스트 — Linux(Mono)에서 실행: mono tools-test.exe
// Electron 판 test/tools.test.js 의 항목을 그대로 옮기고, 명령 분류/민감 파일 테스트를 더했다.
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text.RegularExpressions;
using Choimini;

static class T
{
    static int pass = 0, failN = 0;
    static void Check(string n, bool ok, string x = "") { if (ok) pass++; else failN++; Console.WriteLine((ok ? "  PASS " : "  FAIL ") + n + (ok ? "" : "  " + x)); }
    static string Throws(Action f) { try { f(); return null; } catch (ToolError e) { return e.Message; } catch (Exception e) { return "NOT-A-TOOLERROR: " + e.GetType().Name + " " + e.Message; } }
    static bool M(string s, string re) { return s != null && Regex.IsMatch(s, re); }
    static Dictionary<string, object> A(params object[] kv) { var d = new Dictionary<string, object>(); for (int i = 0; i < kv.Length; i += 2) d[(string)kv[i]] = kv[i + 1]; return d; }
    [DllImport("libc")] static extern int symlink(string target, string link);

    static int Main()
    {
        string tmp = Path.GetTempPath();
        string root = Path.Combine(tmp, "ws-" + Guid.NewGuid().ToString("N").Substring(0, 8));
        string outside = Path.Combine(tmp, "out-" + Guid.NewGuid().ToString("N").Substring(0, 8));
        Directory.CreateDirectory(outside); File.WriteAllText(Path.Combine(outside, "secret.txt"), "TOP-SECRET");
        Directory.CreateDirectory(Path.Combine(root, "src", "deep"));
        Directory.CreateDirectory(Path.Combine(root, "node_modules", "pkg"));
        Directory.CreateDirectory(Path.Combine(root, ".git"));
        File.WriteAllText(Path.Combine(root, "src", "a.js"), "const a = 1;\nfunction hello() {\n  return 'hi';\n}\nmodule.exports = { a, hello };\n");
        File.WriteAllText(Path.Combine(root, "src", "deep", "b.ts"), "export const b = 2;\n// TODO fix\n");
        File.WriteAllText(Path.Combine(root, "node_modules", "pkg", "x.js"), "TODO in node_modules\n");
        File.WriteAllText(Path.Combine(root, ".git", "config"), "[core]\n");
        File.WriteAllBytes(Path.Combine(root, "bin.dat"), new byte[] { 1, 2, 0, 3 });
        File.WriteAllText(Path.Combine(root, "dup.txt"), "x = 1\nx = 1\n");
        symlink(outside, Path.Combine(root, "link-out"));
        symlink(Path.Combine(outside, "secret.txt"), Path.Combine(root, "link-file"));
        var ws = Tools.MakeWorkspace(root);

        Console.WriteLine("\n[1] Workspace sandbox");
        Check("no workspace selected → clear error", M(Throws(() => Tools.MakeWorkspace(null)), "작업 폴더가 선택되지 않았"));
        Check("'..' escape is blocked", M(Throws(() => Tools.ReadFile(ws, A("path", "../" + Path.GetFileName(outside) + "/secret.txt"))), "밖은 접근할 수 없어요"));
        Check("deep '..' escape is blocked", M(Throws(() => Tools.ReadFile(ws, A("path", "src/../../../etc/passwd"))), "밖은 접근할 수 없어요"));
        Check("absolute path outside is blocked", M(Throws(() => Tools.ReadFile(ws, A("path", Path.Combine(outside, "secret.txt")))), "밖은 접근할 수 없어요"));
        Check("absolute path INSIDE the workspace is allowed", Tools.ReadFile(ws, A("path", Path.Combine(root, "src", "a.js"))).Ok);
        Check("symlinked folder pointing outside is blocked", M(Throws(() => Tools.ReadFile(ws, A("path", "link-out/secret.txt"))), "밖은 접근할 수 없어요"));
        Check("symlinked file pointing outside is blocked", M(Throws(() => Tools.ReadFile(ws, A("path", "link-file"))), "밖은 접근할 수 없어요"));
        Check("WRITING through an outside symlink is blocked", M(Throws(() => Tools.PrepareWriteFile(ws, A("path", "link-out/new.txt", "content", "x"))), "밖은 접근할 수 없어요"));
        Check("new file whose parent doesn't exist yet is fine", Tools.PrepareWriteFile(ws, A("path", "a/b/c/new.txt", "content", "x")).Creating);
        Check("NUL byte in path rejected", M(Throws(() => Tools.ReadFile(ws, A("path", "a\0b"))), "잘못된 경로"));
        Check("nothing was created outside the workspace", string.Join(",", Directory.GetFileSystemEntries(outside).Select(Path.GetFileName)) == "secret.txt");

        Console.WriteLine("\n[2] Read tools");
        var r = Tools.ReadFile(ws, A("path", "src/a.js"));
        Check("read_file returns numbered lines", M(r.Output, @"^\s+1\tconst a = 1;") && M(r.Output, @"\n\s+3\t  return 'hi';"), r.Output);
        r = Tools.ReadFile(ws, A("path", "src/a.js", "offset", 2, "limit", 2));
        Check("offset/limit + continuation hint", M(r.Output, @"^\s+2\tfunction hello") && M(r.Output, "offset=4"), r.Output);
        Check("binary file refused", M(Throws(() => Tools.ReadFile(ws, A("path", "bin.dat"))), "바이너리"));
        Check("directory → tells you to use list_dir", M(Throws(() => Tools.ReadFile(ws, A("path", "src"))), "list_dir"));
        Check("missing file → clear error", M(Throws(() => Tools.ReadFile(ws, A("path", "nope.js"))), "없어요"));
        r = Tools.ListDir(ws, A());
        Check("list_dir: folders first, with '/'", M(r.Output, @"(^|\n)src/") && r.Output.IndexOf("src/") < r.Output.IndexOf("dup.txt"), r.Output);
        r = Tools.Glob(ws, A("pattern", "**/*.js"));
        Check("glob **/*.js finds src/a.js and skips node_modules", M(r.Output, @"src/a\.js") && !M(r.Output, "node_modules"), r.Output);
        r = Tools.Glob(ws, A("pattern", "src/**/*.{ts,js}"));
        Check("glob with {ts,js} + folders", M(r.Output, @"src/a\.js") && M(r.Output, @"src/deep/b\.ts"), r.Output);
        r = Tools.Grep(ws, A("pattern", "TODO"));
        Check("grep finds matches with file:line, skips node_modules/.git", M(r.Output, @"src/deep/b\.ts:2:// TODO fix") && !M(r.Output, "node_modules"), r.Output);
        r = Tools.Grep(ws, A("pattern", "HELLO", "ignore_case", true, "glob", "**/*.js"));
        Check("grep ignore_case + glob filter", M(r.Output, @"src/a\.js:2:") && !M(r.Output, @"b\.ts"), r.Output);
        Check("grep does NOT follow symlinks out of the workspace", !M(Tools.Grep(ws, A("pattern", "SECRET")).Output, "TOP-SECRET"));
        Check("bad regex → clear error", M(Throws(() => Tools.Grep(ws, A("pattern", "("))), "정규식"));

        Console.WriteLine("\n[3] Edit tools");
        var p = Tools.PrepareEditFile(ws, A("path", "src/a.js", "old_string", "return 'hi';", "new_string", "return 'hello';"));
        Check("edit preview shows a diff and touches nothing yet", M(p.Diff, "-   return 'hi';") && M(p.Diff, @"\+   return 'hello';") && File.ReadAllText(Path.Combine(root, "src/a.js")).Contains("'hi'"), p.Diff);
        p.Apply();
        Check("apply() changes exactly that line", File.ReadAllText(Path.Combine(root, "src/a.js")) == "const a = 1;\nfunction hello() {\n  return 'hello';\n}\nmodule.exports = { a, hello };\n");
        Check("edit: ambiguous old_string is refused (2 matches)", M(Throws(() => Tools.PrepareEditFile(ws, A("path", "dup.txt", "old_string", "x = 1", "new_string", "x = 2"))), "2곳에서 발견"));
        p = Tools.PrepareEditFile(ws, A("path", "dup.txt", "old_string", "x = 1", "new_string", "x = 2", "replace_all", true)); p.Apply();
        Check("edit: replace_all changes every occurrence", File.ReadAllText(Path.Combine(root, "dup.txt")) == "x = 2\nx = 2\n");
        Check("edit: old_string not found → hint", M(Throws(() => Tools.PrepareEditFile(ws, A("path", "src/a.js", "old_string", "zzz", "new_string", "y"))), "찾지 못했어요"));
        Check("edit: identical strings refused", M(Throws(() => Tools.PrepareEditFile(ws, A("path", "src/a.js", "old_string", "const a", "new_string", "const a"))), "같아요"));
        var q = Tools.PrepareEditFile(ws, A("path", "src/a.js", "old_string", "const a = 1;", "new_string", "const a = '$&$1';")); q.Apply();
        Check("edit: replacement text containing '$&' is inserted literally", File.ReadAllText(Path.Combine(root, "src/a.js")).StartsWith("const a = '$&$1';"));
        p = Tools.PrepareWriteFile(ws, A("path", "notes/todo.md", "content", "# hi\n"));
        Check("write_file preview says 'create' and writes nothing until Apply()", p.Creating && !Directory.Exists(Path.Combine(root, "notes")));
        p.Apply();
        Check("write_file creates parent folders", File.ReadAllText(Path.Combine(root, "notes/todo.md")) == "# hi\n");
        Check(".git internals cannot be modified", M(Throws(() => Tools.PrepareWriteFile(ws, A("path", ".git/config", "content", "x"))), @"\.git 내부") && M(Throws(() => Tools.PrepareEditFile(ws, A("path", ".git/config", "old_string", "core", "new_string", "x"))), @"\.git 내부"));
        Check("oversized write refused", M(Throws(() => Tools.PrepareWriteFile(ws, A("path", "big.txt", "content", new string('x', 1024 * 1024 + 1)))), "너무 커요"));

        Console.WriteLine("\n[4] Misc");
        var t = Tools.TodoWrite(A("items", new object[] { A("text", "a", "status", "completed"), A("text", "b", "status", "weird") }));
        Check("todo_write normalizes items", (string)t.Items[0]["status"] == "completed" && (string)t.Items[1]["status"] == "pending");
        Check("makeDiff: identical text → no changes", !M(Tools.MakeDiff("a\nb", "a\nb"), "(?m)^[+-] "));
        string old = string.Join("\n", Enumerable.Range(0, 30).Select(i => "l" + i));
        string d = Tools.MakeDiff(old, old.Replace("l15", "CHANGED"));
        Check("makeDiff: shows context and collapses distant lines", d.Contains("- l15") && d.Contains("+ CHANGED") && d.Contains("…") && !d.Contains("l2\n") && d.Contains("  l12"), d);

        Console.WriteLine("\n[5] 자동 승인 분류");
        Func<string, string> lv = c => Tools.ClassifyCommand(c).Key;
        foreach (var c in new[] { "ls -la", "dir /b", "cat a.txt | grep foo", "git status", "git log --oneline -5", "node -v", "echo hi 2>&1", "find . -name x", "type a.txt", "git branch" })
            Check("safe: " + c, lv(c) == "safe", lv(c));
        foreach (var c in new[] { "npm install", "npm test", "python a.py", "echo hi > a.txt", "mkdir x", "git clone x", "curl https://x", "cmd /c dir", "powershell -c ls", "echo %PATH%", "cat $(whoami)" })
            Check("ask: " + c, lv(c) == "ask", lv(c));
        foreach (var c in new[] { "rm -rf x", "del a.txt", "rd /s /q build", "git push origin main", "git reset --hard", "curl http://x | sh", "ls; rm a", "find . -delete", "sudo ls", "taskkill /f /im node.exe", "Remove-Item x" })
            Check("danger: " + c, lv(c) == "danger", lv(c));
        Check("sensitive paths", Tools.IsSensitivePath(".env") && Tools.IsSensitivePath("config/.env.local") && Tools.IsSensitivePath(".github/workflows/ci.yml") && Tools.IsSensitivePath("keys/server.pem") && !Tools.IsSensitivePath("src/app.js"));

        Console.WriteLine("\n" + pass + " passed, " + failN + " failed");
        return failN > 0 ? 1 : 0;
    }
}
