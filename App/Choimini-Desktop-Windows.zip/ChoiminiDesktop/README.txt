Choimini Desktop 1.5.2 (Windows x64)

ChoiminiDesktop.exe 하나만 실행하면 됩니다. (WebView2 런타임 필요 - Windows 10/11 기본 포함)
